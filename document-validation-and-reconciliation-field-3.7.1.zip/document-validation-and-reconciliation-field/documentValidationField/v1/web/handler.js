// @author: EXL

// Angular initialization
var app = angular.module("myApp", ["DropDownSelect", "720kb.datepicker"]);
app.directive("dynamicfield", function () {
	return {
		restrict: "E",
		scope: {
			field: "=",
			form: "=",
			uiConfig: "=",
			formValues: "="
		},
		templateUrl: "./fieldHandler.html"
	};
});
// directive for string to number validation
app.directive('stringToNumber', function () {
	return {
		require: 'ngModel',
		link: function (scope, element, attrs, ngModel) {
			ngModel.$parsers.push(function (value) {
				return '' + value;
			});
			ngModel.$formatters.push(function (value) {
				return (typeof value === 'string' && value.indexOf(".") > -1) ? parseFloat(value) : parseInt(value);
			});
		}
	};
});

app.controller("myCtrl", function ($q, $scope, orderByFilter, $rootScope, $location, $timeout) {
	const startTime = performance.now();
	$rootScope.location = $location;

	// VALUE_ORIGINS is to capture the fields value's origin,
	// Auto means captured from Appian and SELECTED means that they are captured from the plugin
	var VALUE_ORIGINS = ["AUTO", "SELECTED"];

	// GLOBAL variable which holds all the plugin data
	var plugInData = {};
	var onChange = "onChange";
	var onChangeLast = "onChangeLast";
	var onSearch = "onSearch";
	var onGridClick = "onGridClick";
	var onButtonClick = "onButtonClick";
	var onTabChange = "onTabChange";
	var iframeHeight = "750px",
		iframeWidth = "750px";

	var isTestModeEnabled = false;

	// PDF.JS Global Variables, which are set here by JS utilities
	var PDFViewerApplication, clearOldRectangles, showRectangleByCoordinates, updatePDFConfigs;

	// Angular's global variable
	$scope.uiConfig = {
		supportedWebFields: {
			all: ["text", "number", "date", "select", "multiselect", "search", "grid", "button-group", "currency", "_", "paragraph", "searchableDropdown", "button", "label", "textended"],
			inputTypes: ["text", "number", "date", "currency", "paragraph", "textended"],
			arrayTypes: ["select", "multiselect"],
			search: ["search"],
			other: ["grid", "button-group", "button", "searchableDropdown", "label"]
		},
		selectedOptions: {},
		gridFieldSelectedOptions: {}, //for array type fields inside grid
		lastFocusedElement: null,
		globalConfig: {}
	};
	// Properties to check while verifying if two field definitions are equal
	$scope.fieldProperties = ["type", "label", "visible", "showLabel", "required", "disabled", "style", "icon", "placeholder", "masterListValue"];
	$scope.changeValue = {};
	$scope.focusedElement = null;
	$scope.myFormHolder = {};
	$scope.isValueChangedInLastFocusedElement = false;
	$scope.formValidationErrors = {};
	$scope.oldFormObjectData = {};
	$scope.oldObjectValue = {};
	$scope.formValues = {};
	$scope.dropDownValues = {};
	$scope.dropDownBooleanValues = {};
	$scope.selectedVal = {};
	$scope.globalConfig = {};
	$scope.isGridCellClicked = false;
	$scope.masterListElement = {};
	$scope.formNewDetails = {};
	$scope.globalMasterValues = {};
	$scope.disableCtrl = {};
	$scope.visibilityCtrl = {};
	$scope.requiredCtrl = {};
	$scope.styleCtrl = {};
	$scope.retainVal = {};

	$scope.globalCascadingMasterValues = {};

	$scope.initialLoadCasCadingDropDownValues = {};
	$scope.OptionLists = {};

	// Collection object to keep the details of all the fields
	$scope.layoutDetails = {};
	// Collection object to keep the details of all the fields one step back
	$scope.oldLayoutDetails = {};
	// Appian document Id
	var currentDocumentDetails = null;
	// Appian document Url
	var currentDocumentId = null;
	// Appian Document Data
	$scope.docData = null;

	$scope.buttonClicked = false;
	// Get Luxon
	const luxonDateTime = luxon.DateTime;
	// Initialization Flag
	var isInitializing = true;
	// Rule Container
	$scope.rulesContainer = {};

	$scope.fieldValDynamic = {
		field: "",
		id: "",
		query: "",
		pageNumber: "",
		origin: "",
		xMin: "",
		xMax: "",
		yMin: "",
		yMax: ""
	};

	// Setting up the above Global variables to initialize the application, they are called from viewer.html file
	window.setPDFViewerApplication = function (data, showHighlight, clearOldRectangle, updatePdfConfig) {
		PDFViewerApplication = data;
		showRectangleByCoordinates = showHighlight;
		clearOldRectangles = clearOldRectangle;
		updatePDFConfigs = updatePdfConfig;

		//call this in last if used in Appian, otherwise comment it to test on local server
		if (!isTestModeEnabled)
			init();
	};

	// updating the focus (annotations) on zoom change, called from viewer.js (function: zoomIn, lineNo : 1278)
	window.resetAnnotations = function () {
		if ($scope.hasOwnProperty("focusedElement") && $scope.focusedElement !== null) {
			setTimeout(function () {
				$scope.onFocusHandler($scope.formValues[$scope.focusedElement.name], $scope.focusedElement);
			}, 1);
		}
	};

	function triggerWebWorkers() {
		$scope.callWebWorker = function () {
			var worker = new Worker('WebWorkers.js');
			var defer = $q.defer();
			worker.onmessage = function (e) {
				defer.resolve(e.data);
			};
			worker.postMessage(plugInData);
			return defer.promise;
		};

		$scope.callWebWorker().then(function (response) {
			// Set Error Message
			//web workers received once validation loop completed here update the Appian validation
			if (isTestModeEnabled != true && response.appianValidation != null && response.appianValidation.length > 0) {
				raiseAppianError(response.appianValidation);
			}
			let scope = response.scopeValue;
			$scope.disableCtrl = scope.disableCtrl;
			$scope.requiredCtrl = scope.requiredCtrl;
			$scope.styleCtrl = scope.styleCtrl;
			$scope.visibilityCtrl = scope.visibilityCtrl;
			setWatchScope(plugInData);
			//milestonesUpdate(plugInData);
			//$scope.formData['milestones'] = milesTone['formDetails']['milestones'];
		});

	}

	function milestonesUpdate(temp) {
		let milesTone = temp;
		var fetchOne = function (index) {
			var deferred = $q.defer();
			// $timeout(function() {
			deferred.resolve([milesTone['formDetails']['milestones'][index]]);
			// }, 800);
			return deferred.promise;
		};

		// $scope.formData['milestones'] = [];
		const lengthObjects = milesTone['formDetails']['milestones'].length - 1;
		for (var i = 1; i < lengthObjects; i++) {
			fetchOne(i).then(function (items) {
				angular.forEach(items, function (item) {
					$scope.formData['milestones'].push(item);
				});
			});
		};
		// Set the initialization flag to false
		isInitializing = false;
	}
	function setWatchScope(inputs) {
		if (inputs.formDetails == null || inputs.formDetails == undefined)
			inputs.formDetails = {};

		if (inputs.formValues == null || inputs.formValues == undefined)
			inputs.formValues = {};

		if (inputs.annotationObject == null || inputs.annotationObject == undefined)
			inputs.annotationObject = {
				clearOldRectangles: true
			};

		inputs.formDetails.milestones = orderByFilter(inputs.formDetails.milestones, "sortOrder");
		var previouslySelected = {};
		$scope.lastSelected = {};
		inputs.formDetails.milestones.forEach(function (eachMilestone) {
			// handle fields inside milestone here
			if (eachMilestone.hasOwnProperty("fields") && eachMilestone.fields.length) {
				eachMilestone.fields.forEach(function (eachField) {
					sanitizeField(eachField, previouslySelected, inputs);
				});
			}
			eachMilestone.sections.forEach(function (section) {
				section.fields.forEach(function (field) {
					sanitizeField(field, previouslySelected, inputs);
				});
			});
		});
		return inputs;
	}

	// handling the on grid clicked event of each field from index.html,
	// will store the cell and row data to Appian's output "onGirdClick" Field
	$scope.onGridClicked = function (cell, row, field) {
		$scope.isGridCellClicked = true;
		$scope.currentClickedGrid = {
			cell: cell,
			row: row,
			field: field
		};

		if (cell.type == "select") {
			$scope.onGridFieldSelectHandler(cell, field, row, false);
		};

		//console.log(cell, row, field);
		if (!isTestModeEnabled) {
			/*addValidationErrorsInFormValues();*/
			Appian.Component.saveValue(onGridClick, {
				cell: cell,
				row: row,
				fieldDetails: field
			});
		}

		onElementFocusHandler(cell, cell);
	};

	// handling the on focus event of each field from index.html
	// will highlight the text in the pdf
	$scope.onFocusHandler = function (formValue, field) {
		$scope.isGridCellClicked = false;
		onElementFocusHandler(formValue, field);
	};

	function onElementFocusHandler(formValue, field) {
		// Save the last focused element
		$scope.uiConfig.lastFocusedElement = clone($scope.focusedElement);
		// update the currently selected element
		$scope.focusedElement = clone(field);

		// Highlight text in PDF 
		if (plugInData.config.highlightTextOnElementFocus == true) {
			highlightTextInPdf(
				formValue,
				{
					phraseSearch: true,
					clearCanvasBeforeHighlighting: false,
					caseSensitive: plugInData.annotationObject.caseSensitive,
					entireWord: plugInData.annotationObject.entireWord,
					highlightAll: plugInData.annotationObject.highlightAll,
					findPrevious: plugInData.annotationObject.findPrevious
				}
			);
		}

		if ($scope.uiConfig.supportedWebFields.inputTypes.indexOf(field.type) > -1 || $scope.uiConfig.supportedWebFields.search.indexOf(field.type) > -1) {
			highlightTextInPdf(formValue, {
				phraseSearch: false,
				clearCanvasBeforeHighlighting: true
			});
		}
		else { $scope.onSelectHandler(formValue, field, true); }
	}

	// Handle the button click detail, will store output in Appian's onButtonCLick Field
	$scope.onButtonClick = function (value, field) {
		$scope.buttonClicked = true;
		if (!isTestModeEnabled) {
			Appian.Component.saveValue(onButtonClick, { fieldDetails: field, clicked: value });
		}
	};

	$scope.resetDropDownCtrl = function (fieldControl, flag) {
		var elementId, oldMasterData, tempList;
		if (flag == "R" || flag == "P") {
			if (flag === "R") {
				if (fieldControl.controls.hasOwnProperty('resetControl')) {
					oldMasterData = $scope.masterListElement[fieldControl.controls.resetControl];
				}
			}
			else if (flag === "P") {
				oldMasterData = $scope.masterListElement[fieldControl];
			}
			tempList = oldMasterData.split("_");
			fieldIndex = tempList[tempList.length - 1];
			if (flag === "R") {
				elementId = fieldControl.controls.resetControl + "_" + fieldIndex;
			}
			else if (flag === "P") {
				elementId = fieldControl + "_" + fieldIndex;
			}

			var resetdropDownVal = {};
			var query = "--Select--";
			var value = "";
			var pageNumber = 0;
			var pageNumber = 0;
			var origin = 0;
			var xMin = 0;
			var xMax = 0;
			var yMin = 0;
			var yMax = 0;
			if (flag === "R") {
				$scope.selectedVal[fieldControl.controls.resetControl].query = value;
			}
			else if (flag === "P") {
				$scope.selectedVal[fieldControl].query = value;
			}
			resetdropDownVal[0] = {
				query: query,
				value: value,
				pagenumber: pageNumber,
				orgin: origin,
				xMin: xMin,
				xMax: xMax,
				yMin: yMin,
				yMax: yMax,
				isSelected: true
			};

			$scope.dropDownValues[elementId] = resetdropDownVal;
			if (flag === "R") {
				$scope.masterListElement[fieldControl.controls.resetControl] = elementId;
			}
			else if (flag === "P") {
				$scope.masterListElement[fieldControl] = elementId;
			}
		}
	};

	$scope.onSelectHandler = function (formValue, field, onFocus, data) {
		console.log("onSelectHandler: \nformValue", formValue, "\nfield", field, "\nonFocus", onFocus, "\ndata", data);

		$scope.isGridCellClicked = false;

		if (onFocus != true) {
			$scope.uiConfig.lastFocusedElement = clone($scope.focusedElement);
			$scope.focusedElement = clone(field);
		}
		var selectedOption = $scope.uiConfig.selectedOptions[field.name];
		if (field.type == "select") {
			if (selectedOption != null && Array.isArray(selectedOption) == false && selectedOption.hasOwnProperty("pageNumber") && selectedOption.pageNumber !== null
				&& selectedOption.hasOwnProperty("pageNumber") !== "") {
				highlightTextInPdf($scope.uiConfig.selectedOptions[field.name], { clearCanvasBeforeHighlighting: true, phraseSearch: false });
			}
		} else if (field.type == "multiselect") {
			//clearing previous rectangles, if any;
			formValue.rows.forEach(function (each, index) {
				if (each.isSelected) {
					highlightTextInPdf(each, { clearCanvasBeforeHighlighting: (index == 0) ? true : false, phraseSearch: false });
				}
			});
		} else if (field.type == "searchableDropdown") {
			//clearing previous rectangles, if any;
			formValue.rows.forEach(function (each, index) {
				if (each.isSelected) {
					highlightTextInPdf(each, { clearCanvasBeforeHighlighting: (index == 0) ? true : false, phraseSearch: false });
				}
			});
		}
	};

	$scope.onSelectHandlerChangeValue = function (field, value) {
		$scope.isGridCellClicked = false;
		//		console.log("onSelectHandlerChangeValue: \field", field, "\nvalue", value);

		var fieldName = field.name;
		// Blank Place holder for value
		var fieldValue = {
			field: fieldName,
			query: "",
			pageNumber: 0,
			origin: "AUTO",
			xMin: 0.00,
			xMax: 0.00,
			yMin: 0.00,
			yMax: 0.00
		};
		var selectedValue = null;
		// Searchable Dropdown returns all options in array. need to find which is selected
		for (var counter = 0; counter < value.rows.length; counter++) {
			if (value.rows[counter].isSelected == true) {
				selectedValue = value.rows[counter];
				break;
			}
		}

		// Update the placeholder with values. Whatever is missing will have default values from placeholder
		fieldValue = Object.assign(fieldValue, selectedValue);

		if (!isTestModeEnabled) {
			Appian.Component.saveValue(onChangeLast, {
				name: fieldName,
				fieldDetails: field,
				newValue: fieldValue
			});
		}
	};

	$scope.onGridSelectHandlerChangeValue = function (formValue, field) {
		var fieldValue = $scope.uiConfig.selectedOptions[field.name];

		if (fieldValue.hasOwnProperty("name")) { Object.assign($scope.fieldValDynamic, { field: field["name"] }); } else { Object.assign($scope.fieldValDynamic, { field: "" }); }
		if (fieldValue.hasOwnProperty("query")) { Object.assign($scope.fieldValDynamic, { query: fieldValue["query"] }); } else { Object.assign($scope.fieldValDynamic, { query: "" }); }
		if (fieldValue.hasOwnProperty("xMin")) { Object.assign($scope.fieldValDynamic, { xMin: fieldValue["xMin"] }); } else { Object.assign($scope.fieldValDynamic, { xMin: 0.00 }); }
		if (fieldValue.hasOwnProperty("xMax")) { Object.assign($scope.fieldValDynamic, { xMax: fieldValue["xMax"] }); } else { Object.assign($scope.fieldValDynamic, { xMax: 0.00 }); }
		if (fieldValue.hasOwnProperty("yMin")) { Object.assign($scope.fieldValDynamic, { yMin: fieldValue["yMin"] }); } else { Object.assign($scope.fieldValDynamic, { yMin: 0.00 }); }
		if (fieldValue.hasOwnProperty("yMax")) { Object.assign($scope.fieldValDynamic, { yMax: fieldValue["yMax"] }); } else { Object.assign($scope.fieldValDynamic, { yMax: 0.00 }); }
		if (fieldValue.hasOwnProperty("id")) { Object.assign($scope.fieldValDynamic, { id: fieldValue["id"] }); } else { Object.assign($scope.fieldValDynamic, { id: 0 }); }
		if (fieldValue.hasOwnProperty("pageNumber")) { Object.assign($scope.fieldValDynamic, { pageNumber: fieldValue["pageNumber"] }); } else { Object.assign($scope.fieldValDynamic, { pageNumber: 0 }); }
		if (fieldValue.hasOwnProperty("origin")) { Object.assign($scope.fieldValDynamic, { origin: fieldValue["origin"] }); } else { Object.assign($scope.fieldValDynamic, { origin: "AUTO" }); }

		if (field.type == "searchableDropdown") {
			//clearing previous rectangles, if any;
			if (!isTestModeEnabled) {
				Appian.Component.saveValue(onChangeLast,
					{
						name: field["name"],
						fieldDetails: field,
						newValue: $scope.fieldValDynamic
					}
				);
			}
		}
	};

	// initialize called to initiate the Appian part, like fetching document from the Appian KC.
	// getting formDetails and formData
	function init() {
		Appian.Component.onNewValue(function (newValues) {
			handleInit(newValues);
		});
	}

	// Open the document given
	function openDocument(appianDocumentId, connectedSystem) {
		// Open the local PDF file in Test Mode
		if (isTestModeEnabled) {
			openPdf("../MRC_SAMPLE.pdf");
			return;
		}
		const payload = { documentId: appianDocumentId };

		// Check if the current document is already loaded
		if (!currentDocumentId || currentDocumentId != appianDocumentId && !$scope.docData) {
			// Get the document
			Appian.Component.invokeClientApi(connectedSystem, "DocumentRetrieveClientApi", payload)
				.then(handleClientApiResponse)
				.catch(handleError);
		}
	};

	function handleError(response) {
		if (response.error && response.error[0]) {
			raiseAppianError([error.error]);
		}
		else {
			raiseAppianError(["An unspecified error occurred"]);
		}
		// Connected System failed. Load document using alternative method
		if (!_.isEqual(currentDocumentDetails, plugInData.documentDownloadURL)) {
			currentDocumentDetails = plugInData.documentDownloadURL;
			getDocumentFromWeb(plugInData.documentDownloadURL);
		}
	}

	function handleClientApiResponse(response) {
		if (response.payload.error) {
			raiseAppianError(response.payload.error);
			return;
		}
		// Clear any error messages
		resetAppianErrors([]);
		docName = response.payload.docName;
		// Set the document Data
		$scope.docData = response.payload.docData;

		// Update the current document id
		currentDocumentId = documentId;

		console.log("Document Name : ", docName);

		openBase64Pdf($scope.docData);
	}

	$scope.handleSearchableDropdownSearchInput = function (searchValue, field) {
		if (!isTestModeEnabled) {
			Appian.Component.saveValue(onSearch, {
				field: field.name,
				event: "searchableDropdown",
				query: searchValue
			});

		} else {
			//console.log(field, searchValue);
		}
	};

	// When the text is selected in the PDF, the text will be updated in the current focused Element.
	// if the element is array type (select, multiselect), then the text will be pushed in the json array as a new option.
	window.onTextSelectedInPDF = function (data) {
		//console.log(data, $scope.focusedElement)
		if ($scope.focusedElement == null) {
			return;
		}

		$scope.$apply(function () {
			data = {
				pageNumber: data.pageNumber,
				query: data.query,
				xMax: data.coords.xMax,
				xMin: data.coords.xMin,
				yMax: data.coords.yMax,
				yMin: data.coords.yMin,
				origin: VALUE_ORIGINS[1]
			};

			if ($scope.isGridCellClicked) {
				$scope.formValues[$scope.currentClickedGrid.field.name].rows.forEach(function (eachRow, rowIndex) {
					eachRow.data.forEach(function (eachCell, cellIndex) {
						if (eachCell.query == $scope.currentClickedGrid.cell.query && eachCell.type == $scope.currentClickedGrid.cell.type) {
							// currently focused element's type
							switch ($scope.currentClickedGrid.cell.type) {
								case "paragraph":
									if (!$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].hasOwnProperty("originalValues")) {
										$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].originalValues = clone($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex]);
									}
									$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex] = merge($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex], data);
									break;
								case "text":
									if (!$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].hasOwnProperty("originalValues")) {
										$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].originalValues = clone($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex]);
									}
									$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex] = merge($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex], data);
									break;
								case "select":
									if ($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex] == undefined) {
										$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex] = [];
									}
									data.field = $scope.focusedElement.name;
									$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].rows.push(data);
									$scope.uiConfig.gridFieldSelectedOptions[$scope.currentClickedGrid.field.name][$scope.currentClickedGrid.cell.name] = clone(data);
									break;
								case "multiselect":
									if ($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex] == undefined) {
										$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex] = [];
									}
									data.field = $scope.focusedElement.name;
									//console.log(JSON.stringify(data));
									$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].rows.push(data);
									$scope.uiConfig.gridFieldSelectedOptions[$scope.currentClickedGrid.field.name][$scope.currentClickedGrid.cell.name].push(data);
									break;
								case "searchableDropdown":
									if ($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex] == undefined) {
										$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex] = [];
									}
									data.field = $scope.focusedElement.name;
									$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].rows.push(data);
									$scope.uiConfig.gridFieldSelectedOptions[$scope.currentClickedGrid.field.name][$scope.currentClickedGrid.cell.name] = clone(data);
									break;
								case "date":
									if (!$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].hasOwnProperty("originalValues")) {
										$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].originalValues = clone($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex]);
									}
									$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex] = merge($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex], data);
									$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].query = formatDate($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].query, $scope.globalConfig.outputDateFormat, $scope.globalConfig.dateFormat);
									break;
								case "number":
									if (!$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].hasOwnProperty("originalValues")) {
										$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].originalValues = clone($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex]);
									}
									$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex] = merge($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex], data);
									break;
								default:
									if (!$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].hasOwnProperty("originalValues")) {
										$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex].originalValues = clone($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex]);
									}
									$scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex] = merge($scope.formValues[$scope.currentClickedGrid.field.name].rows[rowIndex].data[cellIndex], data);
									break;
							}
						}
					}
					);
				});
				return;
			}

			// currently focused element's type
			switch ($scope.focusedElement.type) {
				case "paragraph":
					if ($scope.formValues[$scope.focusedElement.name] == undefined) {
						$scope.formValues[$scope.focusedElement.name] = {};
					}
					if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
						$scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
					}
					$scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);
					break;
				case "text":
					if ($scope.formValues[$scope.focusedElement.name] == undefined) {
						$scope.formValues[$scope.focusedElement.name] = {};
					}
					if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
						$scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
					}
					$scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);
					break;
				case "select":
					if ($scope.formValues[$scope.focusedElement.name] == undefined) {
						$scope.formValues[$scope.focusedElement.name] = [];
					}
					data.field = $scope.focusedElement.name;
					$scope.formValues[$scope.focusedElement.name].rows.push(data);
					$scope.uiConfig.selectedOptions[$scope.focusedElement.name] = clone(data);
					break;
				case "multiselect":
					if ($scope.formValues[$scope.focusedElement.name] == undefined) {
						$scope.formValues[$scope.focusedElement.name] = [];
					}
					data.field = $scope.focusedElement.name;
					$scope.formValues[$scope.focusedElement.name].rows.push(data);
					$scope.uiConfig.selectedOptions[$scope.focusedElement.name].push(data);
					break;
				case "searchableDropdown":
					if ($scope.formValues[$scope.focusedElement.name] == undefined) {
						$scope.formValues[$scope.focusedElement.name] = [];
					}
					data.field = $scope.focusedElement.name;
					$scope.formValues[$scope.focusedElement.name].rows.push(data);
					$scope.uiConfig.selectedOptions[$scope.focusedElement.name] = clone(data);
					break;
				case "date":
					if ($scope.formValues[$scope.focusedElement.name] == undefined) {
						$scope.formValues[$scope.focusedElement.name] = {};
					}
					if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
						$scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
					}
					$scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);

					$scope.formValues[$scope.focusedElement.name].query = formatDate($scope.formValues[$scope.focusedElement.name].query, $scope.globalConfig.outputDateFormat, $scope.globalConfig.dateFormat);
					break;
				case "number":
					if ($scope.formValues[$scope.focusedElement.name] == undefined) {
						$scope.formValues[$scope.focusedElement.name] = {};
					}
					if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
						$scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
					}
					$scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);
					break;
				default:
					if ($scope.formValues[$scope.focusedElement.name] == undefined) {
						$scope.formValues[$scope.focusedElement.name] = {};
					}
					if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
						$scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
					}
					$scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);
					break;
			}
		});
	};

	$scope.dropdownChangeValue = function (field, id, value, positionField) {
		Object.assign(value.data[positionField].rows, { query: $scope.selectedVal[id] });
		if (!isTestModeEnabled) {
			Appian.Component.saveValue(onChangeLast,
				{
					name: field["name"],
					fieldDetails: field,
					newValue: value.data[positionField].rows
				}
			);
		}
	};

	$scope.dateChangeValue = function (field, value) {
		// If in test mode then nothing to do here
		if (isTestModeEnabled) { return; }

		var fieldName = field.name;

		// Get the updated Value in correct format
		var fieldValue = getFieldValue(field, value);

		// Format the date for Appian
		fieldValue.query = formatDate(fieldValue.query, $scope.globalConfig.dateFormat, $scope.globalConfig.outputDateFormat);
		// Save the value
		Appian.Component.saveValue(onChangeLast, {
			name: fieldName,
			fieldDetails: field,
			newValue: fieldValue
		});
	};

	$scope.initialLoadCasCadingControlsUpdate = function (field, value, formValue, idx, flag) {
		$scope.array = [];

		let valueLength;
		var condnName, condnVal, filterObjVal, filteredObjLength, cascadingMasterListVal;
		if (field.hasOwnProperty('cascadingRule')) {
			fieldRuleLength = field.cascadingRule.length;

			//Multiple Filter Option
			for (var i = 0; i < fieldRuleLength; i++) {

				if (field.cascadingRule[i].hasOwnProperty('cascadingList')) {
					cascadingMasterListVal = $scope.globalCascadingMasterValues[field.cascadingRule[i].cascadingList];
				}

				if (typeof cascadingMasterListVal != "undefined" && field.cascadingRule[i].hasOwnProperty('controls') && field.cascadingRule[i].hasOwnProperty('filters')) {
					valueLength = field.cascadingRule[i].filters.value.length;
					for (var y = 0; y < valueLength; y++) {

						condnName = field.cascadingRule[i].filters.value[y]['column'];
						condnVal = $scope.selectedVal[field.cascadingRule[i].filters.value[y]['control']].query;
						if (y > 0) {
							if (!isObjectEmpty(filterObjVal)) {
								filterObjVal = filterObject(filterObjVal, condnName, condnVal);
							}
							else {
								filterObjVal = filterObject(cascadingMasterListVal, condnName, condnVal);
							}
						}
						else {
							filterObjVal = filterObject(cascadingMasterListVal, condnName, condnVal);
						}
					}

					filteredObjLength = Object.keys(filterObjVal).length;
					if (filteredObjLength > 0) {
						for (var l = 0; l < filteredObjLength; l++) {
							if (typeof filterObjVal[Object.keys(filterObjVal)[l]][field.cascadingRule[i].filters.filterColumn] != "undefined") {
								$scope.array.push(filterObjVal[Object.keys(filterObjVal)[l]][field.cascadingRule[i].filters.filterColumn]);
								if (filteredObjLength - 1 == l) {
									if (flag == "I") {
										$scope.initialLoadUpdateCascadingInDropDown(field, value, formValue, field.cascadingRule[i], $scope.array, idx + 1);
									}
									if (flag == "C") {
										$scope.updateCascadingInDropDown(field, value, formValue, field.cascadingRule[i], $scope.array, idx);
									}
								}
							}
						}
					}
				}
			}
		}
	};

	function isObjectEmpty(obj) { return _.isEmpty(obj); }

	const filterObject = (obj, filter, filterValue) =>
		Object.keys(obj).reduce((acc, val) =>
		(obj[val][filter] === filterValue ?
			{
				...acc,
				[val]: obj[val],
			}
			: acc
		), {});


	$scope.ControlsUpdate = function (field, value, formValue, flag, index) {
		var fieldRuleLength, fielddisableLength, fieldrequiredLength, fieldMasterListLength, fieldvisibilityLength;
		let masterListArr, masterListvalExist, result;
		let disabledArr, disabledvalExist, disabledresult;
		let requiredArr, requiredvalExist, requiredresult;
		let visibilityArr, visibilityvalExist, visibilityresult;
		let styleArr, stylevalExist, styleresult;

		if (field.hasOwnProperty('rule')) {
			fieldRuleLength = field.rule.length;
			for (var i = 0; i < fieldRuleLength; i++) {
				if (flag == "C") {
					if (field.rule[i].hasOwnProperty('masterList')) {
						fieldMasterListLength = field.rule[i].masterList.length;
						for (var m = 0; m < fieldMasterListLength; m++) {
							masterListArr = field.rule[i].masterList[m];
							masterListvalExist = value;
							result = masterListArr.values.includes(masterListvalExist);
							if (result == true) {
								// Update Master list in Dropdown based on rule
								$scope.updateMasterListInDropDown(field, value, formValue, field.rule[i].masterList[m]);
							}
						}
					}
				}

				if (field.rule[i].hasOwnProperty('disabled')) {
					fielddisableLength = field.rule[i].disabled.length;
					for (var d = 0; d < fielddisableLength; d++) {
						disabledArr = field.rule[i].disabled[d];
						disabledvalExist = value;
						disabledresult = disabledArr.values.includes(disabledvalExist);
						if (disabledresult == true) {
							// Runtime Enable/disable controls based on rule
							$scope.dynamicDesignPropertiesControls(field, value, field.rule[i].disabled[d], "disabled");
						}
					}
				}

				if (field.rule[i].hasOwnProperty('required')) {
					fieldrequiredLength = field.rule[i].required.length;
					for (var r = 0; r < fieldrequiredLength; r++) {
						requiredArr = field.rule[i].required[r];
						requiredvalExist = value;
						requiredresult = requiredArr.values.includes(requiredvalExist);
						if (requiredresult == true) {
							// Runtime Change Required feature based on rule
							$scope.dynamicDesignPropertiesControls(field, value, field.rule[i].required[r], "required");
						}
					}
				}

				if (field.rule[i].hasOwnProperty('visibility')) {
					fieldvisibilityLength = field.rule[i].visibility.length;
					for (var v = 0; v < fieldvisibilityLength; v++) {
						visibilityArr = field.rule[i].visibility[v];
						visibilityvalExist = value;
						visibilityresult = visibilityArr.values.includes(visibilityvalExist);
						if (visibilityresult == true) {
							// Runtime Change Visibility feature based on rule
							$scope.dynamicDesignPropertiesControls(field, value, field.rule[i].visibility[v], "visibility");
						}
					}
				}

				if (field.rule[i].hasOwnProperty('style')) {
					fieldvisibilityLength = field.rule[i].style.length;
					for (var s = 0; s < fieldvisibilityLength; s++) {
						styleArr = field.rule[i].style[s];
						stylevalExist = value;
						styleresult = styleArr.values.includes(stylevalExist);
						if (styleresult == true) {
							// Runtime Change style feature based on rule
							$scope.dynamicDesignPropertiesControls(field, value, field.rule[i].style[s], "style");
						}
					}
				}
			}
		}

		if (flag == "I" && $scope.buttonClicked == false) {
			if (field.hasOwnProperty('cascadingRule')) {
				$scope.initialLoadCasCadingControlsUpdate(field, value, formValue, index, flag);
			}
		}
		if (flag == "C" && typeof value != "undefined" && value != null && !value.toString().toLowerCase().includes('select')) {//if (typeof value == "undefined" && value == null && value.toString().toLowerCase().includes('select')) {
			if (field.hasOwnProperty('cascadingRule')) {
				$scope.initialLoadCasCadingControlsUpdate(field, value, formValue, index, flag);
			}
		}
	};

	$scope.saveInputTypeValue = function (field, value) {
		// Validate Inputs
		if (typeof field == "undefined" || field == null) { return; }
		// Reset value to blank string if not found
		if (typeof value == "undefined" || value == null) { value = ""; }

		// Specific Code for Select/Multiselect 
		if (field.type == "select" || field.type == "multiselect") {
			if (field.hasOwnProperty('cascadingRule') && field.cascadingRule.length > 0 && field.cascadingRule[0].controls.hasOwnProperty('resetControl')) {
				$scope.resetDropDownCtrl(field.cascadingRule[0], "R");
			}

			if (!field.hasOwnProperty("placeholder") || (field.hasOwnProperty("placeholder") && (field.placeholder == null || field.placeholder == ""))) {
				if (typeof value == "undefined" || value == null || value.toString().toLowerCase().includes('select')) {

					$scope.resetDropDownCtrl(field.cascadingRule[0].controls.controlName, "P");
					$scope.formValues[field.name].rows[0].query = "";
				}
				else {
					$scope.formValues[field.name].rows[0].query = value;
				}

				value = $scope.formValues[field.name].rows[0];
				$scope.isValueChangedInLastFocusedElement = true;
			}
			else {
				$scope.formValues[field.name].rows[0].query = value;
				value = $scope.formValues[field.name].rows[0];
				$scope.isValueChangedInLastFocusedElement = true;
			}
		}
		// General Code continues
		if ($scope.isValueChangedInLastFocusedElement) {
			$scope.isValueChangedInLastFocusedElement = false;

			// Get the updated Value in correct format
			var fieldValue = getFieldValue(field, value);

			if (!isTestModeEnabled) {
				if (field.type == "search") {
					Appian.Component.saveValue(onSearch, fieldValue);
				}
				else {
					// If field type is date then format the date
					if (field.type == "date") {
						// Format the date for Appian
						fieldValue.query = formatDate(fieldValue.query, $scope.globalConfig.dateFormat, $scope.globalConfig.outputDateFormat);
					}

					// Save the value
					Appian.Component.saveValue(onChangeLast, {
						name: field.name,
						fieldDetails: field,
						newValue: fieldValue
					});
				}
				Appian.Component.saveValue(onChange, $scope.formValues);
			}
		}

		// Process Rules specified for the control. Values are compared to the data displayed on the control
		$scope.processRules(field, value);
	};

	// watcher on selectedOptions, as soon as the value is changed in any select type field, it will update the isSelected field on the JSON Object.
	$scope.$watch("uiConfig.selectedOptions", function (newValue, oldValue) {
		if (_.isEqual(newValue, oldValue)) { return; }

		console.log("$watch => uiConfig.selectedOptions\nNew:", newValue, "\nOld:", oldValue);

		Object.keys(newValue).forEach(function (eachKey) {
			$scope.formValues[eachKey].rows.forEach(function (eachValueInForm) {
				if (Array.isArray(newValue[eachKey])) {
					newValue[eachKey].forEach(function (eachSelectedValue) {
						if (_.isEqual(eachSelectedValue, eachValueInForm)) {
							eachValueInForm.isSelected = true;
						}
						else {
							eachValueInForm.isSelected = false;
						}
					});
				}
				else {
					if (_.isEqual(newValue[eachKey], eachValueInForm)) {
						eachValueInForm.isSelected = true;
					}
					else {
						eachValueInForm.isSelected = false;
					}
				}
			});
		});
	}, true);

	// watcher on grid selectedOptions, as soon as the value is changed in any select type field, it will update the isSelected field on the JSON Object.
	$scope.$watch("uiConfig.gridFieldSelectedOptions", function (newValue, oldValue) {
		if (_.isEqual(newValue, oldValue)) { return; }

		Object.keys(newValue).forEach(function (eachGridName) {
			$scope.formValues[eachGridName].rows.forEach(function (eachGridRow) {
				eachGridRow.data.forEach(function (eachCellData) {
					Object.keys(newValue[eachGridName]).forEach(function (eachCellName) {
						if (eachCellData.name == eachCellName && (eachCellData.type == "select" || eachCellData.type == "multiselect")) {
							eachCellData.rows.forEach(function (eachDropdownRow) {
								eachDropdownRow.isSelected = false;
							});

							if (Array.isArray(newValue[eachGridName][eachCellName])) {
								newValue[eachGridName][eachCellName].forEach(function (eachSelectedValue) {
									eachCellData.rows.forEach(function (eachDropdownRow) {
										if (_.isEqual(eachSelectedValue, eachDropdownRow)) {
											eachDropdownRow.isSelected = true;
										}
									});
								});
							} else {
								eachCellData.rows.forEach(function (eachDropdownRow) {
									if (_.isEqual(eachSelectedValue, eachDropdownRow)) {
										eachDropdownRow.isSelected = true;
									}
								});
							}
						}
					});
				});
			});
		});
	}, true);

	// This function is a parent function which invokes viewer.html's showRectangleByCoordinates (showHighlight) to highlight the text in the PDF.
	function highlightTextInPdf(searchObj, config) {
		if (searchObj.query == undefined || searchObj.query == null) {
			return;
		}

		var objectToSearch = clone(searchObj);

		objectToSearch.query = objectToSearch.query.toString();
		objectToSearch.coords = {
			"xMin": objectToSearch.xMin,
			"yMin": objectToSearch.yMin,
			"xMax": objectToSearch.xMax,
			"yMax": objectToSearch.yMax
		};

		if (plugInData.config.clearCanvasBeforeHighlighting != false) {
			clearOldRectangles();
		}

		if (config.phraseSearch == false) {
			// search specific coordinates
			var objToSearch = {
				pageNumber: objectToSearch.pageNumber,
				coords: objectToSearch.coords,
				query: objectToSearch.query,
				origin: objectToSearch.origin
			};

			//objToSearch
			showRectangleByCoordinates(objToSearch);
		}
		else {
			// general search without coordinates
			if (objectToSearch === undefined || objectToSearch === null || objectToSearch.query == undefined || objectToSearch.query == null) {
				return;
			}

			var findEvent = "find";

			if (config.highlightAll == true)
				findEvent = "findhighlightallchange";

			if (config.caseSensitive == true)
				findEvent = "findcasesensitivitychange";

			if (config.entireWord == true)
				findEvent = "findentirewordchange";

			PDFViewerApplication.findController.executeCommand(findEvent, {
				query: objectToSearch.query,
				phraseSearch: config.phraseSearch,
				caseSensitive: config.caseSensitive,
				entireWord: config.entireWord,
				highlightAll: config.highlightAll,
				findPrevious: config.findPrevious
			});
		}
	}

	function getBase64(blob) {
		var reader = new FileReader();
		reader.onload = function () {
			var base64data = reader.result;
			openBase64Pdf(base64data.split("data:application/pdf;base64,")[1]);
		};
		reader.readAsDataURL(blob);
	}

	function getDocumentFromWeb(options) {
		const xhttp = new XMLHttpRequest();
		xhttp.onload = function () {
			getBase64(this.response);
		};
		xhttp.withCredentials = true;
		xhttp.open("GET", options, true);
		xhttp.responseType = "blob";
		xhttp.send();
	}

	function checkAndUpdateSingleFieldObject(fieldName, field) {
		//
		if ($scope.updateFromObject != undefined && $scope.updateFromObject != null && $scope.updateFromObject.name != undefined && $scope.updateFromObject.name != null) {
			if ($scope.updateFromObject.name == fieldName) {
				if (!_.isEqual($scope.oldFormObjectData, $scope.updateFromObject)) {
					return $scope.updateFromObject;
				}
			}
		}
		return field;
	}

	function convertGridFieldsInRequiredFormat(gridFields) {
		gridFields.forEach(function (eachRow) {
			eachRow.data.forEach(function (eachCell) {
				if (eachCell.type == "date") {
					eachCell.query = formatDate(eachCell.query, $scope.globalConfig.outputDateFormat, $scope.globalConfig.dateFormat);
				}
			});
		});
	}

	/*
	 * function is called from sanitizeInput function,
	 * this function handles the Appian input by mapping and segregating the data of each and every field in the required local variables.
	 */
	function sanitizeField(field, previouslySelected, inputs) {
		// create a watcher on each field separately, so that any change in the field will invoke the onChangeLast variable.
		$scope.$watch("formValues." + field["name"], function (newValue, oldValue) {
			if (_.isEqual(newValue, oldValue)) { return; }

			$scope.isValueChangedInLastFocusedElement = true;

			if (field.type == "date") {
				newValue = formatDate(newValue.query, $scope.globalConfig.outputDateFormat, $scope.globalConfig.dateFormat);
			}

			// Update The Layout of the field
			$scope.updateLayout(field);
		}, true);

		previouslySelected[field.name] = [];

		if (inputs.formValues[field.name] == null || inputs.formValues[field.name] == undefined) { return; }

		if (Array.isArray(inputs.formValues[field.name]) && (inputs.formValues[field.name].length == 0 || inputs.formValues[field.name].length == undefined)) { return; }
		switch (field.type) {
			case "search": break;
			case "button-group": break;
			case "_": break;
			case "grid": break;
			case "label": break;
			case "button": break;
			case "text": break;
			case "paragraph": break;
			case "currency": break;
			case "number":
				try {
					console.log("numbers", field.name);
					var value = inputs.formValues[field.name].query + '';
					inputs.formValues[field.name].query = value.indexOf(".") > -1 ? parseFloat(value) : parseInt(value);
				} catch (e) { console.log("Error:", e); }
				break;
			case "date":
				try { inputs.formValues[field.name].query = formatDate(inputs.formValues[field.name].query, $scope.globalConfig.outputDateFormat, $scope.globalConfig.dateFormat); }
				catch (e) { console.log(e); }
				break;
			case "select":
				$scope.uiConfig.selectedOptions[field.name] = {};
				updateSelectedOptionsArray(field, inputs.formValues[field.name].rows);
				break;
			case "multiselect":
				$scope.uiConfig.selectedOptions[field.name] = [];
				updateSelectedOptionsArray(field, inputs.formValues[field.name].rows);
				// setting 10 ms to time so multiselect can load properly
				setTimeout(function () {
					$("#" + field.name).change(function () {
						// Get newly selected elements
						var currentlySelected = $(this).val();
						var newSelections = currentlySelected.filter(function (element) {
							return previouslySelected[field.name].indexOf(element) == -1;
						});
						previouslySelected[field.name] = currentlySelected;
						if (newSelections.length) {
							// If there are multiple new selections, we'll take the last in the list
							$scope.lastSelected[field.name] = newSelections.reverse()[0];
						}
						clearOldRectangles();
						$scope.uiConfig.selectedOptions[field.name].forEach(function (x) {
							if ($scope.lastSelected[field.name] == x["$$hashKey"]) {
								setTimeout(function () {
									highlightTextInPdf(x, { clearCanvasBeforeHighlighting: false, phraseSearch: false });
								}, 10);
							}
						});
					});
				}, 10);
				break;
			default:
				break;
		}
	}

	// this function updates the "$scope.uiConfig.selectedOptions" global variable to handle all the select/multiselect type fields and values.
	function updateSelectedOptionsArray(field, values) {
		if (!Array.isArray(values)) {
			console.error("updateSelectedOptionsArray failed as 'values' in not an array");
		}
		else {
			values.forEach(function (eachValue) {
				if (eachValue.hasOwnProperty("isSelected") && eachValue.isSelected == true) {
					if (field.type == "multiselect") {
						$scope.uiConfig.selectedOptions[field.name].push(eachValue);
					}
					else {
						if (field.type == "select" || field.type == "searchableDropdown") {
							$scope.uiConfig.selectedOptions[field.name] = eachValue;
						}
					}
					if ($scope.dropDownValues.hasOwnProperty($scope.masterListElement[field.name]) != true) {
						$scope.selectedVal[field.name] = eachValue;
					}
				}
				else {
					eachValue.isSelected = false;
				}
			});
		}
	}

	function openPdf(file) {
		PDFViewerApplication.open(file);
	}

	function openBase64Pdf(file) {
		// Base64 String from response shortened
		var pdfData = base64ToUint8Array(file);
		openPdf(pdfData);

		function base64ToUint8Array(base64) {
			var raw = atob(base64);
			var uint8Array = new Uint8Array(raw.length);
			for (var i = 0; i < raw.length; i++) {
				uint8Array[i] = raw.charCodeAt(i);
			}
			return uint8Array;
		}
	}

	// Adjust the plug-in in Appian's available window
	function adjustHeightOfIframe(height) {
		document.getElementById("pdfViewerParent").style.height = height;
		document.getElementById("pdf-js-viewer").setAttribute("height", height.split("px")[0]);

		document.getElementById("dynamic-form").style.height = height;

		/* Set the height of the tab-content page to height - height of tab area */
		var tabHeight = $("ul.nav-tabs").height();
		var tabPaneHeight = height.split("px")[0] - tabHeight;
		$("div.tab-content").height(tabPaneHeight).css("overflow-y", "auto");
	}

	window.getIframeSize = function () {
		adjustHeightOfIframe(iframeHeight, iframeWidth);
		return { iframeHeight: iframeHeight.split("px")[0], iframeWidth: iframeWidth };
	};

	window.getConfig = function () { return plugInData.config; };

	// JSON Deep Clone an Object
	function clone(obj) {
		var regExp = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
		return JSON.parse(JSON.stringify(obj), function (k, v) {
			return typeof v === "string" && regExp.test(v) ? new Date(v) : v;
		});
	}

	// Extracts the button class from style.fieldClass
	$scope.getButtonClass = function (field, index) {
		if (!field) { return ""; }

		if (field.hasOwnProperty("style") && field.style.hasOwnProperty("fieldClass")) {
			return Array.isArray(field.style.fieldClass) ? field.style.fieldClass[index] : field.style.fieldClass;
		}
		return "";
	};

	// global function to check if any field has error or not like, required.
	function validateRegexValidations(field, value) {
		if (!(field.hasOwnProperty("validations") && Array.isArray(field.validations) && field.validations.length > 0)) {
			return {
				invalid: false,
				message: ""
			};
		}

		if (value == undefined || value.query == undefined) {
			return {
				invalid: false,
				message: ""
			};
		}

		return {
			invalid: false,
			message: ""
		};
	}

	$rootScope.checkIfFieldValidationError = function (field, data) {
		var err;
		if (data == null || data == undefined) {
			err = {
				invalid: true,
				message: "Value can not be blank for " + field.label
			};
			$scope.formValidationErrors[field.name] = err;
			return err;
		}

		if (field.required) {
			if ($scope.uiConfig.supportedWebFields.inputTypes.indexOf(field.type) > -1 && (data.query == null || data.query == undefined || data.query == "")) {
				err = {
					invalid: true,
					message: "Value can not be blank for " + field.label
				};

				$scope.formValidationErrors[field.name] = err;
				return err;
			}

			if (field.type == "select" || field.type == "searchableDropdown") {
				if (typeof $scope.uiConfig.selectedOptions[field.name] == "undefined" || $scope.uiConfig.selectedOptions[field.name].query == undefined) {
					err = {
						invalid: true,
						message: "Select 1 value for " + field.label
					};
					$scope.formValidationErrors[field.name] = err;
					return err;
				}
			}
			if (field.type == "multiselect") {
				if ($scope.uiConfig.selectedOptions[field.name].length == 0) {
					err = {
						invalid: true,
						message: "Select at least 1 value for " + field.label
					};
					$scope.formValidationErrors[field.name] = err;
					return err;
				}
			}
		}
		return validateRegexValidations(field, data);
	};

	// set the section's glypihcons beside the Label when collapsed and expanded.
	$(function () {
		$('a[data-toggle="tab"]').on("shown.bs.tab", function (e) {
			e.preventDefault();
			var newTabName = $(e.target).attr("href").replace("#", "");
			var previousTabName = $(e.relatedTarget).attr("href").replace("#", "");

			/* Raise the Appian event if not in test mode */
			if (!isTestModeEnabled) {
				Appian.Component.saveValue(onTabChange, { previousTab: previousTabName, newTab: newTabName });
			};
		});
		setTimeout(function () { $('[data-toggle="tooltip"]').tooltip({ html: true }); }, 5000);
	});

	// Merge two JSON Objects
	var merge = function () {
		var obj = {}, i = 0, il = arguments.length, key;
		for (; i < il; i++) {
			for (key in arguments[i]) {
				if (arguments[i].hasOwnProperty(key)) {
					obj[key] = arguments[i][key];
				}
			}
		}
		return obj;
	};

	$scope.dynamicDesignPropertiesControls = function (field, value, fieldCtrl, flagProperties) {
		let ctrlPropertiesLength;
		ctrlPropertiesLength = fieldCtrl.controls.length;
		for (var p = 0; p < ctrlPropertiesLength; p++) {
			if (flagProperties == 'disabled') {
				$scope.disableCtrl[fieldCtrl.controls[p]] = fieldCtrl.name;
			}
			if (flagProperties == 'required') {
				$scope.requiredCtrl[fieldCtrl.controls[p]] = fieldCtrl.name;
			}

			if (flagProperties == 'visibility') {
				var flag = (fieldCtrl.name) ? false : true;
				$scope.visibilityCtrl[fieldCtrl.controls[p]] = flag;
			}
			if (flagProperties == 'style') {
				var fieldObject = $("#" + fieldCtrl.controls[p]);
				if (fieldObject.length > 0) {
					fieldObject.attr("style", fieldCtrl.styleProperties);
				}
				if (fieldCtrl.styleProperties.includes('display:none')) {
					$scope.visibilityCtrl[fieldCtrl.controls[p]] = false;
				}
				if (fieldCtrl.styleProperties.includes('display:initial') || fieldCtrl.styleProperties.includes('display:block')) {
					$scope.visibilityCtrl[fieldCtrl.controls[p]] = true;
				}
			}
		}
	};

	$scope.initializeSelect = function (field, fieldName, indexVal) {
		if (field.type != "select" && field.type != "multiselect") { return true; }

		var placeholderText = "-- Select --";

		// Get the list of options
		var optionList = $scope.prepareOptionLists(field);

		// set displayText and values
		var displayTexts = optionList.texts;
		var displayValues = optionList.values;

		if (field.hasOwnProperty("placeholder") && field.placeholder != null) {
			placeholderText = field.placeholder;
		}

		displayTexts = [placeholderText].concat(displayTexts);
		displayValues = [""].concat(displayValues);

		if (field.type == "select") {
			$scope.bindSelect(displayTexts, displayValues, indexVal, field);
		}
		else if (field.type == "multiselect") {
			$scope.bindMultiselect(displayTexts, displayValues, indexVal, field);
		}

		return true;
	};

	$scope.bindSelect = function (displayTexts, displayValues, index, field) {
		var selectedValue = displayValues[0];
		var pageNumber = 0;
		var origin = 0;
		var xMin = 0;
		var xMax = 0;
		var yMin = 0;
		var yMax = 0;
		var fieldName = field.name;
		var elementId = fieldName + "_" + index;

		var dropDownVal = {};
		/* Get Parameters of selected value */
		if (field.hasOwnProperty('rows') && field.rows[0].hasOwnProperty('isSelected')) {
			var row = field.rows[0];

			if (displayValues.indexOf(row.query) > -1 && row.isSelected) {
				selectedValue = row.query;
				pageNumber = row.pageNumber;
				origin = row.origin;
				xMin = row.xMin;
				xMax = row.xMax;
				yMin = row.yMin;
				yMax = row.yMax;
			}
		}

		// Get the old selected value from the model container
		if (typeof $scope.selectedVal[fieldName] !== 'undefined' && $scope.selectedVal[fieldName] != null) {
			selectedValue = $scope.selectedVal[fieldName];
		}

		/* Backward Compatibility code. DO NOT CHANGE
		 * START
		 * */
		if (typeof selectedValue === 'undefined' || selectedValue == null) {
			selectedValue = $scope.uiConfig.selectedOptions[field.name];
		}
		/* Backward Compatibility code. DO NOT CHANGE
		 * END
		 * */

		var listLength = displayTexts.length;
		// Loop on all the display texts
		for (var i = 0; i < listLength; i++) {
			// Set the value in array
			dropDownVal[i] = {
				query: displayTexts[i],
				value: displayValues[i],
				pagenumber: pageNumber,
				orgin: origin,
				xMin: xMin,
				xMax: xMax,
				yMin: yMin,
				yMax: yMax
			};
		}
		if ($scope.initialLoadCasCadingDropDownValues[fieldName] === 'undefined' || $scope.initialLoadCasCadingDropDownValues[fieldName] == null) {
			$scope.dropDownValues[elementId] = dropDownVal;
			$scope.masterListElement[fieldName] = elementId;
		}
		else {
			$scope.dropDownValues[elementId] = $scope.initialLoadCasCadingDropDownValues[fieldName];
			$scope.masterListElement[fieldName] = elementId;
		}
	};

	$scope.bindMultiselect = function (displayTexts, displayValues, index, field) {
		var selectedValue = [];
		var query = [];
		var pageNumber = 0;
		var origin = 0;
		var xMin = 0;
		var xMax = 0;
		var yMin = 0;
		var yMax = 0;
		var fieldName = field.name;
		var elementId = fieldName + "_" + index;

		var dropDownVal = {};

		var counter;
		/* Get Parameters of selected value */
		if (field.hasOwnProperty("rows")) {
			for (counter = 0; counter < field.rows.length; counter++) {
				var row = field.rows[counter];

				if (displayValues.indexOf(row.query) > -1 && row.hasOwnProperty("isSelected") && row.isSelected) {
					query.push(
						{
							query: row.query,
							selectedValue: row.query,
							pageNumber: row.pageNumber,
							origin: row.origin,
							xMin: row.xMin,
							xMax: row.xMax,
							yMin: row.yMin,
							yMax: row.yMax
						}
					);
				}
			}
		}

		/* Backward Compatibility code. DO NOT CHANGE
		 * START
		 * */
		for (counter = 0; counter < query.length; counter++) {
			selectedValue.push(query[counter].query);
		}

		if (query.length == 0) {
			var values = $scope.uiConfig.selectedOptions[field.name];

			for (counter = 0; counter < values.length; counter++) {
				selectedValue.push(values[counter].query);
			}
		}

		/* Backward Compatibility code. DO NOT CHANGE
		 * END
		 * */
		$scope.selectedVal[fieldName] = selectedValue;

		for (var i = 0; i < displayTexts.length; i++) {
			dropDownVal[i] = {
				query: displayTexts[i],
				value: displayValues[i],
				pagenumber: pageNumber,
				orgin: origin,
				xMin: xMin,
				xMax: xMax,
				yMin: yMin,
				yMax: yMax
			};
		}

		$scope.dropDownValues[elementId] = dropDownVal;
		$scope.masterListElement[fieldName] = elementId;
	};

	$scope.isValueSelected = function (value, valueToCheckAgainst) {
		if (typeof valueToCheckAgainst == "undefined" || valueToCheckAgainst == null) {
			return false;
		}
		if (typeof value == "undefined" || value == null) {
			return false;
		}
		if (typeof value == "object") { value = value.query; }
		if (typeof value == "undefined" || value == null) {
			return false;
		}

		return value.toString().toLowerCase() == valueToCheckAgainst.toString().toLowerCase();
	};

	$scope.updateLayout = function (field) {
		var fieldName = field["name"];

		/* if the old layout is available */
		if ($scope.layoutDetails[fieldName] != undefined && $scope.oldLayoutDetails[fieldName] != null) {
			/* Check if there is any change in the desired properties of the field
			 * If Yes then continue execution
			 * If No then return
			 */
			if ($scope.hasFieldChanged($scope.oldLayoutDetails[fieldName], $scope.layoutDetails[fieldName]) == false) {
				return true;
			}
		}
		console.log("$scope.updateLayout\n", field);
		// The field has changed, use the values from new layout details
		field = $scope.layoutDetails[fieldName];

		// create jQuery Object with field
		var fieldObject = getJQueryControl(fieldName);

		if (fieldObject.length > 0) {
			fieldObject.attr("ng-disabled", field["disabled"]);
			fieldObject.attr("ng-required", field["required"]);
			fieldObject.attr("ng-style", field["style"]["fieldClass"]);
			fieldObject.attr("ng-class", field["style"]["style"]);
		}
	};

	// This function converts back the field:Object structure to Appian's array structure
	function convertObjectToAppianArray(data) {
		var arr = [];

		Object.keys(data).forEach(function (each) {
			if (Array.isArray(data[each])) {
				for (var i = data[each].length - 1; i >= 0; i--) {
					arr.push(data[each][i]);
				}
			}
			else {
				arr.push(data[each]);
			}
		});

		return arr;
	}

	$scope.initialLoadUpdateCascadingInDropDown = function (field, value, formVal, fieldControl, arrCascad, index) {
		console.log("initialLoadUpdateCascadingInDropDown", field);

		var fieldName = fieldControl.controls.controlName;
		var dropDownVal = {};
		var displayTexts = [];
		var displayValues = [];
		var placeholderAppendText = [];
		var placeholderAppendValue = [];
		var placeholderText = "--Select--";

		// Create element Id
		if (typeof oldMasterData == "undefined" || oldMasterData == null) {
			var elementId = fieldName + "_" + index;
		} else {
			var tempList = oldMasterData.split("_");
			fieldIndex = tempList[tempList.length - 1];
			var elementId = fieldName + "_" + fieldIndex;
		}

		// // Check if Separate Text and Values are given
		// // If text is present in the master list then use it
		displayTexts = $scope.globalMasterValues[fieldControl.controls.masterList].text;

		if (typeof displayTexts == "undefined" || displayTexts == null) {

			displayTexts = $scope.globalMasterValues[fieldControl.controls.masterList];
			displayValues = $scope.globalMasterValues[fieldControl.controls.masterList];
			if (arrCascad.length > 0) {
				displayTexts = convertObjectToAppianArray(arrCascad);
				displayValues = convertObjectToAppianArray(arrCascad);
			}
		}
		else {
			displayTexts = $scope.globalMasterValues[field.masterListValue].text;
			displayValues = $scope.globalMasterValues[field.masterListValue].value;
			/* Check if text and values, both arrays have same length */
			if (displayTexts.length !== displayValues.length) {
				var err = {
					invalid: true,
					message: "text & value length mismatch in given master list : " + field.masterListValue
				};
				$scope.formValidationErrors[field[fieldIndex]] = err;
				return err;
			}
		}

		if (field.hasOwnProperty("placeholder") && field.placeholder != null && field.placeholder != "") {
			placeholderAppendText = [field.placeholder].concat(displayTexts);
			placeholderAppendValue = [""].concat(displayValues);
			displayValues = placeholderAppendValue;
			displayTexts = placeholderAppendText;
		}
		else {
			placeholderAppendText = [placeholderText].concat(displayTexts);
			placeholderAppendValue = [""].concat(displayValues);
			displayValues = placeholderAppendValue;
			displayTexts = placeholderAppendText;
		}

		if (fieldControl.hasOwnProperty('selectedVal') && fieldControl.selectedVal != null) {
			var selectedValue = fieldControl.selectedVal;
			var query = fieldControl.selectedVal;
			var pageNumber = 0;
			var origin = 0;
			var xMin = 0;
			var xMax = 0;
			var yMin = 0;
			var yMax = 0;
		}
		else {
			var selectedValue = formVal[fieldControl.controls.controlName].rows[0].query;
			var query = formVal[fieldControl.controls.controlName].rows[0].query;
			var pageNumber = 0;
			var origin = 0;
			var xMin = 0;
			var xMax = 0;
			var yMin = 0;
			var yMax = 0;
		}
		// //Get the old selected value from the model container
		if (typeof $scope.selectedVal[fieldName] !== 'undefined' && $scope.selectedVal[fieldName] != null) {
			$scope.selectedVal[fieldName].query = selectedValue;
		}

		/* Backward Compatibility code. DO NOT CHANGE
		 * START
		 * */
		if (typeof query === 'undefined' || query == null) {
			selectedValue = $scope.uiConfig.selectedOptions[field.name].query;
			// Set the value in model
			$scope.selectedVal[fieldName].query = selectedValue;
		}
		/* Backward Compatibility code. DO NOT CHANGE
		 * END
		 * */

		for (var i = 0; i < displayTexts.length; i++) {
			dropDownVal[i] = {
				query: displayTexts[i],
				value: displayValues[i],
				pagenumber: pageNumber,
				orgin: origin,
				xMin: xMin,
				xMax: xMax,
				yMin: yMin,
				yMax: yMax
			};
		}

		$scope.initialLoadCasCadingDropDownValues[fieldName] = dropDownVal;

		$scope.dropDownValues[elementId] = dropDownVal;
		$scope.masterListElement[fieldName] = elementId;

		return true;
	};

	$scope.isInArray = function (value, array) {
		return array.indexOf(value) > -1;
	};

	$scope.updateCascadingInDropDown = function (field, value, formVal, fieldControl, arrCascad) {
		console.log("updateCascadingInDropDown", field);

		var fieldName = fieldControl.controls.controlName;
		var dropDownVal = {};
		var displayTexts = [];
		var displayValues = [];
		var placeholderAppendText = [];
		var placeholderAppendValue = [];
		var placeholderText = "--Select--";

		/* Find Old Index */
		var oldMasterData = $scope.masterListElement[fieldName];
		var tempList = oldMasterData.split("_");
		fieldIndex = tempList[tempList.length - 1];
		var elementId = fieldName + "_" + fieldIndex;

		displayTexts = $scope.globalMasterValues[fieldControl.controls.masterList].text;

		if (typeof displayTexts == "undefined" || displayTexts == null) {

			displayTexts = $scope.globalMasterValues[fieldControl.controls.masterList];
			displayValues = $scope.globalMasterValues[fieldControl.controls.masterList];
			if (arrCascad.length > 0) {
				displayTexts = convertObjectToAppianArray(arrCascad);
				displayValues = convertObjectToAppianArray(arrCascad);
			}
		}
		else {
			displayTexts = $scope.globalMasterValues[field.masterListValue].text;
			displayValues = $scope.globalMasterValues[field.masterListValue].value;
			/* Check if text and values, both arrays have same length */
			if (displayTexts.length !== displayValues.length) {
				var err = {
					invalid: true,
					message: "text & value length mismatch in given master list : " + field.masterListValue
				};
				$scope.formValidationErrors[field[fieldIndex]] = err;
				return err;
			}
		}

		if (field.hasOwnProperty("placeholder") && field.placeholder != null && field.placeholder != "") {
			placeholderAppendText = [field.placeholder].concat(displayTexts);
			placeholderAppendValue = [""].concat(displayValues);
			displayValues = placeholderAppendValue;
			displayTexts = placeholderAppendText;
		}
		else {
			placeholderAppendText = [placeholderText].concat(displayTexts);
			placeholderAppendValue = [""].concat(displayValues);
			displayValues = placeholderAppendValue;
			displayTexts = placeholderAppendText;
		}

		if (fieldControl.hasOwnProperty('selectedVal') && fieldControl.selectedVal != null) {
			var selectedValue = fieldControl.selectedVal;
			var query = fieldControl.selectedVal;
			var pageNumber = 0;
			var origin = 0;
			var xMin = 0;
			var xMax = 0;
			var yMin = 0;
			var yMax = 0;
		} else {
			var selectedValue;
			var query;
			var pageNumber = 0;
			var origin = 0;
			var xMin = 0;
			var xMax = 0;
			var yMin = 0;
			var yMax = 0;
		}

		//Get the old selected value from the model container
		if (typeof $scope.selectedVal[fieldName] !== 'undefined' && $scope.selectedVal[fieldName] != null) {
			$scope.selectedVal[fieldName].query = selectedValue;
		}

		/* Backward Compatibility code. DO NOT CHANGE
		 * START
		 * */
		if (typeof query === 'undefined' || query == null) {
			selectedValue = $scope.uiConfig.selectedOptions[field.name].query;
			// Set the value in model
			$scope.selectedVal[fieldName].query = selectedValue;
		}
		/* Backward Compatibility code. DO NOT CHANGE
		 * END
		 * */

		for (var i = 0; i < displayTexts.length; i++) {
			if (i === 0) {
				selectedValue = true;
				$scope.selectedVal[fieldName].query = displayValues[i];
			}
			else {
				selectedValue = false;
			}

			dropDownVal[i] = {
				query: displayTexts[i],
				value: displayValues[i],
				pagenumber: pageNumber,
				orgin: origin,
				xMin: xMin,
				xMax: xMax,
				yMin: yMin,
				yMax: yMax
			};
		}

		$scope.dropDownValues[elementId] = dropDownVal;
		$scope.masterListElement[fieldName] = elementId;
		return true;
	};

	$scope.updateMasterListInDropDown = function (field, value, formVal, fieldControl) {
		var ctrlLength = fieldControl.controls.length;
		for (var c = 0; c < ctrlLength; c++) {

			var fieldName = fieldControl.controls[c]; //field.name;
			var dropDownVal = {};
			var displayTexts = [];
			var displayValues = [];
			var placeholderAppendText = [];
			var placeholderAppendValue = [];
			var placeholderText = "--Select--";

			/* Find Old Index */
			var oldMasterData = $scope.masterListElement[fieldName];
			var tempList = oldMasterData.split("_");
			var fieldIndex = tempList[tempList.length - 1];
			// Create element Id
			var elementId = fieldName + "_" + fieldIndex;

			// No Master List Given */
			if (field.type == "select") { if (typeof field.masterListValue == "undefined") { return true; } }
			// Check if Separate Text and Values are given
			// If text is present in the master list then use it

			displayTexts = $scope.globalMasterValues[fieldControl.name].text;
			if (typeof displayTexts == "undefined" || displayTexts == null) {
				displayTexts = $scope.globalMasterValues[fieldControl.name];
				displayValues = $scope.globalMasterValues[fieldControl.name];
			}
			else {
				displayTexts = $scope.globalMasterValues[field.masterListValue].text;
				displayValues = $scope.globalMasterValues[field.masterListValue].value;
				/* Check if text and values, both arrays have same length */
				if (displayTexts.length !== displayValues.length) {
					var err = {
						invalid: true,
						message: "text & value length mismatch in given master list : " + field.masterListValue
					};
					$scope.formValidationErrors[field[fieldIndex]] = err;
					return err;
				}
			}

			if (field.hasOwnProperty("placeholder") && field.placeholder != null && field.placeholder != "") {
				placeholderAppendText = [field.placeholder].concat(displayTexts);
				placeholderAppendValue = [""].concat(displayValues);
				displayValues = placeholderAppendValue;
				displayTexts = placeholderAppendText;
			}
			else {
				placeholderAppendText = [placeholderText].concat(displayTexts);
				placeholderAppendValue = [""].concat(displayValues);
				displayValues = placeholderAppendValue;
				displayTexts = placeholderAppendText;
			}

			if (fieldControl.hasOwnProperty('selectedVal') && fieldControl.selectedVal != null) {
				var selectedValue = fieldControl.selectedVal;
				var query = fieldControl.selectedVal;
				var pageNumber = 0;
				var origin = 0;
				var xMin = 0;
				var xMax = 0;
				var yMin = 0;
				var yMax = 0;
			}
			else {
				var selectedValue = formVal[fieldControl.controls[c]].rows[0].query;
				var query = formVal[fieldControl.controls[c]].rows[0].query;
				var pageNumber = 0;
				var origin = 0;
				var xMin = 0;
				var xMax = 0;
				var yMin = 0;
				var yMax = 0;
			}
			// //Get the old selected value from the model container
			if (typeof $scope.selectedVal[fieldName] !== 'undefined' && $scope.selectedVal[fieldName] != null) {
				$scope.selectedVal[fieldName].query = selectedValue;
			}

			/* Backward Compatibility code. DO NOT CHANGE
			 * START
			 * */
			if (typeof query === 'undefined' || query == null) {
				selectedValue = $scope.uiConfig.selectedOptions[field.name].query;
				// Set the value in model
				$scope.selectedVal[fieldName].query = selectedValue;
			}
			/* Backward Compatibility code. DO NOT CHANGE
			 * END
			 * */
			for (var i = 0; i < displayTexts.length; i++) {
				if (i == 0) {
					selectedValue = true;
					$scope.selectedVal[fieldName].query = displayValues[i];
				}
				else {
					selectedValue = false;
				}

				dropDownVal[i] = {
					query: displayTexts[i],
					value: displayValues[i],
					pagenumber: pageNumber,
					orgin: origin,
					xMin: xMin,
					xMax: xMax,
					yMin: yMin,
					yMax: yMax
				};
			}

			$scope.dropDownValues[elementId] = dropDownVal;
			$scope.masterListElement[fieldName] = elementId;
			return true;
		}
	};

	$scope.updateDropdownOptions = function (field) {
		var fieldName = field.name;
		var dropDownVal = {};
		var displayTexts = [];
		var displayValues = [];
		var placeholderAppendText = [];
		var placeholderAppendValue = [];
		var placeholderText = "-- Select --";

		/* Find Old Index */
		var oldMasterData = $scope.masterListElement[fieldName];
		var tempList = oldMasterData.split("_");
		var fieldIndex = tempList[tempList.length - 1];
		// Create element Id
		var elementId = fieldName + "_" + fieldIndex;

		// No Master List Given */
		if (typeof field.masterListValue == "undefined") { return true; }
		// Check if Separate Text and Values are given
		// If text is present in the master list then use it
		displayTexts = $scope.globalMasterValues[field.masterListValue].text;
		if (typeof displayTexts == "undefined" || displayTexts == null) {
			displayTexts = $scope.globalMasterValues[field.masterListValue];
			displayValues = $scope.globalMasterValues[field.masterListValue];
		}
		else {
			displayTexts = $scope.globalMasterValues[field.masterListValue].text;
			displayValues = $scope.globalMasterValues[field.masterListValue].value;
			/* Check if text and values, both arrays have same length */
			if (displayTexts.length !== displayValues.length) {
				var err = {
					invalid: true,
					message: "text & value length mismatch in given master list : " + field.masterListValue
				};
				$scope.formValidationErrors[field[fieldIndex]] = err;
				return err;
			}
		}

		if (field.hasOwnProperty("placeholder") && field.placeholder != null) {
			placeholderAppendText = [field.placeholder].concat(displayTexts);
			placeholderAppendValue = [""].concat(displayValues);
			displayValues = placeholderAppendValue;
			displayTexts = placeholderAppendText;
		}
		else {
			placeholderAppendText = [placeholderText].concat(displayTexts);
			placeholderAppendValue = [""].concat(displayValues);
			displayValues = placeholderAppendValue;
			displayTexts = placeholderAppendText;
		}

		var selectedValue = displayValues[0];
		var query = selectedValue;
		var pageNumber = 0;
		var origin = 0;
		var xMin = 0;
		var xMax = 0;
		var yMin = 0;
		var yMax = 0;

		// Get the old selected value from the model container
		if (typeof $scope.selectedVal[fieldName] !== 'undefined' && $scope.selectedVal[fieldName] != null) {
			selectedValue = $scope.selectedVal[fieldName].query;
		}

		/* Backward Compatibility code. DO NOT CHANGE
		 * START
		 * */
		if (typeof query === 'undefined' || query == null) {
			selectedValue = $scope.uiConfig.selectedOptions[field.name].query;
			// Set the value in model
			$scope.selectedVal[fieldName].query = selectedValue;
		}
		/* Backward Compatibility code. DO NOT CHANGE
		 * END
		 * */

		for (var i = 0; i < displayTexts.length; i++) {
			dropDownVal[i] = {
				query: displayTexts[i],
				value: displayValues[i],
				pagenumber: pageNumber,
				orgin: origin,
				xMin: xMin,
				xMax: xMax,
				yMin: yMin,
				yMax: yMax
			};
		}

		$scope.dropDownValues[elementId] = dropDownVal;
		$scope.masterListElement[fieldName] = elementId;
		return true;
	};

	function getFieldValue(field, value) {

		// Blank Place holder for value
		var fieldValue = {
			field: field.name,
			query: "",
			pageNumber: 0,
			origin: "AUTO",
			xMin: 0.00,
			xMax: 0.00,
			yMin: 0.00,
			yMax: 0.00
		};
		// Sanitize query
		if (typeof value.query == "undefined" || value.query == null) {
			value.query = "";
		}
		// Update the placeholder with values. Whatever is missing will have default values from placeholder
		fieldValue = Object.assign(fieldValue, value);
		return fieldValue;
	}

	$scope.hasFieldChanged = function (oldValue, newValue) {
		console.log("hasFieldChanged\nNew:", newValue, "\nOld:", oldValue);
		// If no values then return false
		if (oldValue == undefined || oldValue == null || newValue == undefined || newValue == null) { return false; }

		var result = _.chain(oldValue).keys().every(function (currentKey) {
			// if current key is one of the desired properties
			if ($scope.fieldProperties.indexOf(currentKey) > -1) {
				// Compare the values
				return _.has(newValue, currentKey) && _.isEqual(oldValue[currentKey], newValue[currentKey]);
			}
			else {
				return false;
			}
		}).value();
		// if equal then result will be true so return false and vice versaTe
		return !result;
	};

	// #region Date Format Code

	/*
	 * Parses the given value on the formats and returns the date if success
	 * in case of failure, blank string is returned
	 */
	function formatDate(value, inputformat, outputFormat) {
		// If no value then return blank string
		if (value == undefined || value == null) {
			return "";
		}

		// if no input format then default to format from global config
		if (inputformat == undefined || inputformat == null || inputformat.trim() == "") {
			inputformat = $scope.globalConfig.dateFormat;
		}

		// If the date format is still null then change it to ISO8601
		if (inputformat == undefined || inputformat == null || inputformat.trim() == "") {
			inputformat = "yyyy-MM-dd";
		}

		// if no output format then default to format from global config
		if (outputFormat == undefined || outputFormat == null || outputFormat.trim() == "") {
			outputFormat = $scope.globalConfig.outputDateFormat;
		}

		// If the date format is still null then change it to ISO8601
		if (outputFormat == undefined || outputFormat == null || outputFormat.trim() == "") {
			outputFormat = "yyyy-MM-dd";
		}

		var formattedDate;

		// Parse the date on given input format
		var parsedDate = luxonDateTime.fromFormat(value, inputformat);

		// If Parse Failed,
		if (!parsedDate.isValid) {
			// Log the failure reason with value and format
			// try output format
			parsedDate = luxonDateTime.fromFormat(value, outputFormat);
		}

		// Parse failed again, try parsing it with default JS Date object
		if (!parsedDate.isValid) {
			// Log the failure reason with value and format
			parsedDate = Date.parse(value);

			// Check if the date is valid 
			if (!(parsedDate instanceof Date) || isNaN(parsedDate)) {
				// Parse Failed again, date seems to be invalid,
				//return original value
				return value;
			}
			else {
				// Convert the date from JS date
				parsedDate = luxonDateTime.fromJSDate(parsedDate);
				// Format the date
				formattedDate = parsedDate.toFormat(outputFormat);
				// Return the formatted date
				return formattedDate;
			}
		}
		// If reached here then date is parsed via luxon and valid 
		// Convert the date in proper format if possible
		formattedDate = parsedDate.toFormat(outputFormat);
		// Return the formatted date
		return formattedDate;
	}

	// #endregion Date Format Code

	// #region Master List Code

	$scope.prepareOptionLists = function (field) {
		var displayTexts = [];
		var displayValues = [];
		var masterListName;

		// Validate Input
		if (!field || !field.masterListValue) {
			return {
				texts: [],
				values: []
			};
		}

		// Get the master list name from the layoutDetails saved on initialization
		var layoutMasterListName = $scope.layoutDetails[field.name].masterListValue;

		// Get the required parameters
		// master list name from layout takes preference
		if (!layoutMasterListName) { masterListName = field.masterListValue; }
		else { masterListName = layoutMasterListName; }

		var masterColumn = field.masterColumn;

		// Get the master list using the list name
		var masterList = $scope.globalMasterValues[masterListName];

		// Apply The filters to the list returned
		masterList = $scope.applyFilters(field, masterList);

		// Get the values for master column
		if (masterColumn) { masterList = masterList.map(item => item[masterColumn]); }

		// Check if Separate Text and Values are given
		// If text is present in the master list then use it
		displayTexts = masterList.text;

		if (displayTexts == undefined || displayTexts == null) {
			displayTexts = masterList;
			displayValues = masterList;
		}
		else {
			displayTexts = masterList.text;
			displayValues = masterList.value;
			/* Check if text and values, both arrays have same length */
			if (displayTexts.length !== displayValues.length) {
				raiseAppianError("text & value length mismatch in given master list : " + field.name);
				return {
					texts: [],
					values: []
				};
			}
		}

		// Remove Duplicates for text and value combinations
		var dataItems = displayTexts.map((value, index) => { return [value, displayValues[index]]; });
		dataItems = Array.from(new Set(dataItems.map((res) => res.join("-")))).map((data) => data.split("-"));

		return {
			texts: dataItems.map(items => items[0]),
			values: dataItems.map(items => items[1])
		};
	};

	function getDisplayTextForValue(field, value) {
		// Validate input
		if (!field || !value) { return []; }

		var texts = [];

		// Get the master list
		var masterList = $scope.prepareOptionLists(field);
		// Get the texts for the value
		var indices = masterList.values.map((item, index) => item == value ? index : "").filter(String);

		var texts = masterList.texts.filter((item, index) => {
			if (indices.indexOf(index) > -1) { return true; }
			else { return false; }
		});

		return texts;
	};

	// #endregion Master List Code

	// #region textended Code

	$scope.initiateModal = function (field) {
		var fieldName = field.name;

		// Get the list of options
		var optionList = $scope.prepareOptionLists(field);

		// set displayText and values
		var displayTexts = optionList.texts;
		var displayValues = optionList.values;

		// Get the filter attribute if available
		var jqElement = getJQueryControl(fieldName);
		// Element not found
		if (jqElement.length == 0) { return true; }

		var dataItems = displayTexts.map((value, index) => {
			return [value, displayValues[index]];
		});

		getJQueryControl("#" + fieldName + "_modal_table").dataTable({
			data: dataItems,
			destroy: true,
			scrollY: "250px",
			scrollCollapse: true,
			paging: false,
			select: "single",
			info: false,
			"initComplete": function (settings, json) {
				$(".dataTables_scrollHeadInner").css({ "width": "100%" });
				$(".dataTables_scrollHeadInner table").css({ "width": "100%" });
				$(".dataTables_scrollHeadInner th").css({ "width": "100%" });
				$(".dataTables_filter").parent().removeClass("col-sm-6").addClass("col-sm-12").css({ "display": "flex", "justify-content": "center" });
			},
			columnDefs: [
				{
					target: 1,
					visible: false,
					searchable: false
				}
			]
		});
	};

	$scope.selectOption = function (field) {
		var fieldName = field.name;

		var table = getJQueryControl("#" + fieldName + "_modal_table").DataTable();
		// Selected row will have two values. first will be Display Text and second will be the value to be sent to Appian
		var selectedRows = table.rows('.selected').data()[0];

		if (selectedRows.length == 0) { return; }
		// Extract the text and value
		var text = selectedRows[0];
		var value = selectedRows[1];

		// Set the value to display
		$scope.formValues[field.name].query = text;
		// Prepare the value to be sent to Appian
		var value = getFieldValue(field, { query: value });

		// Send Change to Appian
		if (!isTestModeEnabled) {
			// Prepare the data to be sent to Appian
			var appianData = {
				name: field.name,
				fieldDetails: field,
				newValue: value
			};
			save(appianData);
		}

		// Process Rules specified for the control. Values are compared to the data displayed on the control
		$scope.processRules(field, text);
	};

	$scope.applyFilters = function (field, listToFilter) {
		// Validate inputs
		if (!field || !listToFilter || listToFilter.length == 0) { return listToFilter; }

		// Get the filter attribute if available

		var filterList = $scope.rulesContainer[field.name];

		if (!filterList) { return listToFilter; }

		// Parse the Filter
		filterList = JSON.parse(filterList);

		// Filtered List
		var filteredList = listToFilter;
		// Loop on the filters
		filterList.forEach(filter => {
			// Get the column and value
			var column = filter.columnToFilter;
			var value = filter.valueForFilter;

			filteredList = filteredList.filter(item => item[column] == value);
		});
		return filteredList;
	};
	// #endregion textended Code

	// #region Rule Processing

	/*
	 * Operators that are valid
	 */
	const validOperators = ["=", "<>", "<", "<=", ">", ">=", "in", "notin"];
	/*
	* Actions that are valid
	*/
	const validActions = ["property", "action", "filter"];

	/**
	 * Process rules specified for the field
	 * @param {Object[]} field Control whose rules need to be processed.
	 * The Format for a rule is 
	 *	{
	 *		"rules": [ Rule1, Rule2, ...]
	 *	}
	 * @param {any} currentValue Current value of the field
	 * @returns No return value
	 */
	$scope.processRules = function (field, currentValue) {
		// Validate input parameters
		if (!field) { return; }
		// Get All the rules for the field
		var rules = [];
		if (field.hasOwnProperty("rules")) { rules = field.rules; }
		// Check if any rule is present
		if (!rules || rules.length == 0) { return; }

		// Get the master list
		var masterList = $scope.prepareOptionLists(field);

		// Loop through all the rules
		rules.forEach(function (rule) {
			var ruleClone = rule;
			// Run only if action type is property
			if (rule.actionType == "property") {
				// Update the values in the rule based on the values present in the "values" in the master list
				var texts = masterList.values.map((value, index) => {
					if (rule.values.indexOf(value.toString()) > -1) {
						return masterList.texts[index];
					}
				});
				// Remove all the undefined values
				texts = texts.filter(function (text) { return text !== undefined; });
				// Replace values in the rule with display texts
				// Clone it to preserve the original rule
				ruleClone = clone(rule);
				ruleClone.values = texts;
			}

			// Process Rule
			$scope.processRule(ruleClone, currentValue);
		});
	};

	/**
	 * Processes one rule from a field
	 * @param {Object} rule The Rule object to process. The format of the Rule object is :
	 * {
	 *       "operator": "",  
	 *       "values": [""],
	 *		 "actions": [action1, action2, ...]
	 *   }
	 * operator can be one of =,<>,<,<=,>,>=, in, notin,
	 * 
	 * @param {any} currentValue Value against which the rule will be processed
	 * @returns No return value
	 */
	$scope.processRule = function (rule, currentValue) {
		// Validate input parameters
		if (!rule) { return; }
		// Get all the values from the rule
		var actionType = rule.actionType;

		// Validate the parameters
		if (!actionType || validActions.indexOf(actionType) < 0) { raiseAppianError("Action Type is Missing Or Invalid. Valid values are 'property', 'action', 'filter'"); return; };

		switch (actionType) {
			case "property": $scope.processPropertyRule(rule, currentValue); break;
			case "filter": $scope.processFilterRule(rule, currentValue); break;
			case "action": break;
			default: break;
		}
	};

	$scope.processPropertyRule = function (rule, currentValue) {
		// Validate input parameters
		if (!rule) { return; }

		// Get all the values from the rule
		var operator = $.trim(rule.operator).toLowerCase();
		var values = rule.values;
		var actions = rule.actions;

		// Validate the parameters
		if (!operator || validOperators.indexOf(operator) < 0) { raiseAppianError("Operator Missing Or Invalid. Valid values are =, <>, <, <=, >, >=, in, notin"); return; }
		if (!values || values.length == 0) { raiseAppianError("No Values found to process in the rule."); return; }
		if (!actions || actions.length == 0) { raiseAppianError("No action found to process in the rule"); return; }

		var operatorCheckResult;
		// Check if the current value satisfies the values provided according to the operator
		switch (operator) {
			case "=": operatorCheckResult = $scope.checkEqual(currentValue, values); break;
			case "<>": operatorCheckResult = $scope.checkNotEqual(currentValue, values); break;
			case "<": operatorCheckResult = $scope.checkLessThan(currentValue, values); break;
			case "<=": operatorCheckResult = $scope.checkLessThanEqualTo(currentValue, values); break;
			case ">": operatorCheckResult = $scope.checkGreaterThan(currentValue, values); break;
			case ">=": operatorCheckResult = $scope.checkGreaterThanEqualTo(currentValue, values); break;
			case "in": operatorCheckResult = $scope.checkIn(currentValue, values); break;
			case "notin": operatorCheckResult = $scope.checkNotIn(currentValue, values); break;
			default: raiseAppianError("Operator Missing Or Invalid. Valid values are =, <>, <, <=, >, >=, in, notin"); return;
		}

		// If No Rules passed, return
		if (!operatorCheckResult) { return; }
		// Rule Check is true, run all the actions 
		// Loop through all the actions
		actions.forEach(function (action) {
			// Validate input parameters
			if (!action) { return true; }
			// Get all the values from action
			var controls = action.controls;
			var properties = action.properties;
			var values = action.values;

			// Validate the parameters
			if (!controls || controls.length == 0) { raiseAppianError("No Controls found to process in the rule."); return true; }
			if (!properties || properties.length == 0) { raiseAppianError("No properties found to acted upon the rule"); return true; }
			if (!values || values.length == 0) { raiseAppianError("No properties values found to acted upon the rule"); return true; }

			// Process Action
			$scope.runPropertyAction(controls, properties, values);
		});
	};

	// #region Operator Processing

	$scope.checkEqual = function (currentValue, values) { return $.trim(currentValue).toLowerCase() == $.trim(values).toLowerCase(); };
	$scope.checkNotEqual = function (currentValue, values) { return $.trim(currentValue).toLowerCase() != $.trim(values).toLowerCase(); };
	$scope.checkLessThan = function (currentValue, values) { return $.trim(currentValue).toLowerCase() < $.trim(values).toLowerCase(); };
	$scope.checkLessThanEqualTo = function (currentValue, values) { return $.trim(currentValue).toLowerCase() <= $.trim(values).toLowerCase(); };
	$scope.checkGreaterThan = function (currentValue, values) { return $.trim(currentValue).toLowerCase() > $.trim(values).toLowerCase(); };
	$scope.checkGreaterThanEqualTo = function (currentValue, values) { return $.trim(currentValue).toLowerCase() >= $.trim(values).toLowerCase(); };
	$scope.checkIn = function (currentValue, values) {
		// Convert Values to array if not already
		if (!Array.isArray(values)) { values = [values]; }
		// Convert all values to lowercase string 
		values = values.map(value => $.trim(value).toLowerCase());
		// Validate
		return values.includes($.trim(currentValue).toLowerCase());
	};
	$scope.checkNotIn = function (currentValue, values) {
		// Convert Values to array if not already
		if (!Array.isArray(values)) { values = [values]; }
		// Convert all values to lowercase string 
		values = values.map(value => $.trim(value).toLowerCase());
		// Validate
		return !values.includes($.trim(currentValue).toLowerCase());
	};

	// #endregion Operator Processing

	$scope.processFilterRule = function (rule, currentValue) {
		// Validate input parameters
		if (!rule) { return; }

		// Get all the values from the rule
		var actions = rule.actions;

		// Validate the parameters
		if (!actions || actions.length == 0) { raiseAppianError("No action found to process in the rule"); return true; }

		// Loop through all the actions
		actions.forEach(function (action) {
			// Validate input parameters
			if (!action) { return true; }
			// Get all the values from action
			var controls = action.controls;
			var columnToFilter = action.columnToFilter;

			// Validate the parameters
			if (!controls || controls.length == 0) { raiseAppianError("No Controls found to process in the rule."); return true; }
			if (!columnToFilter || columnToFilter.length == 0) { raiseAppianError("No Column Filter found to acted upon the rule"); return true; }

			// Process Action
			$scope.runFilterAction(controls, columnToFilter, currentValue);
		});
	};

	$scope.runPropertyAction = function (controls, properties, values) {
		// Validate input parameters
		if (!controls) { return; }
		if (!properties) { return; }
		if (!values) { return; }

		// Convert input parameters to array if not already
		if (!Array.isArray(controls)) { controls = [controls]; }
		if (!Array.isArray(properties)) { properties = [properties]; }
		if (!Array.isArray(values)) { values = [values]; }

		var valuesLength = values.length;

		// Loop on all controls
		controls.forEach(function (control) {
			// Loop on all the properties
			properties.forEach(function (property, index) {
				// Get the value for the current index
				var value = "";
				if (index < valuesLength) { value = values[index]; }

				// Set controls property to value
				$scope.setControlProperty(control, property, value);
			});
		});
	};

	$scope.runFilterAction = function (controls, columnToFilter, valueForFilter) {
		// Validate input parameters
		if (!controls) { return; }
		if (!columnToFilter) { return; }
		if (!valueForFilter) { valueForFilter = ""; }

		// Convert input parameters to array if not already
		if (!Array.isArray(controls)) { controls = [controls]; }

		// Loop on all controls
		controls.forEach(function (control) {
			// Reset the value of the target control if available and initialization is not in progress
			if (!isInitializing && $scope.formValues[control]) { $scope.formValues[control].query = ""; }

			// Prepare the filter object to be set on the control
			var filter = {
				columnToFilter: columnToFilter,
				valueForFilter: valueForFilter
			};

			// Get the current filter attribute
			var currentFilter = $scope.rulesContainer[control];

			// Validate current filter
			if (!currentFilter || currentFilter.length == 0) { currentFilter = "[]"; }

			// Parse the Filter
			currentFilter = JSON.parse(currentFilter);

			// Flag to indicate if the column has been found in the current filter list
			var filterFound = false;
			// Check for the presence of the current column to filter
			currentFilter.forEach(filterValue => {
				// Compare the column name with current column name
				if ($.trim(filterValue.columnToFilter).toLowerCase() == $.trim(columnToFilter).toLowerCase()) {
					// Update the value with the current  value
					filterValue.valueForFilter = valueForFilter;
					// Set the flag
					filterFound = true;
					// Break out of loop
					return false;
				}
				return true;
			});

			// If the filter is not found then add the filter to current filter list, otherwise continue as the value has already been updated
			if (!filterFound) { currentFilter.push(filter); }

			// Set the rule in the scope container also
			$scope.rulesContainer[control] = JSON.stringify(currentFilter);

			// Continue 
			return true;
		});
	};

	$scope.setControlProperty = function (control, property, value) {
		// Validate input parameters
		if (!control) { return; }
		if (!property) { return; }
		if (!value) { value = ""; }

		// Get the element
		var jqElement = getJQueryControl(control);
		// Element not found
		if (jqElement.length == 0) { return; }

		var element = jqElement[0];

		// Get all the attributes of the element
		var attributes = [];
		var computedAttributes = element.attributes;
		for (var i = 0; i < computedAttributes.length; i++) { attributes.push(computedAttributes[i]); }

		switch (property) {
			case "readonly": jqElement.attr("ng-readonly", value); break;
			case "disabled": jqElement.attr("ng-disabled", value); $scope.disableCtrl[control] = value.toBoolean(); break;
			case "required": jqElement.attr("ng-required", value); $scope.requiredCtrl[control] = value.toBoolean(); break;
			case "masterListValue":
				jqElement.attr("masterListValue", value);
				$scope.layoutDetails[control].masterListValue = value;
				break;
			case "display":
				if (value == "none") { $scope.visibilityCtrl[control] = false; }
				else { $scope.visibilityCtrl[control] = value.toBoolean(); };
				break;
			default:
				jqElement.attr(property, value);
				jqElement.attr("ng-" + property, value);
				break;
		}
	};

	// #endregion Rule Processing

	// #region Appian Methods

	function save(valueToSave, event) {
		if (isTestModeEnabled) { return; }

		if (Appian == undefined || Appian == null) { return; }

		var eventToRaise = onChangeLast;
		if (event != undefined || event != null) { eventToRaise = event; }

		Appian.Component.saveValue(eventToRaise, valueToSave);
	}

	/**
	 * Raise Error for Appian. it will be passed back to Appian and shown on UI
	 * @param {String} errorValue Error Message to be shown
	 * @returns Nothing
	 */
	function raiseAppianError(errorValue) {
		if (isTestModeEnabled) { return; }

		if (Appian == undefined || Appian == null) { return; }

		//Appian.Component.setValidations(errorValue);
	}

	function resetAppianErrors() {
		if (isTestModeEnabled) { return; }

		if (Appian == undefined || Appian == null) { return; }

		Appian.Component.setValidations([]);
	}

	// #endregion Appian Methods

	//#region Initialization Methods

	function initializeControlRules(field, value) {
		// Execute the rules available on the field after all the controls has been initialized
		setTimeout(function () {
			isInitializing = true;
			$scope.processRules(field, value);
			isInitializing = false;
		}, 1000);
	}
	// This function will update the input as per version 1.0's structure
	// like converts array into Key:Objects structure, so the plugin can handle  
	function convertInputArrayInRequiredFormat(inputs) {
		var returnValue;
		var newFormValues = {};

		$scope.lastSelected = {};
		inputs.formDetails.milestones = orderByFilter(inputs.formDetails.milestones, "sortOrder");
		for (var milestoneIndex = inputs.formDetails.milestones.length - 1; milestoneIndex >= 0; milestoneIndex--) {
			returnValue = convertArrayToDictionary(inputs.formDetails.milestones[milestoneIndex], inputs.formValues, "milestone");
			inputs.formDetails.milestones[milestoneIndex] = returnValue.container;
			newFormValues = Object.assign(newFormValues, returnValue.tempObject);

			// for fields within sections
			for (var i = inputs.formDetails.milestones[milestoneIndex].sections.length - 1; i >= 0; i--) {
				returnValue = convertArrayToDictionary(inputs.formDetails.milestones[milestoneIndex].sections[i], inputs.formValues, "section");
				inputs.formDetails.milestones[milestoneIndex].sections[i] = returnValue.container;
				newFormValues = Object.assign(newFormValues, returnValue.tempObject);
			}
		}
		inputs.formValues = newFormValues;
		return inputs;
	}

	function convertArrayToDictionary(container, values, typeOfContainer) {
		var k;
		var fieldIndex;
		var tempObject = {};
		var fieldName;
		var fieldType;

		if (container.hasOwnProperty("fields") && container.fields.length) {
			container = checkAndUpdateSingleFieldObject(container.name, container);

			for (fieldIndex = 0; fieldIndex < container.fields.length; fieldIndex++) {
				fieldName = container.fields[fieldIndex].name;
				fieldType = container.fields[fieldIndex].type;
				//adding in temp array to handle runtime single object changes
				container.fields[fieldIndex] = checkAndUpdateSingleFieldObject(fieldName, container.fields[fieldIndex]);
				/*
				 * Create a backup of the control to be used later
				 */
				// Save the current layout to old layout container
				$scope.oldLayoutDetails[fieldName] = $scope.layoutDetails[fieldName];
				// Update the current layout with new value
				$scope.layoutDetails[fieldName] = container.fields[fieldIndex];

				for (k = values.length - 1; k >= 0; k--) {
					var value = values[k];
					if (value.field == fieldName) {
						if ($scope.uiConfig.supportedWebFields.arrayTypes.indexOf(fieldType) > -1) {
							if (tempObject[fieldName] == undefined) {
								tempObject[fieldName] = value;
							}
						}
						else {
							tempObject[fieldName] = value;
						}
						if (typeOfContainer === "milestone" && fieldType == "grid") {
							convertGridFieldsInRequiredFormat(values[k].rows);
						}

						// Execute the rules available on the field
						initializeControlRules(container.fields[fieldIndex], value.query);
					}
				}
			}
		}

		return {
			container: container,
			tempObject: tempObject
		};
	}

	/**
	 * Initialize the plugin
	 * @param {any} newValues the data used to initialize the plugin
	 */
	function handleInit(newValues) {
		// Set a flag to indicate that initialization is running
		isInitializing = true;
		// Apply the values from the json to the scope variables
		try {
			// Set the initial value for the global plugin data
			plugInData = newValues;
			$scope.globalConfig = plugInData.config;
			$scope.globalMasterValues = plugInData.masterValues;
			$scope.globalCascadingMasterValues = plugInData.cascading;

			$scope.updateObjectValues = plugInData.updateObjectValues;
			$scope.updateFromObject = plugInData.updateFormObject;

			//For optimize unwanted loops and remove extra function 
			plugInData = convertInputArrayInRequiredFormat(plugInData);
			// Duplicate Form Details using clone method
			$scope.formData = clone(plugInData.formDetails);
			const labelName = JSON.parse(JSON.stringify(plugInData.formDetails));

			$scope.tabHeader = labelName.milestones.map(e => { return { label: e.label, name: e.name, style: e.style }; });
			//			$scope.tabHeader =JSON.parse(JSON.stringify(plugInData.formDetails));
			//$scope.formData.milestones = $scope.formData.milestones.slice(0, 1);
			$scope.globalMasterValues = plugInData.masterValues;
			$scope.globalCascadingMasterValues = plugInData.cascading;
			$scope.formValues = plugInData.formValues;

			$scope.originalFormValues = clone($scope.formValues);

			$scope.selectTab = function (index) {
				const findIndex = $scope.formData.milestones.findIndex(e => e.name === plugInData.formDetails.milestones[index].name);
				if (findIndex === -1) {
					$scope.formData.milestones.push(plugInData.formDetails.milestones[index]);
				}
			};
			// Select the first tab only if no other tabs have been opened
			if ($scope.formData.milestones.length < 1) { $scope.selectTab(0); }

			//created web workers for update validation to Appian 
			triggerWebWorkers();
		}
		catch (e) {
			console.error(e);
		}

		setTimeout(function () {
			if (plugInData.height != "auto" && plugInData.height != null) { iframeHeight = plugInData.height; }
			else { iframeHeight = "750px"; }

			adjustHeightOfIframe(iframeHeight, iframeWidth);
			updatePDFConfigs(plugInData.config);

			// Open the document
			openDocument(plugInData.appianDocumentId, plugInData.documentConnectedSystem);

			if ($scope.docData == null && !_.isEqual(currentDocumentId, plugInData.documentDownloadURL)) {
				currentDocumentId = plugInData.documentDownloadURL;
				getDocumentFromWeb(currentDocumentId);
			}

			if (plugInData.annotationObject != null || plugInData.annotationObject != undefined || Object.keys(plugInData.annotationObject) > 0) {
				highlightTextInPdf({ query: plugInData.annotationObject.query }, plugInData.annotationObject);
			}
		}, 500);

		//Add event handler to tabs for tab-change
		setTimeout(function () {
			$scope.$apply(function () {
				$('a[data-toggle="tab"]').on("shown.bs.tab", function (e) {
					e.preventDefault();
					var newTabName = $(e.target).attr("href").replace("#", "");
					var previousTabName = $(e.relatedTarget).attr("href").replace("#", "");

					/* Raise the Appian event if not in test mode */
					if (!isTestModeEnabled) {
						Appian.Component.saveValue(onTabChange, { previousTab: previousTabName, newTab: newTabName });
					};
				});

				setTimeout(function () { $('[data-toggle="tooltip"]').tooltip({ html: true }); }, 5000);
			});
		}, 1500);
	}

	//--------IMPORTANT------------
	/*TEST VALUES START:- FOR TESTING MODE (Without Appian)*/
	if (!isTestModeEnabled) { isTestModeEnabled = getTestModeFlag(); }

	if (!isTestModeEnabled) { init(); }
	else { handleInit(window.TEST_VALUES); }

	function getTestModeFlag() {
		var isTestMode = false;
		if (typeof (Appian) === "undefined") {
			isTestMode = window.TEST_VALUES.enableTestMode;
		}
		return isTestMode;
	}

	/*TEST VALUES END*/

	//#endregion Initialization Methods
	const endTime = performance.now();
	console.log('PerformanceTime', endTime - startTime);
});