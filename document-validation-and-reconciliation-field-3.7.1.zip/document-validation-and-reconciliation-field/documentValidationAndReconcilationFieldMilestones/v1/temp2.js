window.TEST_VALUES = {
    annotationObject: {
        query: "string to search",
        pageNumber: 1,
        xMin: 20.45,
        xMax: 30.32,
        yMin: 18.8,
        yMax: 19.6,
        phraseSearch: false, // if true then ONLY query will be searched otherwise coordinates will be highlighted
        caseSensitive: false,
        entireWord: false,
        highlightAll: true,
        findPrevious: false
    },
    documentDetails: {
        documentId: 1234,
        username: "mayur"
    },
    onChange: {},
    config: {
        // highlightAtPDFScale: 0.75,
        defaultRectanglePadding: 1,
        clearCanvasBeforeHighlighting: true,
        highlightTextOnElementFocus: true,
        highlightAll: true,
    },
    downloadFileConnectedSystem: {}, //cons!CONNECTED_SYSTEM
    formDetails: {
        verticalMargin: "10px",
        vSpacingBetweenFields: "5px",
        milestoneClass: "primary",
        milestones: [{
                label: "Policy Details",
                name: "policyDetail",
                sortOrder: 1,
                fields: [{
                        type: "search",
                        name: "policySearch",
                        label: "Policy Search",
                        class: "form-control",
                        style: {
                            divClass: "col-md-12",
                            fieldClass: "form-control",
                            labelClass: "text-primary",
                            style: ""
                        },
                    }, {
                        type: "grid",
                        name: "grid1",
                        label: "Test Grid",
                        style: {
                            divClass: "col-md-12",
                            fieldClass: "table table-bordered table-hover table-striped",
                            labelClass: "text-primary",
                            style: "color: green"
                        },
                        columns: [{
                                header: "First Name",
                                headerStyle: "background-color: blue; color: white",
                                dataStyle: "text-align:left"
                            },
                            {
                                header: "Last Name",
                                headerStyle: "",
                                dataStyle: "text-align:right"
                            },
                            {
                                header: "Email",
                                headerStyle: "",
                                dataStyle: "text-align:center"
                            }
                        ],
                        clickable: true
                    },
                    {
                        type: "text",
                        name: "UMR",
                        label: "UMR",                    
                        required: true,
                        style: {
                            divClass: "col-sm-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary",
                            style: ""
                        },
                        icon: {
                            visible: true,
                            icon: "lightbulb-o",
                            htmlStyle: "color:red;font-size: 18px"
                        }
                    },
                    {
                        type: "_",
                        name: "_"
                    },
                    {
                        type: "text",
                        name: "Premium",
                        label: "Premium",
                        // class: "form-control",
                        // placeholder: "placeholder",
                        required: true,
                        style: {
                            divClass: "col-sm-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary",
                            style: ""
                        },
                         validations: [{
                                regex: "^[0-9.]{1,10}$",
                                errorMessage: "Premium should be numeric and between 5-6 in length"
                            }
                        ]

                    },
                    {
                        type: "text",
                        name: "Settlement_Due_Date2",
                        label: "Settlement_Due_Date",
                        // class: "form-control",
                        // placeholder: "placeholder",
                        required: true,
                        style: {
                            divClass: "col-sm-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary",
                            style: ""
                        },

                    },
                ],
                sections: [{
                    label: "Policy Details",
                    name: "PolicyDetails",
                    collapsed: false,
                    class: "panel panel-primary",
                    fields: [{
                            type: "grid",
                            name: "grid1",
                            label: "Test Grid",
                            style: {
                                divClass: "col-md-12",
                                fieldClass: "table table-bordered table-hover table-striped",
                                labelClass: "text-primary",
                                style: ""
                            },
                            columns: [{
                                    header: "First Name",
                                    dataStyle: "text-align:left"
                                },
                                {
                                    header: "Last Name",
                                    dataStyle: "text-align:right"
                                },
                                {
                                    header: "Email",
                                    dataStyle: "text-align:center"
                                }
                            ],
                        },
                        {
                            type: "currency",
                            name: "Amount",
                            label: "Amount",
                            // class: "form-control",
                            required: true,
                            style: {
                                divClass: "col-md-6",
                                fieldClass: "form-control",
                                labelClass: "text-primary",
                                style: ""
                            },
                            icon: {
                                visible: true,
                                icon: "lightbulb-o",
                                htmlStyle: "color:red;font-size: 18px"
                            }
                        },
                        {
                            type: "button-group", //select, multiselect,button-group
                            name: "DupplicateCheck",
                            required: true,
                            label: "Duplicate Found ?",
                            class: "form-control",
                            style: {
                                divClass: "col-md-6",
                                fieldClass: ["btn-primary btn-lg", "btn-danger btn-lg"],
                                labelClass: "text-primary",
                                style: ""
                            },
                            icon: {
                                visible: true,
                                icon: "lightbulb-o",
                                htmlStyle: "color:red;font-size: 18px"
                            }
                        },
                    ]
                }, {
                    label: "Policy Details 2",
                    name: "PolicyDetails2",
                    collapsed: true,
                    class: "panel panel-primary",
                    fields: [{
                        type: "text",
                        name: "Situation",
                        label: "Situation",
                        // class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-md-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary",
                            style: ""
                        },
                        icon: {
                            visible: true,
                            icon: "lightbulb-o",
                            htmlStyle: "color:red;font-size: 18px"
                        }
                    }, ]
                }]
            },
            {
                label: "Incident Details",
                name: "incidentDetail",
                sortOrder: 2,
                sections: [{
                    label: "Insurance Details",
                    name: "Policy_Details",
                    collapsed: true,
                    class: "panel panel-primary",
                    fields: [{
                        type: "text",
                        name: "Address",
                        label: "Address",
                        class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-md-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary",
                            style: ""
                        }
                    }, ]
                }]
            }
        ],
    },
    formValues: [{
            field: "grid1",
            rows: [{
                    id: 1,
                    data: [{
                            query: "John",
                            pageNumber: 12,
                            origin: "AUTO",
                            id: 7,
                            xMin: 0.436,
                            xMax: 0.529,
                            yMin: 0.537,
                            yMax: 0.547
                        },
                        { query: "Doe", dataStyle: "background-color: yellow" },
                        { query: "John@test.com" },
                    ]
                },
                {
                    id: 2,
                    data: [
                        { query: "July" },
                        { query: "Dooley" },
                        { query: "July@test.com" },
                    ],
                }
            ]
        },
        {
            field: "UMR",
            query: "B98345029321",
            id: 1,
            pageNumber: 1,
            origin: "AUTO",
            name: "qaz",
            xMin: 0.335,
            xMax: 0.441,
            yMin: 0.185,
            yMax: 0.194,
            accuracy: 1,

        }, {
            field: "DupplicateCheck", //select, multiselect,button-group
            rows: [{
                    query: "Yes",
                    id: 1,
                    pageNumber: 2,
                    origin: "AUTO",
                    name: "qaz",
                    xMin: 0.335,
                    xMax: 0.441,
                    yMin: 0.185,
                    yMax: 0.194,
                    accuracy: 1,
                },
                {
                    query: "No",
                    id: 1,
                    pageNumber: 3,
                    origin: "AUTO",
                    name: "qaz",
                    xMin: 0.335,
                    xMax: 0.441,
                    yMin: 0.185,
                    yMax: 0.194,
                    accuracy: 1,
                }
            ]

        },
        {
            field: "Address",
            query: "100 Paseo de Roxas , Legazpi Village, Makati, Metro Manila, Phillipines",
            pageNumber: 1,
            origin: "AUTO",
            xMin: 0.333,
            xMax: 0.499,
            yMin: 0.239,
            yMax: 0.332,
            tempKey: 1234,
            id: 2
        },

        {
            field: "policySearch",
            id: 3,
            query: ""
        },
        {
            field: "Insured",
            id: 4,
            query: "Test",
            pageNumber: 3,
            origin: "AUTO",
            xMin: 0.333,
            xMax: 0.499,
            yMin: 0.239,
            yMax: 0.332
        },
        {
            field: "Amount",
            id: 4,
            query: "1,20,000",
            pageNumber: 3,
            origin: "AUTO",
            xMin: 0.333,
            xMax: 0.499,
            yMin: 0.239,
            yMax: 0.332
        },
        {
            field: "Type",
            id: 5,
            query: "Terrorism and/or Sabotage Reinsurance",
            pageNumber: 1,
            origin: "AUTO",
            xMin: 0.335,
            xMax: 0.631,
            yMin: 0.212,
            yMax: 0.224
        },
        {
            field: "Country_Of_Origin",
            id: 6,
            query: "PHL",
            pageNumber: 12,
            origin: "AUTO",
            xMin: 0.435,
            xMax: 0.515,
            yMin: 0.232,
            yMax: 0.244
        },
        {
            field: "Regulatory_Client_Classification",
            query: "Reinsurance",
            pageNumber: 12,
            origin: "AUTO",
            id: 7,
            xMin: 0.436,
            xMax: 0.529,
            yMin: 0.537,
            yMax: 0.547
        },
        {
            field: "Policy_Start_Date",
            id: 8,
            query: "25/01/2021",
            pageNumber: 1,
            origin: "AUTO",
            xMin: 0.335,
            xMax: 0.853,
            yMin: 0.385,
            yMax: 0.434,
            format: "DD/MM/YYYY"
        },  

        {
            field:"_"
        }    
    ]
}