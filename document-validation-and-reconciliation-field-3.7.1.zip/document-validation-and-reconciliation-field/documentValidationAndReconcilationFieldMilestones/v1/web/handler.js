// @author: Mayur Agarwal


// Angular initialization
var app = angular.module('myApp', []);
app.directive('dynamicfield', function() {
    return {
        restrict: 'E',
        scope: {
            field: '=',
            form: '=',
            uiConfig: '=',
            formValues: '='
        },
        templateUrl: './fieldHandler.html'
    };
});
app.controller('myCtrl', function($scope, orderByFilter, $rootScope) {

    // VALUE_ORIGINS is to capture the fields value's orign,
    // Auto means captured from Appian and SELECTED means that they are captured from the plugin
    var VALUE_ORIGINS = ["AUTO", "SELECTED"];

    var PDF_SUFFIX = ""; // "data:application/pdf;base64,";

    // GLOBAL variable which holds all the plugin data
    var NEW_VALUES = {};
    var onChange = "onChange";
    var onChangeLast = "onChangeLast";
    var onSearch = "onSearch";
    var onGridClick = "onGridClick";
    var onButtonClick = "onButtonClick";
    var iframeHeight = "750px",
        iframeWidth = "750px";

    // PDF.JS Global Variables, which are set here by JS utilities
    var PDFViewerApplication, clearOldRectangles, showRectangleByCoordinates;

    // Angular's global variable
    $scope.uiConfig = {
        supportedWebFields: {
            all: ["text", "number", "date", "select", "multiselect", "search", "grid", "button-group", "currency",
                "_"
            ],
            inputTypes: ["text", "number", "date", "currency"],
            arrayTypes: ["select", "multiselect"],
            search: ["search"],
            other: ["grid", "button-group"]
        },
        selectedOptions: {},
        lastFocusedElement: null,
    }

    // Current Focused element
    $scope.focusedElement = null;
    $scope.myFormHolder = {};
    $scope.isValueChangedInLastFocusedElement = false;
    $scope.formValidationErrors = {};

    //--------IMPORTANT------------
    /*TEST VALUES START:- FOR TESTING MODE (Without Appian)*/
    var TEST_MODE = false;
    var temp;
    // if (TEST_MODE) {
    //     temp = sanitiseInput(validateAppianInput(convertInputArrayInRequiredFormat(window.TEST_VALUES)));
    //     $scope.formData = temp.formDetails;
    //     $scope.formValues = temp.formValues;

    //     $scope.originalFormValues = clone($scope.formValues);
    //     NEW_VALUES = temp;
    //     setTimeout(function() {
    //         //openPDF("../MRC_SAMPLE.pdf");
    //         getDocumentFromWeb("https://bpmdemo.appcino.com:9999/suite/doc/ioB7821xURit2IUeybKIJd3cTC7pFU8p1kmeOjvF_z4BQXHjovcDxabhOs")
    //     }, 1000);
    // }

    /*TEST VALUES END*/

    // Setting up the above Global variables to initialise the application, they are called from viewer.html file
    window.setPDFViewerApplication = function(data, showHighlight, clearOldRectangle) {
        PDFViewerApplication = data;
        showRectangleByCoordinates = showHighlight;
        clearOldRectangles = clearOldRectangle;


        //call this in last if used in Appian, otherwise comment it to test on local server
        if (!TEST_MODE)
            init();
    }


    // updating the focus (annotations) on zoom change, called from viewer.js (function: zoomIn, lineNo : 1278)
    window.resetAnnotations = function() {
        if ($scope.hasOwnProperty("focusedElement") && $scope.focusedElement != null) {
            setTimeout(function() {
                $scope.onFocusHandler($scope.formValues[$scope.focusedElement.name], $scope.focusedElement);
            }, 1)
        }
    }


    // appian document Id
    var currentDocumentDetails;

    // handling the on grid clicked event of each field from index.html,
    // will store the cell and row data to appian's output "onGirdClick" Field
    $scope.onGridClicked = function(cell, row, field) {
        if (!TEST_MODE) {
            addValidationErrorsInFormValues();
            Appian.Component.saveValue(onGridClick, {
                cell: cell,
                row: row,
                fieldDetails: field
            });
        }

        $scope.onFocusHandler(cell, {
            type: "text"
        });
    }

    // handling the on focus event of each field from index.html
    // will highlight the text in the pdf
    $scope.onFocusHandler = function(formValue, field) {
        //console.log(formValue, field);
        $scope.uiConfig.lastFocusedElement = clone($scope.focusedElement);
        // handle the onSelect here
        $scope.focusedElement = clone(field);
        //console.log($scope.uiConfig.lastFocusedElement, $scope.focusedElement);

        if (NEW_VALUES.config.highlightTextOnElementFocus == true) {
            highlightTextInPdf(formValue, {
                phraseSearch: true,
                clearCanvasBeforeHighlighting: false,
                caseSensitive: NEW_VALUES.annotationObject.caseSensitive,
                entireWord: NEW_VALUES.annotationObject.entireWord,
                highlightAll: NEW_VALUES.annotationObject.highlightAll,
                findPrevious: NEW_VALUES.annotationObject.findPrevious,
            });
        }

        if ($scope.uiConfig.supportedWebFields.inputTypes.indexOf(field.type) > -1 || $scope.uiConfig.supportedWebFields.search.indexOf(field.type) > -1) {
            highlightTextInPdf(formValue, {
                phraseSearch: false,
                clearCanvasBeforeHighlighting: true
            });
        } else {
            $scope.onSelectHandler(formValue, field, true);
        }
    }

    // Handle the button click detail, will store output in Appian's onButtonCLick Field
    $scope.onButtonClick = function(value, field) {
        addValidationErrorsInFormValues();
        if (!TEST_MODE) {
            Appian.Component.saveValue(onButtonClick, { fieldDetails: field, clicked: value });
        }
    }

    // handling the select/multiselect change event
    // will highlight the text in the pdf
    $scope.onSelectHandler = function(formValue, field, onFocus, data) {
        // onFocus != true, means original selection change event.
        console.log(formValue)
        if (onFocus != true) {
            $scope.uiConfig.lastFocusedElement = clone($scope.focusedElement);
            $scope.focusedElement = clone(field);
        }

        // handle multiple select issue, of all rects in one page
        // if(onFocus == true){
        //     return
        // }

        //console.log($scope.uiConfig.selectedOptions[field.name]);

        if (field.type == "select") {
            if ($scope.uiConfig.selectedOptions[field.name] != null &&
                Array.isArray($scope.uiConfig.selectedOptions[field.name]) == false &&
                $scope.uiConfig.selectedOptions[field.name].hasOwnProperty("pageNumber")) {

                highlightTextInPdf($scope.uiConfig.selectedOptions[field.name], { clearCanvasBeforeHighlighting: true, phraseSearch: false });
            }
        } else if (field.type == "multiselect") {
            //clearing previous rects, if any;
            formValue.rows.forEach(function(each, index) {
                if (each.isSelected) {
                    highlightTextInPdf(each, { clearCanvasBeforeHighlighting: (index == 0) ? true : false, phraseSearch: false });
                }
            })
        }
    }

    // init called to initiate the Appian part, like fetching document from the Appian KC.
    // getting formDetails and formData
    function init() {
        Appian.Component.onNewValue(function(newValues) {
            console.log("Mayur Agarwal: Document Ready", newValues, PDFViewerApplication);
            Appian.Component.setValidations([]);
            try {
                NEW_VALUES = sanitiseInput(validateAppianInput(convertInputArrayInRequiredFormat(newValues)));
            } catch (e) {
                console.error(e)
            }

            $scope.$apply(function() {
                $scope.formData = NEW_VALUES.formDetails;
                $scope.formValues = NEW_VALUES.formValues;
                $scope.originalFormValues = clone($scope.formValues);
            });


            if (NEW_VALUES.height != "auto" && NEW_VALUES.height != null) {
                iframeHeight = NEW_VALUES.height;
            } else {
                iframeHeight = "750px";
            }

            adjustHeightOfIframe(iframeHeight, iframeWidth);

            // should be loaded in last of this function
            // if (currentDocumentDetails.documentId != NEW_VALUES.documentDetails.documentId) {
            //     console.log("New Document, refreshing viewport");
            //     currentDocumentDetails = NEW_VALUES.documentDetails;
            //     getDocumentFromAppian(NEW_VALUES.downloadFileConnectedSystem, NEW_VALUES.documentDetails);
            //     return;
            // }

            if (!_.isEqual(currentDocumentDetails, NEW_VALUES.documentDownloadURL)) {
                console.log("New Document, refreshing viewport");
                currentDocumentDetails = NEW_VALUES.documentDownloadURL;
                //getDocumentFromAppian(NEW_VALUES.downloadFileConnectedSystem, NEW_VALUES.documentDetails);
                getDocumentFromWeb(NEW_VALUES.documentDownloadURL);
                return;
            }

            if (NEW_VALUES.annotationObject != null || NEW_VALUES.annotationObject != undefined || Object.keys(NEW_VALUES.annotationObject) > 0) {
                highlightTextInPdf({ query: NEW_VALUES.annotationObject.query }, NEW_VALUES.annotationObject);
            }
        });
    }


    // When the text is selected in the PDF, the text will be updated in the current focused Element.
    // if the element is array type (select, multiselect), then the text will be pushed in the json array as a new option.
    window.onTextSelectedInPDF = function(data) {
        //console.log(data, $scope.focusedElement)
        if ($scope.focusedElement == null) {
            return;
        }

        $scope.$apply(function() {
            data = {
                pageNumber: data.pageNumber,
                query: data.query,
                xMax: data.coords.xMax,
                xMin: data.coords.xMin,
                yMax: data.coords.yMax,
                yMin: data.coords.yMin,
                origin: VALUE_ORIGINS[1]
            };

            // currently focused element's type
            switch ($scope.focusedElement.type) {
                case "text":
                    if ($scope.formValues[$scope.focusedElement.name] == undefined) {
                        $scope.formValues[$scope.focusedElement.name] = {};
                    }
                    if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
                        $scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
                    }
                    $scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);
                    break;

                case "select":
                    if ($scope.formValues[$scope.focusedElement.name] == undefined) {
                        $scope.formValues[$scope.focusedElement.name] = [];
                    }
                    data.field = $scope.focusedElement.name;
                    $scope.formValues[$scope.focusedElement.name].push(data);
                    $scope.uiConfig.selectedOptions[$scope.focusedElement.name] = clone(data);
                    break;

                case "multiselect":
                    if ($scope.formValues[$scope.focusedElement.name] == undefined) {
                        $scope.formValues[$scope.focusedElement.name] = [];
                    }
                    data.field = $scope.focusedElement.name;
                    $scope.formValues[$scope.focusedElement.name].push(data);
                    $scope.uiConfig.selectedOptions[$scope.focusedElement.name].push(data);
                    // setTimeout(function() {
                    //     $("#" + $scope.focusedElement.name).selectpicker('refresh');
                    // }, 10);
                    break;

                case "date":
                    if ($scope.formValues[$scope.focusedElement.name] == undefined) {
                        $scope.formValues[$scope.focusedElement.name] = {};
                    }
                    if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
                        $scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
                    }
                    $scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);
                    $scope.formValues[$scope.focusedElement.name].query = Date.parse($scope.formValues[$scope.focusedElement.name].query);
                    break;

                case "number":
                    if ($scope.formValues[$scope.focusedElement.name] == undefined) {
                        $scope.formValues[$scope.focusedElement.name] = {};
                    }
                    if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
                        $scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
                    }
                    $scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);
                    break;

                default:
                    if ($scope.formValues[$scope.focusedElement.name] == undefined) {
                        $scope.formValues[$scope.focusedElement.name] = {};
                    }
                    if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
                        $scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
                    }
                    $scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);
                    break;
            }
        });
    }

    $scope.saveInputTypeValue = function(field, value) {

        if ($scope.isValueChangedInLastFocusedElement) {
            $scope.isValueChangedInLastFocusedElement = false;
            console.log(field, value)

            addValidationErrorsInFormValues();

            if (!TEST_MODE) {

                if (field.type == "search") {
                    Appian.Component.saveValue(onSearch, value);
                } else {
                    Appian.Component.saveValue(onChangeLast, {
                        name: field['name'],
                        fieldDetails: field,
                        newValue: value,
                        //oldValue: oldValue
                    });
                }
                Appian.Component.saveValue(onChange, $scope.formValues);
            }
        }
    }

    function addValidationErrorsInFormValues() {
        Object.keys($scope.formValues).forEach(function(eachKey) {
            $scope.formValues[eachKey].validationResults = undefined; // merge($scope.formValues[eachKey], { validationResults: $scope.formValidationErrors[eachKey] })
            delete $scope.formValues[eachKey].validationResults;
        });

        if (Object.keys($scope.formValidationErrors).length > 0) {
            //console.log($scope.formValidationErrors)
            Object.keys($scope.formValidationErrors).forEach(function(eachKey) {
                if (!Array.isArray($scope.formValues[eachKey])) {
                    $scope.formValues[eachKey] = merge($scope.formValues[eachKey], { validationResults: $scope.formValidationErrors[eachKey] })
                }
            });
        }

        $scope.formValidationErrors = {};
    }

    // watcher on formValues, as soon as any value is changed in formValues, it will update the Appian's "onChange" field.
    $scope.$watch('formValues', function(newValue, oldValue) {
        if ($scope.focusedElement != null && ($scope.uiConfig.supportedWebFields.inputTypes.indexOf($scope.focusedElement.type) > -1 || $scope.focusedElement.type == "search")) {
            $scope.isValueChangedInLastFocusedElement = true;
            return;
        }

        addValidationErrorsInFormValues();

        var updatedResults = convertObjectToAppianArray($scope.formValues);
        //console.log(updatedResults);
        if (!TEST_MODE) {
            Appian.Component.saveValue(onChange, updatedResults);
        }
    }, true);

    // watcher on selectedOptions, as soon as the value is changed in any select type field, it will update the isSelected field on the JSON Obejct.
    $scope.$watch('uiConfig.selectedOptions', function(newValue, oldValue) {
        Object.keys(newValue).forEach(function(eachKey) {
            $scope.formValues[eachKey].rows.forEach(function(eachValueInForm) {
                eachValueInForm.isSelected = false;
            });

            $scope.formValues[eachKey].rows.forEach(function(eachValueInForm) {
                if (Array.isArray(newValue[eachKey])) {
                    newValue[eachKey].forEach(function(eachSelectedValue) {
                        if (_.isEqual(eachSelectedValue, eachValueInForm)) {
                            eachValueInForm.isSelected = true;
                        }
                    })
                } else {
                    if (_.isEqual(newValue[eachKey], eachValueInForm)) {
                        eachValueInForm.isSelected = true;
                    }
                }
            });
        });
    }, true);


    // This function is a parent function which invokes viewer.html's showRectangleByCoordinates (showHighlight) to highlight the text in the PDF.
    function highlightTextInPdf(searchObj, config) {
        //xMin, yMin, xMax  ,yMax

        var objectToSearch = clone(searchObj);
        //console.log(objectToSearch)
        objectToSearch.query = objectToSearch.query.toString();
        objectToSearch.coords = {
            "xMin": objectToSearch.xMin,
            "yMin": objectToSearch.yMin,
            "xMax": objectToSearch.xMax,
            "yMax": objectToSearch.yMax
        };

        if (NEW_VALUES.config.clearCanvasBeforeHighlighting != false) {
            clearOldRectangles();
        }

        if (config.phraseSearch == false) {
            // search specific coordinates
            var objToSearch = {
                pageNumber: objectToSearch.pageNumber,
                coords: objectToSearch.coords,
                query: objectToSearch.query,
                origin: objectToSearch.origin
            }

            //objToSearch
            showRectangleByCoordinates(objToSearch);

        } else {
            // general search without coordinates
            if (objectToSearch == undefined || objectToSearch == null || objectToSearch.query == undefined || objectToSearch.query == null) {
                return;
            }

            var findEvent = "find";

            if (config.highlightAll == true)
                findEvent = "findhighlightallchange";

            if (config.caseSensitive == true)
                findEvent = "findcasesensitivitychange";

            if (config.entireWord == true)
                findEvent = "findentirewordchange";

            //findagain 

            PDFViewerApplication.findController.executeCommand(findEvent, {
                query: objectToSearch.query,
                phraseSearch: config.phraseSearch,
                caseSensitive: config.caseSensitive,
                entireWord: config.entireWord,
                highlightAll: config.highlightAll,
                findPrevious: config.findPrevious
            });
        }
    }

    function getDocumentFromWeb(options) {

        function getBase64(blob) {
            var reader = new FileReader();
            reader.onload = function() {
                var base64data = reader.result;
                openBase64PDF(base64data.split("data:application/pdf;base64,")[1])
            }
            reader.readAsDataURL(blob);
        }

        const xhttp = new XMLHttpRequest();
        xhttp.onload = function() {
            //console.log(this.response);
            getBase64(this.response);
        }
        xhttp.withCredentials = true;
        xhttp.open("GET", options, true);
        xhttp.responseType = 'blob';
        xhttp.send();
    }

    function getDocumentFromAppian(connectedSystem, payload) {
        Appian.Component.invokeClientApi(connectedSystem, "DownloadDocumentClientApi", payload)
            .then(handleTokenResponse, handleTokenError);
    }

    function handleTokenResponse(response) {
        console.log(response)
        var payload = {};
        if (response.type == "INVOCATION_SUCCESS" && response.payload != undefined && response.payload.hasOwnProperty("error")) {
            Appian.Component.setValidations(["Error occured while retrieving the document, Please check if you have sufficient privileges to view it. " + JSON.stringify(response.payload)]);
        }

        if (response.type == "INVOCATION_SUCCESS" && response.payload != undefined && response.payload.hasOwnProperty("documentBase64")) {
            payload = response.payload;
            openBase64PDF(PDF_SUFFIX + payload.documentBase64);
        } else {
            Appian.Component.setValidations(["Unable to retrieve document from Appian, please check documentId", payload.error]);
        }

        return;
    }

    function handleTokenError(response) {
        console.log(response)
        Appian.Component.setValidations(["Error occured with connected system: " + response]);
        return;
    }

    // This function will update the input as per version 1.0's structure
    // like converts array into Key:Objects structure, so the plugin can handle  
    function convertInputArrayInRequiredFormat(inputs) {
        var tempObject = {};

        for (var miles = inputs.formDetails.milestones.length - 1; miles >= 0; miles--) {
            if (inputs.formDetails.milestones[miles].hasOwnProperty("fields") && inputs.formDetails.milestones[miles].fields.length) {
                for (var mileFields = 0; mileFields < inputs.formDetails.milestones[miles].fields.length; mileFields++) {
                    var fieldNameFromFormDetails = inputs.formDetails.milestones[miles].fields[mileFields].name;
                    var fieldTypeFromFormDetails = inputs.formDetails.milestones[miles].fields[mileFields].type;

                    for (var k = inputs.formValues.length - 1; k >= 0; k--) {
                        //inputs.formValues[k].originalQuery = inputs.formValues[k].query;
                        if (inputs.formValues[k].field == fieldNameFromFormDetails) {

                            if ($scope.uiConfig.supportedWebFields.arrayTypes.indexOf(fieldTypeFromFormDetails) > -1) {
                                if (tempObject[fieldNameFromFormDetails] == undefined)
                                    tempObject[fieldNameFromFormDetails] = inputs.formValues[k];
                                //tempObject[inputs.formDetails.milestones[miles].fields[j].name].push(inputs.formValues[k].rows);
                            } else {
                                if (inputs.formValues[k].field == fieldNameFromFormDetails) {
                                    tempObject[inputs.formValues[k].field] = inputs.formValues[k];
                                }
                            }


                        }
                    }
                }
            }
            // for fields within sections
            for (var i = inputs.formDetails.milestones[miles].sections.length - 1; i >= 0; i--) {
                for (var j = inputs.formDetails.milestones[miles].sections[i].fields.length - 1; j >= 0; j--) {
                    // non array objects

                    var fieldNameFromFormDetails = inputs.formDetails.milestones[miles].sections[i].fields[j].name;
                    var fieldTypeFromFormDetails = inputs.formDetails.milestones[miles].sections[i].fields[j].type;


                    for (var k = inputs.formValues.length - 1; k >= 0; k--) {
                        //inputs.formValues[k].originalQuery = inputs.formValues[k].query;
                        if (inputs.formValues[k].field == fieldNameFromFormDetails) {

                            if ($scope.uiConfig.supportedWebFields.arrayTypes.indexOf(fieldTypeFromFormDetails) > -1) {
                                if (tempObject[fieldNameFromFormDetails] == undefined)
                                    tempObject[fieldNameFromFormDetails] = inputs.formValues[k];
                                //tempObject[inputs.formDetails.milestones[miles].sections[i].fields[j].name].push(inputs.formValues[k].rows);
                            } else {
                                if (inputs.formValues[k].field == fieldNameFromFormDetails) {
                                    tempObject[inputs.formValues[k].field] = inputs.formValues[k];
                                }
                            }


                        }
                    }
                }
            }
        }
        inputs.formValues = tempObject;
        return inputs;
    }



    function validateAppianInput(inputs) {

        var appianInputValidationResult = [];

        // if (inputs.downloadFileConnectedSystem == undefined || inputs.downloadFileConnectedSystem == null) {
        //     appianInputValidationResult.push("Required fields are missing: downloadFileConnectedSystem");
        // }

        if (inputs.formDetails == undefined || inputs.formDetails == null) {
            appianInputValidationResult.push("Required fields are missing: formDetails");
        }

        if (inputs.formValues == undefined || inputs.formValues == null) {
            appianInputValidationResult.push("Required fields are missing: formValues");
        }
        if (inputs.config == undefined || inputs.config == null) {
            appianInputValidationResult.push("Required fields are missing: config");
        }


        if (TEST_MODE == false && (inputs.formValues == null || inputs.formValues == undefined || inputs.formValues.length == 0)) {
            Appian.Component.setValidations(appianInputValidationResult);
            return inputs;
        }

        //validating formDetails and values
        inputs.formDetails.milestones.forEach(function(milestone) {
            milestone.sections.forEach(function(section) {
                section.fields.forEach(function(field) {
                    if (inputs.formValues[field.name] == null || inputs.formValues[field.name] == undefined || inputs.formValues[field.name].length == 0 || inputs.formValues[field.name].length == undefined) {
                        return;
                    }

                    switch (field.type) {
                        case "text":

                            break;
                        case "currency":

                            break;

                        case "number":
                            if (inputs.formValues[field.name].query != null && parseFloat(inputs.formValues[field.name].query) == "NaN")
                                appianInputValidationResult.push("Invalid Value in " + field.name + ": should be a number, but " + inputs.formValues[field.name].query + " is given.");
                            break;

                        case "date":
                            // try {
                            //     if (inputs.formValues[field.name].query != null && inputs.formValues[field.name].query != "" && (!field.hasOwnProperty("format") || field.format == "null"))
                            //         appianInputValidationResult.push("Missing 'format': A Valid Moment Date Format is required to parse the date string " + field.name);
                            // } catch (e) {
                            //     console.log(e);
                            // }
                            break;

                        case "select":
                            if (!Array.isArray(inputs.formValues[field.name].rows))
                                appianInputValidationResult.push("Invalid Value: formValue Must be an array for " + field.name);
                            break;

                        case "multiselect":
                            if (!Array.isArray(inputs.formValues[field.name].rows))
                                appianInputValidationResult.push("Invalid Value: formValue Must be an array for " + field.name);
                            break;


                        case "grid":
                            if (!Array.isArray(inputs.formValues[field.name].rows))
                                appianInputValidationResult.push("Invalid Value: formValue Must be an array for " + field.name);
                            break;


                        case "button-group":
                            if (!Array.isArray(inputs.formValues[field.name].rows))
                                appianInputValidationResult.push("Invalid Value: formValue Must be an array for " + field.name);
                            break;
                    }
                });
            });
        });
        console.log(appianInputValidationResult)
        // Set Error Message
        if (TEST_MODE != true && appianInputValidationResult != null && appianInputValidationResult.length > 0) {
            Appian.Component.setValidations(appianInputValidationResult);
        }
        return inputs;
    }


    // This is a wrapper function to extract the fields from milestones and nested sections.
    // handle the Appian input by mapping and segregating the data of each and every field in the required local variables.
    function sanitiseInput(inputs) {
        console.log(inputs)
        if (inputs.formDetails == null || inputs.formDetails == undefined)
            inputs.formDetails = {};

        if (inputs.formValues == null || inputs.formValues == undefined)
            inputs.formValues = {};

        if (inputs.annotationObject == null || inputs.annotationObject == undefined)
            inputs.annotationObject = {
                clearOldRectangles: true
            };

        inputs.formDetails.milestones = orderByFilter(inputs.formDetails.milestones, 'sortOrder')
        var previouslySelected = {};
        $scope.lastSelected = {};
        inputs.formDetails.milestones.forEach(function(eachMilestone) {
            // handle fields inside milestone here
            if (eachMilestone.hasOwnProperty("fields") && eachMilestone.fields.length) {
                eachMilestone.fields.forEach(function(eachField) {
                    sanitiseField(eachField, previouslySelected, inputs);
                });
            }
            eachMilestone.sections.forEach(function(section) {
                section.fields.forEach(function(field) {
                    sanitiseField(field, previouslySelected, inputs)
                });
            });
        });
        return inputs;
    }

    // function is called from sanitiseInput function, this function
    // handles the Appian input by mapping and segregating the data of each and every field in the required local variables.
    function sanitiseField(field, previouslySelected, inputs) {
        // create a watcher on each field separatelly, so that any change in the field will invoke the onChangeLast variable.

        $scope.$watch("formValues." + field['name'], function(newValue, oldValue) {
            // console.log(field.type)

            if (_.isEqual(newValue, oldValue))
                return;

            if ($scope.uiConfig.supportedWebFields.inputTypes.indexOf(field.type) > -1 || field.type == "search") {
                $scope.isValueChangedInLastFocusedElement = true;
                return;
            }
            addValidationErrorsInFormValues();
            if (!TEST_MODE)
                Appian.Component.saveValue(onChangeLast, {
                    name: field['name'],
                    fieldDetails: field,
                    newValue: newValue,
                    oldValue: oldValue
                });

            if (field.type == "search") {
                if (!TEST_MODE)
                    Appian.Component.saveValue(onSearch, newValue);
            }
        }, true);

        previouslySelected[field.name] = [];
        //console.log(inputs.formValues)
        if (inputs.formValues[field.name] == null || inputs.formValues[field.name] == undefined) {
            return;
        } else if (Array.isArray(inputs.formValues[field.name]) && (inputs.formValues[field.name].length == 0 || inputs.formValues[field.name].length == undefined)) {
            return;
        }

        switch (field.type) {
            case "search":

                break;
            case "button-group":

                break;
            case "_":

                break;
            case "grid":

                break;
            case "text":

                break;
            case "currency":

                break;

            case "number":
                if (inputs.formValues[field.name].query.indexOf(".") > -1)
                    inputs.formValues[field.name].query = parseFloat(inputs.formValues[field.name].query)
                else
                    inputs.formValues[field.name].query = parseInt(inputs.formValues[field.name].query)
                break;

            case "date":
                try {
                    //var dateMomentObject = moment(inputs.formValues[field.name].query, field.format); // 1st argument - string, 2nd argument - format
                    //inputs.formValues[field.name].query = dateMomentObject.toDate();
                    inputs.formValues[field.name].query = Date.parse(inputs.formValues[field.name].query);
                } catch (e) {
                    console.log(e);
                }
                break;

            case "select":
                $scope.uiConfig.selectedOptions[field.name] = {};

                updateSelectedOptionsArray(field, inputs.formValues[field.name].rows);
                break;

            case "multiselect":
                $scope.uiConfig.selectedOptions[field.name] = [];

                // setting 10 ms to time so multiselect can load properly
                setTimeout(function() {
                    //$("#" + field.name).selectpicker('refresh');


                    $("#" + field.name).change(function() {
                        // Get newly selected elements
                        var currentlySelected = $(this).val();
                        var newSelections = currentlySelected.filter(function(element) {
                            return previouslySelected[field.name].indexOf(element) == -1;
                        });
                        previouslySelected[field.name] = currentlySelected;

                        if (newSelections.length) {
                            // If there are multiple new selections, we'll take the last in the list
                            $scope.lastSelected[field.name] = newSelections.reverse()[0];
                        }

                        clearOldRectangles();

                        $scope.uiConfig.selectedOptions[field.name].forEach(function(x) {
                            console.log($scope.lastSelected[field.name], x["$$hashKey"])
                            if ($scope.lastSelected[field.name] == x["$$hashKey"]) {
                                setTimeout(function() {
                                    highlightTextInPdf(x, { clearCanvasBeforeHighlighting: false, phraseSearch: false });
                                }, 10);
                            }
                        });
                    });

                }, 10);
                break;

            default:
                console.log("Unsupported formValues (" + field.type + ") found for " + field.name)
                break;
        }

    }

    // this function updates the "$scope.uiConfig.selectedOptions" global variable to handle all the select/multiselect type fields and values.
    function updateSelectedOptionsArray(field, values) {
        if (Array.isArray(values)) {
            values.forEach(function(eachValue) {
                if (eachValue.hasOwnProperty("isSelected") && eachValue.isSelected == true) {
                    if (field.type == "multiselect")
                        $scope.uiConfig.selectedOptions[field.name].push(eachValue);
                    else if (field.type == "select")
                        $scope.uiConfig.selectedOptions[field.name] = eachValue;
                } else {
                    eachValue.isSelected = false;
                }
            })
        } else {
            console.error("updateSelectedOptionsArray failed as 'values' in not an array")
        }
    }

    function openPDF(file) {
        PDFViewerApplication.open(file);
    }

    function openBase64PDF(file) {
        //var res = file; // Base64 String from response shortened

        var pdfData = base64ToUint8Array(file);
        openPDF(pdfData);

        function base64ToUint8Array(base64) {
            var raw = atob(base64);
            var uint8Array = new Uint8Array(raw.length);
            for (var i = 0; i < raw.length; i++) {
                uint8Array[i] = raw.charCodeAt(i);
            }
            return uint8Array;
            //PDFViewerApplication.open(file);
        }
    }

    // Adjust the plugin in Appian's available window
    function adjustHeightOfIframe(height, width) {
        //var heights = window.innerHeight;
        document.getElementById("parent").style.height = height;
        document.getElementById("pdf-js-viewer").setAttribute("height", height.split("px")[0]);

        document.getElementById("dynamic-form").style.height = height;
        document.getElementById("dynamic-form").style["overflow-y"] = "scroll";
        // if (width != undefined && width != null)
        //     document.getElementById("parent").style.width = width;
        //document.getElementById("pdf-js-viewer").setAttribute("width", ((heights * 2) / 3));
    }

    window.getIframeSize = function() {
        adjustHeightOfIframe(iframeHeight, iframeWidth);
        return { iframeHeight: iframeHeight.split("px")[0], iframeWidth: iframeWidth }
    }

    window.getConfig = function() {
        return NEW_VALUES.config
    }

    // JSON Deep Clone an Object
    function clone(obj) {
        var regExp = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
        return JSON.parse(JSON.stringify(obj), function(k, v) {
            if (typeof v === 'string' && regExp.test(v))
                return new Date(v)
            return v;
        })
    }


    // Extracts the button class from style.fieldClass
    $scope.getButtonClass = function(field, index) {
        if (field.hasOwnProperty("style") && field.style.hasOwnProperty("fieldClass")) {
            if (Array.isArray(field.style.fieldClass)) {
                return field.style.fieldClass[index];
            } else {
                return field.style.fieldClass;
            }
        }
    }

    // global function to check if any field has error or not like, required.
    function validateRegexValidations(field, value) {
        if (!(field.hasOwnProperty("validations") && Array.isArray(field.validations) && field.validations.length > 0)) {
            return {
                invalid: false,
                message: ""
            };
        }


        if (value == undefined || value.query == undefined) {
            return {
                invalid: false,
                message: ""
            };
        }

        var validations = field.validations;

        function stringToRegex(s, m) {
            return (m = s.match(/^([\/~@;%#'])(.*?)\1([gimsuy]*)$/)) ? new RegExp(m[2], m[3].split('').filter((i, p, s) => s.indexOf(i) === p).join('')) : new RegExp(s);
        }

        for (var i = 0; i < validations.length; i++) {
            //console.log(stringToRegex(validations[i].regex));
            //console.log(validations[i], new RegExp(stringToRegex(validations[i].regex)), new RegExp(validations[i].regex).test(value.query))

            if (!new RegExp(stringToRegex(validations[i].regex)).test(value.query)) {
                // Appian.Component.setValidations([validations[i].errorMessage]);
                var err = {
                    invalid: true,
                    message: validations[i].errorMessage
                };
                $scope.formValidationErrors[field.name] = err;
                return err;
            }
        }
        //console.log(field, value)

        return {
            invalid: false,
            message: ""
        };
    }

    $rootScope.checkIfFieldValidationError = function(field, data) {
        if (data == undefined || data == null) {
            var err = {
                invalid: true,
                message: "Value can not be blank for " + field.name
            };
            $scope.formValidationErrors[field.name] = err;
            return err;
        }

        if (field.required) {
            if ($scope.uiConfig.supportedWebFields.inputTypes.indexOf(field.type) > -1 && (data.query == null || data.query == undefined || data.query == '')) {
                var err = {
                    invalid: true,
                    message: "Value can not be blank for " + field.name
                };

                $scope.formValidationErrors[field.name] = err;
                return err;
            }

            if (field.type == "select") {
                if ($scope.uiConfig.selectedOptions[field.name].query == undefined) {
                    var err = {
                        invalid: true,
                        message: "Select 1 value for " + field.name
                    }
                    $scope.formValidationErrors[field.name] = err;
                    return err;
                }
            }
            if (field.type == "multiselect") {
                if ($scope.uiConfig.selectedOptions[field.name].length == 0) {
                    var err = {
                        invalid: true,
                        message: "Select atleast 1 value for " + field.name
                    }
                    $scope.formValidationErrors[field.name] = err;
                    return err;
                }
            }
        }
        return validateRegexValidations(field, data);
    }

    // set the section's glypihcons beside the Label when collapsed and expanded.
    $(document).ready(function() {
        // enable tooltips

        // UI section glyphicon updates
        $('div.collapse').on("show.bs.collapse || hide.bs.collapse", function() {
            let glyph = $(this).siblings("div.panel-heading").find('span.fa');
            glyph.hasClass("fa-chevron-up") ? glyph.toggleClass("fa-chevron-down") : glyph.toggleClass("fa-chevron-up");
        });
    });

    // This function converts back the field:Object structure to Appian's array structure
    function convertObjectToAppianArray(data) {
        var arr = [];

        Object.keys(data).forEach(function(each) {
            if (Array.isArray(data[each])) {
                for (var i = data[each].length - 1; i >= 0; i--) {
                    arr.push(data[each][i]);
                }
            } else {
                arr.push(data[each]);
            }
        });

        return arr;
    }

    // Merge two JSON Objects
    var merge = function() {
        var obj = {},
            i = 0,
            il = arguments.length,
            key;
        for (; i < il; i++) {
            for (key in arguments[i]) {
                if (arguments[i].hasOwnProperty(key)) {
                    obj[key] = arguments[i][key];
                }
            }
        }
        return obj;
    };

    // usage:
    // var original = {
    //     a: [1, null, undefined, 0, { a: null }, new Date()],
    //     b: {
    //         c() { return 0 }
    //     }
    // }


    //image001_20210602_083904660_0
});