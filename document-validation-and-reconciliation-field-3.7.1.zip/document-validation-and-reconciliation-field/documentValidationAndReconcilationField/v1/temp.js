window.TEST_VALUES = {
    annotationObject: {
        query: "string to search",
        pageNumber: 1,
        coords: {
            xMin: 20.45,
            xMax: 30.32,
            yMin: 18.8,
            yMax: 19.6,
        },
        phraseSearch: false, // if true then ONLY query will be searched otherwise coordinates will be highlighted
        caseSensitive: false,
        entireWord: false,
        highlightAll: true,
        findPrevious: false
    },
    documentDetails: {
        documentId: 1234,
        username: "mayur"
    },
    onChange: {},
    config: {
        // highlightAtPDFScale: 0.75,
        defaultRectanglePadding: 1,
        clearCanvasBeforeHighlighting: true,
        highlightTextOnElementFocus: true
    },
    downloadFileConnectedSystem: {}, //cons!CONNECTED_SYSTEM
    formDetails: {
        verticalMargin: "10px",
        vSpacingBetweenFields: "5px",
        sections: [{
                label: "Risk Details",
                sortOrder: 1,
                class: "panel panel-primary",
                fields: [{
                        type: "text",
                        name: "UMR",
                        label: "UMR",
                        // class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-md-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        },
                        icon: {
                            visible: true,
                            icon: "lightbulb-o",
                            htmlStyle: "color:red;font-size: 18px"
                        },
                        validations: [{
                                regex: "^[a-zA-Z0-9]{10,12}$",
                                errorMessage: "UMR should be between 10 to 12 characters in length"
                            }
                        ]
                    },
                    {
                        type: "multiselect",
                        name: "Insured",
                        label: "Insured",
                        class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-md-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        },
                        icon: {
                            visible: true,
                            icon: "lightbulb-o",
                            htmlStyle: "color:orange;font-size: 18px"
                        }
                    },
                    {
                        type: "text",
                        name: "Type",
                        label: "Type",
                        class: "form-control",
                        required: false,
                        style: {
                            divClass: "col-md-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        }
                    },
                    {
                        type: "text",
                        name: "Address",
                        label: "Address",
                        class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-md-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        }
                    },
                    {
                        type: "date",
                        name: "Policy_Start_Date",
                        label: "Policy Start Date",
                        class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-md-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        },
                        format: "DD/MM/YYYY"
                    },
                    {
                        type: "date",
                        name: "Policy_End_Date",
                        label: "Policy End Date",
                        class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-md-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        },
                        format: "DD/MM/YYYY"
                    },
                    {
                        type: "currency",
                        name: "Premium",
                        label: "Premium",
                        class: "form-control",
                        symbol: {
                            symbol: "$",
                            htmlStyle: "color:orange;font-size: 18px"
                        },
                        required: true,
                        style: {
                            divClass: "col-md-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        }
                    }
                ]
            },
            {
                label: "Fiscal and Regulatory",
                sortOrder: 2,
                class: "panel panel-info",
                fields: [{
                        type: "text",
                        name: "Country_Of_Origin",
                        label: "Country of Origin",
                        class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-xs-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        }
                    },
                    {
                        type: "text",
                        name: "Regulatory_Risk_Location",
                        label: "Regulatory Risk Location",
                        class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-xs-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        },
                        placeholder: "Regulatory Risk Location"
                    },
                    {
                        type: "text",
                        name: "Regulatory_Client_Classification",
                        label: "Regulatory Client Location",
                        class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-xs-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        }
                    }
                ]
            },
            {
                label: "Subscription Agreement",
                sortOrder: 3,
                class: "panel panel-info",
                fields: [{
                        type: "date",
                        name: "Settlement_Due_Date",
                        label: "Settlement Due Date",
                        class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-xs-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        },
                        format: "DD/MM/YYYY"
                    },
                    {
                        type: "text",
                        name: "Slip_Leader",
                        label: "Slip Leader",
                        class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-xs-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        }
                    }
                ]
            },
            {
                label: "Security Details",
                sortOrder: 4,
                class: "panel panel-success",
                fields: [{
                        type: "text",
                        name: "Order_Hereon",
                        label: "Order Hereon",
                        class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-xs-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        }
                    },
                    {
                        type: "text",
                        name: "Basis_of_Written_Lines",
                        label: "Basis of Written Lines",
                        class: "form-control",
                        required: true,
                        style: {
                            divClass: "col-xs-6",
                            fieldClass: "form-control",
                            labelClass: "text-primary"
                        }
                    }
                ]
            },
            {
                label: "Broker Remuneration & Deductions",
                name: "BrokerRemunerationDeductions",
                sortOrder: 5,
                class: "panel panel-danger",
                fields: [{
                    type: "number",
                    name: "Total_Brokerage",
                    label: "Total Brokerage",
                    class: "form-control",
                    required: true,
                    style: {
                        divClass: "col-xs-6",
                        fieldClass: "form-control",
                        labelClass: "text-primary"
                    },
                    validations: [{
                                regex: "^[0-9.]{1,10}$",
                                errorMessage: "Total Brokerage should be numeric and between 5-6 in length"
                            }
                        ]
                }]
            }
        ],
    },
    formValues: {
        "UMR": {
            query: "B98345029321",
            pageNumber: 1,
            origin: "AUTO",
            coords: {
                xMin: 0.335,
                xMax: 0.441,
                yMin: 0.185,
                yMax: 0.194
            }
        },
        "Insured": [{
                query: "Bosco Inc.",
                pageNumber: 1,
                origin: "AUTO",
                coords: {
                    xMin: 0.333,
                    xMax: 0.499,
                    yMin: 0.239,
                    yMax: 0.332
                }
            },
            {
                query: "Test",
                pageNumber: 3,
                origin: "AUTO",
                coords: {
                    xMin: 0.333,
                    xMax: 0.499,
                    yMin: 0.239,
                    yMax: 0.332
                }
            }
        ],
        "Type": {
            query: "Terrorism and/or Sabotage Reinsurance",
            pageNumber: 1,
            origin: "AUTO",
            coords: {
                xMin: 0.335,
                xMax: 0.631,
                yMin: 0.212,
                yMax: 0.224
            }
        },
        "Country_Of_Origin": {
            query: "PHL",
            pageNumber: 12,
            origin: "AUTO",
            coords: {
                xMin: 0.435,
                xMax: 0.515,
                yMin: 0.232,
                yMax: 0.244
            }
        },
        "Regulatory_Client_Classification": {
            query: "Reinsurance",
            pageNumber: 12,
            origin: "AUTO",
            coords: {
                xMin: 0.436,
                xMax: 0.529,
                yMin: 0.537,
                yMax: 0.547
            }
        },
        "Policy_Start_Date": {
            query: "25/01/2021",
            pageNumber: 1,
            origin: "AUTO",
            coords: {
                xMin: 0.335,
                xMax: 0.853,
                yMin: 0.385,
                yMax: 0.434
            },
            format: "DD/MM/YYYY"
        },
        "Policy_End_Date": {
            query: "24/01/2022",
            pageNumber: 1,
            origin: "AUTO",
            coords: {
                xMin: 0.335,
                xMax: 0.853,
                yMin: 0.385,
                yMax: 0.434
            },
            format: "DD/MM/YYYY"
        },
        "Situation": {
            query: "PHL",
            pageNumber: 1,
            origin: "AUTO",
            coords: {
                xMin: 0.342,
                xMax: 0.871,
                yMin: 0.617,
                yMax: 0.629
            }
        },
        "Order_Hereon": {
            query: "4% of 100%",
            pageNumber: 7,
            origin: "AUTO",
            coords: {
                xMin: 0.345,
                xMax: 0.461,
                yMin: 0.868,
                yMax: 0.877
            }
        },
        "Regulatory_Risk_Location": {
            query: "PHL",
            pageNumber: 12,
            origin: "AUTO",
            coords: {
                xMin: 0.439,
                xMax: 0.519,
                yMin: 0.273,
                yMax: 0.285
            }
        },
        "Premium": {
            query: "1,000,000 PHP",
            pageNumber: 3,
            origin: "AUTO",
            coords: {
                xMin: 0.343,
                xMax: 0.57,
                yMin: 0.711,
                yMax: 0.722
            }
        },
        "Settlement_Due_Date": {
            query: "25/05/2021",
            pageNumber: 10,
            origin: "AUTO",
            coords: {
                xMin: 0.365,
                xMax: 0.468,
                yMin: 0.717,
                yMax: 0.729
            },
            format: "DD/MM/YYYY"
        },
        "Total_Brokerage": {
            query: "20%",
            pageNumber: 13,
            origin: "AUTO",
            coords: {
                xMin: 0.487,
                xMax: 0.525,
                yMin: 0.244,
                yMax: 0.254
            }
        },
        "Slip_Leader": {
            query: "Lloyd Syndicate 0878",
            pageNumber: 9,
            origin: "AUTO",
            coords: {
                xMin: 0.348,
                xMax: 0.495,
                yMin: 0.184,
                yMax: 0.195
            }
        },
        "Address": {
            query: "100 Paseo de Roxas , Legazpi Village, Makati, Metro Manila, Phillipines",
            pageNumber: 1,
            origin: "AUTO",
            coords: {
                xMin: 0.333,
                xMax: 0.499,
                yMin: 0.239,
                yMax: 0.332
            }
        }
    }
}