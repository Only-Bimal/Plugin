// @author: Mayur Agarwal


// Angular initialization
var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, orderByFilter, $rootScope, $http, $sce) {

    // VALUE_ORIGINS is to capture the fields value's orign,
    // Auto means captured from Appian and SELECTED means that they are captured from the plugin
    var VALUE_ORIGINS = ["AUTO", "SELECTED"];

    var PDF_SUFFIX = ""; // "data:application/pdf;base64,";

    // GLOBAL variable which holds all the plugin data
    var NEW_VALUES = {};
    var onChange = "onChange";
    var onChangeLast = "onChangeLast";
    var iframeHeight = "750px",
        iframeWidth = "750px";

    // PDF.JS Global Variables, which are set here by JS utilities
    var PDFViewerApplication, clearOldRectangles, showRectangleByCoordinates;

    // Angular's global variable
    $scope.uiConfig = {
        supportedWebFields: {
            all: ["text", "number", "date", "select", "multiselect", "currency"],
            inputTypes: ["text", "number", "date", "currency"],
            arrayTypes: ["select", "multiselect"]
        },
        selectedOptions: {},
        lastFocusedElement: null,
    }

    // Current Focused element
    $scope.focusedElement = null;
    $scope.isValueChangedInLastFocusedElement = false;
    $scope.formValidationErrors = {};

    //--------IMPORTANT------------
    /*TEST VALUES START:- FOR TESTING MODE (Without Appian)*/
    var TEST_MODE = false;
    var temp;
    // if (TEST_MODE) {
    //     temp = sanitiseInput(validateAppianInput(window.TEST_VALUES));
    //     $scope.formData = temp.formDetails;
    //     $scope.formValues = temp.formValues;

    //     $scope.originalFormValues = clone($scope.formValues);
    //     NEW_VALUES = temp;

    //     setTimeout(function() {
    //         //openPDF("../MRC_SAMPLE.pdf");
    //         getDocumentFromWeb("https://bpmdemo.appcino.com:9999/suite/doc/ioB7821xURit2IUeybKIJd3cTC7pFU8p1kmeOjvF_z4BQXHjovcDxabhOs")
    //     }, 1000);

    //     /*setTimeout(function() {
    //         highlightTextInPdf({
    //             phraseSearch: false,
    //             "pageNumber": 1,
    //             "coords": { "xMin": 0.617, "yMin": 0.129, "xMax": 0.686, "yMax": 0.117 },
    //             "query": ""
    //         })
    //     }, 4000)*/
    // }

    /*TEST VALUES END*/

    // Setting up the above Global variables to initialise the application, they are called from viewer.html file
    window.setPDFViewerApplication = function(data, showHighlight, clearOldRectangle) {
        PDFViewerApplication = data;
        showRectangleByCoordinates = showHighlight;
        clearOldRectangles = clearOldRectangle;

        //call this in last if used in Appian, otherwise comment it to test on local server
        if (!TEST_MODE)
            init();
    }

    // updating the focus (annotations) on zoom change, called from viewer.js (function: zoomIn, lineNo : 1278)
    window.resetAnnotations = function() {
        if ($scope.hasOwnProperty("focusedElement") && $scope.focusedElement != null) {
            setTimeout(function() {
                $scope.onFocusHandler($scope.formValues[$scope.focusedElement.name], $scope.focusedElement);
            }, 1)
        }
    }


    // appian document Id
    var currentDocumentDetails = null;

    // handling the on focus event of each field from index.html
    $scope.onFocusHandler = function(formValue, field) {
        //console.log(formValue, field);
        $scope.uiConfig.lastFocusedElement = clone($scope.focusedElement);
        $scope.focusedElement = clone(field);
        //console.log($scope.uiConfig.lastFocusedElement, $scope.focusedElement);

        if (NEW_VALUES.config.highlightTextOnElementFocus == true) {
            highlightTextInPdf(formValue, {
                phraseSearch: true,
                clearCanvasBeforeHighlighting: false,
                caseSensitive: NEW_VALUES.annotationObject.caseSensitive,
                entireWord: NEW_VALUES.annotationObject.entireWord,
                highlightAll: NEW_VALUES.annotationObject.highlightAll,
                findPrevious: NEW_VALUES.annotationObject.findPrevious,
            });
        }

        if ($scope.uiConfig.supportedWebFields.inputTypes.indexOf(field.type) > -1) {
            highlightTextInPdf(formValue, {
                phraseSearch: false,
                clearCanvasBeforeHighlighting: true
            });
        } else {
            $scope.onSelectHandler(formValue, field, true);
        }
    }

    // handling the select/multiselect change event
    $scope.onSelectHandler = function(formValue, field, onFocus, data) {
        // onFocus != true, means original selection change event.
        //console.log(data)
        if (onFocus != true) {
            $scope.uiConfig.lastFocusedElement = clone($scope.focusedElement);
            $scope.focusedElement = clone(field);
        }

        // handle multiple select issue, of all rects in one page
        // if(onFocus == true){
        //     return
        // }

        //console.log($scope.uiConfig.selectedOptions[field.name]);

        if (field.type == "select") {
            if ($scope.uiConfig.selectedOptions[field.name] != null &&
                Array.isArray($scope.uiConfig.selectedOptions[field.name]) == false &&
                $scope.uiConfig.selectedOptions[field.name].hasOwnProperty("pageNumber")) {

                highlightTextInPdf($scope.uiConfig.selectedOptions[field.name], { clearCanvasBeforeHighlighting: true, phraseSearch: false });
            }
        } else if (field.type == "multiselect") {
            //clearing previous rects, if any;
        }
    }

    // init called to initiate the Appian part, like fetching document from the Appian KC.
    function init() {
        Appian.Component.onNewValue(function(newValues) {
            console.log("Mayur Agarwal: Document Ready", newValues, PDFViewerApplication);
            Appian.Component.setValidations([]);
            try {
                NEW_VALUES = sanitiseInput(validateAppianInput(newValues));
            } catch (e) {
                console.error(e)
            }

            $scope.$apply(function() {
                $scope.formData = NEW_VALUES.formDetails;
                $scope.formValues = NEW_VALUES.formValues;
                $scope.originalFormValues = clone($scope.formValues);
            });


            if (NEW_VALUES.height != "auto" && NEW_VALUES.height != null) {
                iframeHeight = NEW_VALUES.height;
            } else {
                iframeHeight = "750px";
            }

            adjustHeightOfIframe(iframeHeight, iframeWidth);

            // should be loaded in last of this function
            // if (!_.isEqual(currentDocumentDetails, NEW_VALUES.downloadDocumentDetails)) {
            //     console.log("New Document, refreshing viewport");
            //     currentDocumentDetails = NEW_VALUES.downloadDocumentDetails;
            //     //getDocumentFromAppian(NEW_VALUES.downloadFileConnectedSystem, NEW_VALUES.documentDetails);
            //     getDocumentFromWeb(NEW_VALUES.downloadDocumentDetails);
            //     return;
            // }

            if (!_.isEqual(currentDocumentDetails, NEW_VALUES.documentDownloadURL)) {
                console.log("New Document, refreshing viewport");
                currentDocumentDetails = NEW_VALUES.documentDownloadURL;
                //getDocumentFromAppian(NEW_VALUES.downloadFileConnectedSystem, NEW_VALUES.documentDetails);
                getDocumentFromWeb(NEW_VALUES.documentDownloadURL);
                return;
            }

            if (NEW_VALUES.annotationObject != null || NEW_VALUES.annotationObject != undefined || Object.keys(NEW_VALUES.annotationObject) > 0) {
                highlightTextInPdf({ query: NEW_VALUES.annotationObject.query }, NEW_VALUES.annotationObject);
            }
        });
    }

    var merge = function() {
        var obj = {},
            i = 0,
            il = arguments.length,
            key;
        for (; i < il; i++) {
            for (key in arguments[i]) {
                if (arguments[i].hasOwnProperty(key)) {
                    obj[key] = arguments[i][key];
                }
            }
        }
        return obj;
    };

    window.onTextSelectedInPDF = function(data) {
        //console.log(data, $scope.focusedElement)
        if ($scope.focusedElement == null) {
            return;
        }

        $scope.$apply(function() {
            data = {
                pageNumber: data.pageNumber,
                query: data.query,
                xMax: data.coords.xMax,
                xMin: data.coords.xMin,
                yMax: data.coords.yMax,
                yMin: data.coords.yMin,
                origin: VALUE_ORIGINS[1]
            };

            // currently focused element's type
            switch ($scope.focusedElement.type) {
                case "text":
                    if ($scope.formValues[$scope.focusedElement.name] == undefined) {
                        $scope.formValues[$scope.focusedElement.name] = {};
                    }
                    if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
                        $scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
                    }
                    $scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);
                    break;

                case "select":
                    if ($scope.formValues[$scope.focusedElement.name] == undefined) {
                        $scope.formValues[$scope.focusedElement.name] = [];
                    }
                    data.field = $scope.focusedElement.name;
                    $scope.formValues[$scope.focusedElement.name].push(data);
                    $scope.uiConfig.selectedOptions[$scope.focusedElement.name] = clone(data);
                    break;

                case "multiselect":
                    if ($scope.formValues[$scope.focusedElement.name] == undefined) {
                        $scope.formValues[$scope.focusedElement.name] = [];
                    }
                    data.field = $scope.focusedElement.name;
                    $scope.formValues[$scope.focusedElement.name].push(data);
                    $scope.uiConfig.selectedOptions[$scope.focusedElement.name].push(data);
                    // setTimeout(function() {
                    //     $("#" + $scope.focusedElement.name).selectpicker('refresh');
                    // }, 10);
                    break;

                case "date":
                    if ($scope.formValues[$scope.focusedElement.name] == undefined) {
                        $scope.formValues[$scope.focusedElement.name] = {};
                    }
                    if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
                        $scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
                    }
                    $scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);
                    $scope.formValues[$scope.focusedElement.name].query = Date.parse($scope.formValues[$scope.focusedElement.name].query);
                    break;

                case "number":
                    if ($scope.formValues[$scope.focusedElement.name] == undefined) {
                        $scope.formValues[$scope.focusedElement.name] = {};
                    }
                    if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
                        $scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
                    }
                    $scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);
                    break;

                default:
                    if ($scope.formValues[$scope.focusedElement.name] == undefined) {
                        $scope.formValues[$scope.focusedElement.name] = {};
                    }
                    if (!$scope.formValues[$scope.focusedElement.name].hasOwnProperty("originalValues")) {
                        $scope.formValues[$scope.focusedElement.name].originalValues = clone($scope.formValues[$scope.focusedElement.name]);
                    }
                    $scope.formValues[$scope.focusedElement.name] = merge($scope.formValues[$scope.focusedElement.name], data);
                    break;
            }
        });
    }

    function addValidationErrorsInFormValues() {+
        Object.keys($scope.formValues).forEach(function(eachKey) {
            $scope.formValues[eachKey].validationResults = undefined; // merge($scope.formValues[eachKey], { validationResults: $scope.formValidationErrors[eachKey] })
            delete $scope.formValues[eachKey].validationResults;
        });

        if (Object.keys($scope.formValidationErrors).length > 0) {
            //console.log($scope.formValidationErrors)
            Object.keys($scope.formValidationErrors).forEach(function(eachKey) {
                if (!Array.isArray($scope.formValues[eachKey])) {
                    $scope.formValues[eachKey] = merge($scope.formValues[eachKey], { validationResults: $scope.formValidationErrors[eachKey] })
                }
            });
        }

        $scope.formValidationErrors = {};
    }

    $scope.saveInputTypeValue = function(field, value) {
        if ($scope.isValueChangedInLastFocusedElement) {
            $scope.isValueChangedInLastFocusedElement = false;
            //console.log(field, value)

            addValidationErrorsInFormValues();

            if (!TEST_MODE) {
                Appian.Component.saveValue(onChange, $scope.formValues);
                Appian.Component.saveValue(onChangeLast, {
                    name: field['name'],
                    fieldDetails: field,
                    newValue: value,
                    //oldValue: oldValue
                });
            }
        }
    }

    $scope.$watch('formValues', function(newValue, oldValue) {
        //console.log(newValue, oldValue)
        //var updatedResults = convertObjectToAppianArray($scope.formValues);

        if ($scope.focusedElement != null && $scope.uiConfig.supportedWebFields.inputTypes.indexOf($scope.focusedElement.type) > -1) {
            $scope.isValueChangedInLastFocusedElement = true;
            return;
        }

        addValidationErrorsInFormValues()

        if (!TEST_MODE) {
            $scope.isValueChangedInLastFocusedElement = false;
            Appian.Component.saveValue(onChange, $scope.formValues);
        }
        $scope.formValidationErrors = {};
    }, true);

    $scope.$watch('uiConfig.selectedOptions', function(newValue, oldValue) {
        Object.keys(newValue).forEach(function(eachKey) {
            $scope.formValues[eachKey].forEach(function(eachValueInForm) {
                eachValueInForm.isSelected = false;
            });

            $scope.formValues[eachKey].forEach(function(eachValueInForm) {
                if (Array.isArray(newValue[eachKey])) {
                    newValue[eachKey].forEach(function(eachSelectedValue) {
                        if (_.isEqual(eachSelectedValue, eachValueInForm)) {
                            eachValueInForm.isSelected = true;
                        }
                    })
                } else {
                    if (_.isEqual(newValue[eachKey], eachValueInForm)) {
                        eachValueInForm.isSelected = true;
                    }
                }
            });
        });
    }, true);

    function highlightTextInPdf(searchObj, config) {
        //xMin, yMin, xMax  ,yMax

        var objectToSearch = clone(searchObj);

        objectToSearch.query = objectToSearch.query.toString();
        objectToSearch.coords = {
            "xMin": objectToSearch.coords.xMin,
            "yMin": objectToSearch.coords.yMin,
            "xMax": objectToSearch.coords.xMax,
            "yMax": objectToSearch.coords.yMax
        };

        if (NEW_VALUES.config.clearCanvasBeforeHighlighting != false) {
            clearOldRectangles();
        }

        if (config.phraseSearch == false) {
            // search specific coordinates
            var objToSearch = {
                pageNumber: objectToSearch.pageNumber,
                coords: objectToSearch.coords,
                query: objectToSearch.query,
                origin: objectToSearch.origin
            }

            showRectangleByCoordinates(objToSearch);

        } else {
            // general search without coordinates
            if (objectToSearch == undefined || objectToSearch == null || objectToSearch.query == undefined || objectToSearch.query == null) {
                return;
            }

            var findEvent = "find";

            if (config.highlightAll == true)
                findEvent = "findhighlightallchange";

            if (config.caseSensitive == true)
                findEvent = "findcasesensitivitychange";

            if (config.entireWord == true)
                findEvent = "findentirewordchange";

            //findagain 

            PDFViewerApplication.findController.executeCommand(findEvent, {
                query: objectToSearch.query,
                phraseSearch: config.phraseSearch,
                caseSensitive: config.caseSensitive,
                entireWord: config.entireWord,
                highlightAll: config.highlightAll,
                findPrevious: config.findPrevious
            });
        }
    }

    function getDocumentFromWeb(url) {

        function getBase64(blob) {
            var reader = new FileReader();
            reader.onload = function() {
                var base64data = reader.result;
                openBase64PDF(base64data.split("data:application/pdf;base64,")[1])
            }
            reader.readAsDataURL(blob);
        }

        const xhttp = new XMLHttpRequest();
        xhttp.onload = function() {
            //console.log(this.response);
            getBase64(this.response);
            // document.getElementById("demo").innerHTML =
            //     this.responseText;
        }
        xhttp.withCredentials = true;
        xhttp.open("GET", url, true);
        xhttp.responseType = 'blob';
        xhttp.send();
    }

    // function getDocumentFromAppian(connectedSystem, payload) {
    //     Appian.Component.invokeClientApi(connectedSystem, "DownloadDocumentClientApi", payload)
    //         .then(handleTokenResponse, handleTokenError);
    // }

    // function handleTokenResponse(response) {
    //     console.log(response)
    //     var payload = {};
    //     if (response.type == "INVOCATION_SUCCESS" && response.payload != undefined && response.payload.hasOwnProperty("error")) {}

    //     if (response.type == "INVOCATION_SUCCESS" && response.payload != undefined && response.payload.hasOwnProperty("documentBase64")) {
    //         payload = response.payload;
    //         openBase64PDF(PDF_SUFFIX + payload.documentBase64);
    //     } else {
    //         Appian.Component.setValidations(["Unable to retrieve document from Appian, please check documentDownloadURL and username"]);
    //     }

    //     return;
    // }

    // function handleTokenError(response) {
    //     console.log(response)
    //     Appian.Component.setValidations(["Error occured with connected system: " + response]);
    //     return;
    // }

    function convertObjectToAppianArray(data) {
        var arr = [];

        Object.keys(data).forEach(function(each) {
            if (Array.isArray(data[each])) {
                for (var i = data[each].length - 1; i >= 0; i--) {
                    arr.push(data[each][i]);
                }
            } else {
                arr.push(data[each]);
            }
        });

        return arr;
    }

    function validateAppianInput(inputs) {

        var appianInputValidationResult = [];

        // if (inputs.downloadFileConnectedSystem == undefined || inputs.downloadFileConnectedSystem == null) {
        //     appianInputValidationResult.push("Required fields are missing: downloadFileConnectedSystem");
        // }

        if (inputs.formDetails == undefined || inputs.formDetails == null) {
            appianInputValidationResult.push("Required fields are missing: formDetails");
        }

        if (inputs.formValues == undefined || inputs.formValues == null) {
            appianInputValidationResult.push("Required fields are missing: formValues");
        }
        if (inputs.config == undefined || inputs.config == null) {
            appianInputValidationResult.push("Required fields are missing: config");
        }


        if (TEST_MODE == false && (inputs.formValues == null || inputs.formValues == undefined || inputs.formValues.length == 0)) {
            Appian.Component.setValidations(appianInputValidationResult);
            return inputs;
        }

        //validating formDetails and values        
        inputs.formDetails.sections.forEach(function(section) {
            section.fields.forEach(function(field) {
                if (inputs.formValues[field.name] == null || inputs.formValues[field.name] == undefined || inputs.formValues[field.name].length == 0 || inputs.formValues[field.name].length == undefined) {
                    return;
                }

                switch (field.type) {
                    case "text":

                        break;

                    case "number":
                        if (inputs.formValues[field.name].query != null && parseFloat(inputs.formValues[field.name].query) == "NaN")
                            appianInputValidationResult.push("Invalid Value in " + field.name + ": should be a number, but " + inputs.formValues[field.name].query + " is given.");
                        break;

                    case "currency":
                        // if (inputs.formValues[field.name].query != null && parseFloat(inputs.formValues[field.name].query) == "NaN")
                        //     appianInputValidationResult.push("Invalid Value in " + field.name + ": should be a number, but " + inputs.formValues[field.name].query + " is given.");
                        break;

                    case "date":
                        // try {
                        //     if (inputs.formValues[field.name].query != null && inputs.formValues[field.name].query != "" && (!field.hasOwnProperty("format") || field.format == "null"))
                        //         appianInputValidationResult.push("Missing 'format': A Valid Moment Date Format is required to parse the date string " + field.name);
                        // } catch (e) {
                        //     console.log(e);
                        // }
                        break;

                    case "select":
                        if (!Array.isArray(inputs.formValues[field.name]))
                            appianInputValidationResult.push("Invalid Value: formValue Must be an array for " + field.name);
                        break;

                    case "multiselect":
                        if (!Array.isArray(inputs.formValues[field.name]))
                            appianInputValidationResult.push("Invalid Value: formValue Must be an array for " + field.name);
                        break;
                }
            });
        });
        console.log(appianInputValidationResult)
        // Set Error Message
        if (TEST_MODE != true && appianInputValidationResult != null && appianInputValidationResult.length > 0) {
            Appian.Component.setValidations(appianInputValidationResult);
        }
        return inputs;
    }

    function sanitiseInput(inputs) {
        if (inputs.formDetails == null || inputs.formDetails == undefined)
            inputs.formDetails = {};

        if (inputs.formValues == null || inputs.formValues == undefined)
            inputs.formValues = {};

        if (inputs.annotationObject == null || inputs.annotationObject == undefined)
            inputs.annotationObject = {
                clearOldRectangles: true
            };

        inputs.formDetails.sections = orderByFilter(inputs.formDetails.sections, 'sortOrder')
        var previouslySelected = {};
        $scope.lastSelected = {};
        inputs.formDetails.sections.forEach(function(section) {
            section.fields.forEach(function(field) {
                try {
                    $scope.$watch("formValues." + field['name'], function(newValue, oldValue) {
                        if (_.isEqual(newValue, oldValue))
                            return;



                        if ($scope.uiConfig.supportedWebFields.inputTypes.indexOf(field.type) > -1) {
                            $scope.isValueChangedInLastFocusedElement = true;
                            return;
                        }

                        addValidationErrorsInFormValues()

                        if (!TEST_MODE) {
                            $scope.isValueChangedInLastFocusedElement = false;
                            Appian.Component.saveValue(onChangeLast, {
                                name: field['name'],
                                fieldDetails: field,
                                newValue: newValue,
                                //oldValue: oldValue
                            });
                        }
                    }, true);
                } catch (e) { console.log("field name cannot contain special character and space: " + field["name"]) }

                previouslySelected[field.name] = [];
                if (inputs.formValues[field.name] == null || inputs.formValues[field.name] == undefined) {
                    return;
                } else if (Array.isArray(inputs.formValues[field.name]) && (inputs.formValues[field.name].length == 0 || inputs.formValues[field.name].length == undefined)) {
                    return;
                }

                switch (field.type) {
                    case "text":

                        break;

                    case "number":
                        if (inputs.formValues[field.name].query.indexOf(".") > -1)
                            inputs.formValues[field.name].query = parseFloat(inputs.formValues[field.name].query)
                        else
                            inputs.formValues[field.name].query = parseInt(inputs.formValues[field.name].query)
                        break;


                    case "currency":
                        // if (inputs.formValues[field.name].query.indexOf(".") > -1)
                        //     inputs.formValues[field.name].query = parseFloat(inputs.formValues[field.name].query)
                        // else
                        //     inputs.formValues[field.name].query = parseInt(inputs.formValues[field.name].query)
                        break;

                    case "date":
                        try {
                            //var dateMomentObject = moment(inputs.formValues[field.name].query, field.format); // 1st argument - string, 2nd argument - format
                            //inputs.formValues[field.name].query = dateMomentObject.toDate();
                            inputs.formValues[field.name].query = Date.parse(inputs.formValues[field.name].query);
                        } catch (e) {
                            console.log(e);
                        }
                        break;

                    case "select":
                        $scope.uiConfig.selectedOptions[field.name] = {};

                        updateSelectedOptionsArray(field, inputs.formValues[field.name]);
                        break;

                    case "multiselect":
                        $scope.uiConfig.selectedOptions[field.name] = [];

                        // setting 10 ms to time so multiselect can load properly
                        setTimeout(function() {
                            //$("#" + field.name).selectpicker('refresh');


                            $("#" + field.name).change(function() {
                                // Get newly selected elements
                                var currentlySelected = $(this).val();
                                var newSelections = currentlySelected.filter(function(element) {
                                    return previouslySelected[field.name].indexOf(element) == -1;
                                });
                                previouslySelected[field.name] = currentlySelected;

                                if (newSelections.length) {
                                    // If there are multiple new selections, we'll take the last in the list
                                    $scope.lastSelected[field.name] = newSelections.reverse()[0];
                                }

                                clearOldRectangles();

                                $scope.uiConfig.selectedOptions[field.name].forEach(function(x) {
                                    if ($scope.lastSelected[field.name] == x["$$hashKey"]) {
                                        setTimeout(function() {
                                            highlightTextInPdf(x, { clearCanvasBeforeHighlighting: false, phraseSearch: false });
                                        }, 10);
                                    }
                                });
                            });

                        }, 10);
                        break;

                    default:
                        console.log("Unsupported formValues (" + field.type + ") found for " + field.name)
                        break;
                }

            });
        });
        return inputs;
    }

    function updateSelectedOptionsArray(field, values) {
        if (Array.isArray(values)) {
            values.forEach(function(eachValue) {
                if (eachValue.hasOwnProperty("isSelected") && eachValue.isSelected == true) {
                    if (field.type == "multiselect")
                        $scope.uiConfig.selectedOptions[field.name].push(eachValue);
                    else if (field.type == "select")
                        $scope.uiConfig.selectedOptions[field.name] = eachValue;
                } else {
                    eachValue.isSelected = false;
                }
            })
        } else {
            console.error("updateSelectedOptionsArray failed as 'values' in not an array")
        }
    }

    function openPDF(file) {

        PDFViewerApplication.open(file);
    }

    function openBase64PDF(file) {
        var pdfData = base64ToUint8Array(file);
        openPDF(pdfData);

        function base64ToUint8Array(base64) {
            var raw = atob(base64);
            var uint8Array = new Uint8Array(raw.length);
            for (var i = 0; i < raw.length; i++) {
                uint8Array[i] = raw.charCodeAt(i);
            }
            return uint8Array;
        }
    }

    function adjustHeightOfIframe(height, width) {
        //var heights = window.innerHeight;
        document.getElementById("parent").style.height = height;
        document.getElementById("pdf-js-viewer").setAttribute("height", height.split("px")[0]);

        document.getElementById("dynamic-form").style.height = height;
        document.getElementById("dynamic-form").style["overflow-y"] = "scroll";
        // if (width != undefined && width != null)
        //     document.getElementById("parent").style.width = width;
        //document.getElementById("pdf-js-viewer").setAttribute("width", ((heights * 2) / 3));
    }

    window.getIframeSize = function() {
        adjustHeightOfIframe(iframeHeight, iframeWidth);
        return { iframeHeight: iframeHeight.split("px")[0], iframeWidth: iframeWidth }
    }

    window.getConfig = function() {
        return NEW_VALUES.config
    }

    function clone(obj) {
        var regExp = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
        return JSON.parse(JSON.stringify(obj), function(k, v) {
            if (typeof v === 'string' && regExp.test(v))
                return new Date(v)
            return v;
        })
    }

    function validateRegexValidations(field, value) {
        if (!(field.hasOwnProperty("validations") && Array.isArray(field.validations) && field.validations.length > 0)) {
            return {
                invalid: false,
                message: ""
            };
        }


        if (value == undefined || value.query == undefined) {
            return {
                invalid: false,
                message: ""
            };
        }

        var validations = field.validations;

        function stringToRegex(s, m) {
            return (m = s.match(/^([\/~@;%#'])(.*?)\1([gimsuy]*)$/)) ? new RegExp(m[2], m[3].split('').filter((i, p, s) => s.indexOf(i) === p).join('')) : new RegExp(s);
        }

        for (var i = 0; i < validations.length; i++) {
            //console.log(stringToRegex(validations[i].regex));
            //console.log(validations[i], new RegExp(stringToRegex(validations[i].regex)), new RegExp(validations[i].regex).test(value.query))

            if (!new RegExp(stringToRegex(validations[i].regex)).test(value.query)) {
                // Appian.Component.setValidations([validations[i].errorMessage]);
                var err = {
                    invalid: true,
                    message: validations[i].errorMessage
                };
                $scope.formValidationErrors[field.name] = err;
                return err;
            }
        }
        //console.log(field, value)

        return {
            invalid: false,
            message: ""
        };
    }

    $scope.checkIfFieldValidationError = function(field, data) {
        if (data == undefined || data == null) {
            var err = {
                invalid: true,
                message: "Value can not be blank for " + field.name
            };
            $scope.formValidationErrors[field.name] = err;
            return err;
        }

        if (field.required) {
            if ($scope.uiConfig.supportedWebFields.inputTypes.indexOf(field.type) > -1 && (data.query == null || data.query == undefined || data.query == '')) {
                var err = {
                    invalid: true,
                    message: "Value can not be blank for " + field.name
                };

                $scope.formValidationErrors[field.name] = err;
                return err;
            }

            if (field.type == "select") {
                if ($scope.uiConfig.selectedOptions[field.name].query == undefined) {
                    var err = {
                        invalid: true,
                        message: "Select 1 value for " + field.name
                    }
                    $scope.formValidationErrors[field.name] = err;
                    return err;
                }
            }
            if (field.type == "multiselect") {
                if ($scope.uiConfig.selectedOptions[field.name].length == 0) {
                    var err = {
                        invalid: true,
                        message: "Select atleast 1 value for " + field.name
                    }
                    $scope.formValidationErrors[field.name] = err;
                    return err;
                }
            }
        }
        return validateRegexValidations(field, data);
    }

});