﻿//#region Utility Methods
// Make date picker  from a text box
function makeDatePicker(datePickerControl, minimumDate, objectToCheck) {
	if (!minimumDate) { minimumDate = "01/01/1900"; }

	var dateOptions = {
		format: "MM dd, yyyy",
		maxViewMode: 2,
		autoclose: true,
		todayHighlight: true,
		todayBtn: "linked",
		startDate: minimumDate,
		endDate: "12/31/2700",
		templates: {
			leftArrow: '<i class="glyphicon glyphicon-arrow-left"></i>',
			rightArrow: '<i class="glyphicon glyphicon-arrow-right"></i>'
		}
	};

	var dateControl = getJQueryControl(datePickerControl);
	// Date-control will be readonly
	dateControl.attr("readonly", "readonly");
	// Remove if already there
	dateControl.datepicker('destroy');
	var picker = dateControl.datepicker(dateOptions);
	picker.on("hide.bs.modal", function (e) {
		// Stop bootstrap event for dialog to be triggered
		e.preventDefault();
		if (objectToCheck) { objectToCheck.isPicker = true; }
	});
	// Return the original jQuery control
	return dateControl;
}

// #region String Methods

// #region StartsWith PolyFill

/*! https://mths.be/startswith v0.2.0 by @mathias */
if (!String.prototype.startsWith) {
	(function () {
		'use strict'; // needed to support `apply`/`call` with `undefined`/`null`
		var defineProperty = (function () {
			// IE 8 only supports `Object.defineProperty` on DOM elements
			try {
				var object = {};
				var $defineProperty = Object.defineProperty;
				var result = $defineProperty(object, object, object) && $defineProperty;
			} catch (error) { }
			return result;
		}());
		var toString = {}.toString;
		var startsWith = function (search) {
			if (this == null) {
				throw TypeError();
			}
			var string = String(this);
			if (search && toString.call(search) == '[object RegExp]') {
				throw TypeError();
			}
			var stringLength = string.length;
			var searchString = String(search);
			var searchLength = searchString.length;
			var position = arguments.length > 1 ? arguments[1] : undefined;
			// `ToInteger`
			var pos = position ? Number(position) : 0;
			if (pos != pos) { // better `isNaN`
				pos = 0;
			}
			var start = Math.min(Math.max(pos, 0), stringLength);
			// Avoid the `indexOf` call if no match is possible
			if (searchLength + start > stringLength) {
				return false;
			}
			var index = -1;
			while (++index < searchLength) {
				if (string.charCodeAt(start + index) != searchString.charCodeAt(index)) {
					return false;
				}
			}
			return true;
		};
		if (defineProperty) {
			defineProperty(String.prototype, 'startsWith', {
				'value': startsWith,
				'configurable': true,
				'writable': true
			});
		} else {
			String.prototype.startsWith = startsWith;
		}
	}());
}

if (!String.prototype.endsWith) {
	String.prototype.endsWith = function (searchString, position) {
		var subjectString = this.toString();
		if (typeof position !== 'number' || !isFinite(position) || Math.floor(position) !== position || position > subjectString.length) { position = subjectString.length; }
		position -= searchString.length;
		var lastIndex = subjectString.lastIndexOf(searchString, position);
		return lastIndex !== -1 && lastIndex === position;
	};
}

// #endregion

function getRandomString(length) {
	var s = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	return Array(length).join().split(',').map(function () { return s.charAt(Math.floor(Math.random() * s.length)); }).join('');
}

// Replace all in string
String.prototype.replaceEverywhere = function (findWhat, replaceWith) {
	var stringValue = this;

	while (stringValue.indexOf(findWhat) > -1) { stringValue = stringValue.replace(findWhat, replaceWith); }
	return stringValue;
};
function toYesNoString(stringToChange) {
	var strValue = $.trim(stringToChange).toLowerCase();
	var valueToReturn;

	switch (strValue) {
		case "true": valueToReturn = "Yes"; break;
		case "yes": valueToReturn = "Yes"; break;
		case "1": valueToReturn = "Yes"; break;
		case "false": valueToReturn = "No"; break;
		case "no": valueToReturn = "No"; break;
		case "0": valueToReturn = "No"; break;
		case "y": valueToReturn = "Yes"; break;
		case "n": valueToReturn = "No"; break;
		default: valueToReturn = stringToChange; break;
	}
	return valueToReturn;
};

String.prototype.toYesNoString = function () { return toYesNoString(this.toString()); };
Boolean.prototype.toYesNoString = function () { return toYesNoString(this.toString()); };

String.prototype.toBoolean = function () { return toBoolean(this); };

/*Changes camel case to a human readable format. So helloWorld, hello-world and hello_world becomes "Hello World". */
String.prototype.toProperWords = function () {
	var output = "";
	var str = this;
	var len = str.length;
	var character;

	for (var i = 0; i < len; i++) {
		character = str.charAt(i);

		if (i === 0) { output += character.toUpperCase(); }
		else if (character !== character.toLowerCase() && character === character.toUpperCase()) { output += " " + character; }
		else if (character === "-" || character === "_") { output += " "; }
		else { output += character; }
	}
	return output;
};

function splitStringOnLength(splittedString, lengthRequired) {
	var newArray = [];
	var start = 0;
	var end = lengthRequired;
	while (start < splittedString.length) {
		newArray.push(splittedString.substring(start, end));
		start = start + lengthRequired;
		end = end + lengthRequired;
	}

	return newArray;
}

// Get the indices where the characters/string occurs
if (!String.prototype.getIndicesOf) {
	String.prototype.getIndicesOf = function getIndicesOf(stringToSearch, caseSensitive) {
		var originalString = this;
		var originalLength = originalString.length;
		if (originalLength === 0) { return []; }

		var startIndex = 0;
		var index;
		var indices = [];

		if (!caseSensitive) { stringToSearch = stringToSearch.toLowerCase(); originalString = originalString.toLowerCase(); }

		index = stringToSearch.indexOf(originalString, startIndex);
		while (index > -1) {
			indices.push(index);
			startIndex = index + originalLength;
			index = stringToSearch.indexOf(originalString, startIndex);
		}
		return indices;
	};
}

// Get the substrings based on search criteria, substring length and string search set
if (!String.prototype.getSubstrings) {
	String.prototype.getSubstrings = function getSubstrings(searchPattern, requiredLength, searchSet, caseSensitive) {
		var originalString = this;
		var originalLength = originalString.length;
		if (originalLength === 0) { return []; }
		// Mandatory Part
		var regExString = searchPattern;//+{'+
		// Search set
		if (searchSet) { regExString += '[' + searchSet + ']'; }

		// Required Length
		if (requiredLength && $.trim(requiredLength) && $.isNumeric(requiredLength)) {
			requiredLength = parseInt(requiredLength);
			regExString += !searchSet ? '{0,' + requiredLength + '}' : '{' + requiredLength + '}';
		}

		// Reg Ex flag
		var regFlags = 'g';
		if (!caseSensitive) { regFlags += 'i'; }

		var regExp = new RegExp(regExString, regFlags);

		var returnValue = originalString.match(regExp);
		// Never return undefined or null
		return !returnValue ? [] : returnValue;
	};
}

// Parse string to a number
if (!String.prototype.toDouble) {
	String.prototype.toDouble = function toDouble(decimalPlaces) {
		var returnValue;
		var str = this;
		// str is null, undefined or blank, return 0.0
		if (!str || $.trim(str) === "") { returnValue = 0.0; }
		else {
			// Try to parse it
			var retValue = parseFloat(str);
			// If Not A Number, return 0.0
			if (isNaN(retValue)) { returnValue = 0.0; }
			// Otherwise a valid number is found, return the number
			else { returnValue = retValue; }
		}
		// If no of decimal places specified then fix the value
		if (decimalPlaces) { returnValue = returnValue.toFixed(decimalPlaces); }
		return parseFloat(returnValue);
	};
}
// #endregion

//#region Format the numbers according to format string
/**
* Formats the number according to the 'format' string;
* adheres to the American number standard where a comma
* is inserted after every 3 digits.
*  note: there should be only 1 contiguous number in the format,
* where a number consists of digits, period, and commas
*        any other characters can be wrapped around this number, including '$', '%', or text
*        examples (123456.789):
*          '0′ - (123456) show only digits, no precision
*          '0.00′ - (123456.78) show only digits, 2 precision
*          '0.0000′ - (123456.7890) show only digits, 4 precision
*          '0,000′ - (123,456) show comma and digits, no precision
*          '0,000.00′ - (123,456.78) show comma and digits, 2 precision
*          '0,0.00′ - (123,456.78) shortcut method, show comma and digits, 2 precision
*
* @method format
* @param format {string} the way you would like to format this text
* @return {string} the formatted number
* @public
*/

Number.prototype.format = function (format) {
	if (!window.isType(format, 'string')) { return ''; } // sanity check 

	var hasComma = -1 < format.indexOf(','),
		psplit = format.stripNonNumeric().split('.'),
		that = this;

	// compute precision
	if (1 < psplit.length) {
		// fix number precision
		that = that.toFixed(psplit[1].length);
	}
	// error: too many periods
	else if (2 < psplit.length) {
		throw 'NumberFormatException: invalid format, formats should have no more than 1 period: ' + format;
	}
	// remove precision
	else {
		that = that.toFixed(0);
	}

	// get the string now that precision is correct
	var fnum = that.toString();

	// format has comma, then compute commas
	if (hasComma) {
		// remove precision for computation
		psplit = fnum.split('.');

		var cnum = psplit[0];
		var parr = [];
		var j = cnum.length;
		var m = Math.floor(j / 3);
		var n = cnum.length % 3 || 3; // n cannot be ZERO or causes infinite loop 

		// break the number into chunks of 3 digits; first chunk may be less than 3
		for (var i = 0; i < j; i += n) {
			if (i !== 0) { n = 3; }
			parr[parr.length] = cnum.substr(i, n);
			m -= 1;
		}

		// put chunks back together, separated by comma
		fnum = parr.join(',');

		// add the precision back in
		if (psplit[1]) { fnum += '.' + psplit[1]; }
	}

	// replace the number portion of the format with fnum
	return format.replace(/[\d,?\.?]+/, fnum);
};

// Add commas to number
Number.prototype.addCommas = function () { return this.toLocaleString(); };

// Add commas to numeric string
function addCommas(data) {
	data += '';
	var x = data.split('.');
	var x1 = x[0];
	var x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) { x1 = x1.replace(rgx, '$1' + ',' + '$2'); }

	return x1 + x2;
}

// Remove commas from numeric string
function removeCommas(data) {
	var dataType = typeof data;
	if (dataType !== "string") { return data; }
	while (data.indexOf(",") > -1) { data = data.replace(',', ''); }
	return data;
}
//#endregion

// #region Boolean Extensions

function toBoolean(value) {
	var strValue = $.trim(value).toLowerCase();
	var valueToReturn;

	switch (strValue) {
		case "true": valueToReturn = true; break;
		case "yes": valueToReturn = true; break;
		case "1": valueToReturn = true; break;
		case "false": valueToReturn = false; break;
		case "no": valueToReturn = false; break;
		case "0": valueToReturn = false; break;
		default: if (value) { valueToReturn = true; } else { valueToReturn = false; }; break;
	}
	return valueToReturn;
};

// #endregion Boolean Extensions

function getJQueryControl(controlName) {
	var control;
	// If controlName is string
	if (typeof controlName === 'string') { control = $("#" + controlName.replaceEverywhere("#", "")); }
	else { control = $(controlName); }
	return control;
}

//#region Select Code

//function addOption(controlName, text, value, isSelected) {
//	var beforeAddEvent = jQuery.Event("beforeAddOption", { cancelable: true });
//	var afterAddEvent = jQuery.Event("afterAddOption", { cancelable: false });

//	var control = getJQueryControl(controlName);
//	var optionToAdd = $('<option></option>').val(value).html(text);
//	var eventData = { option: optionToAdd };

//	if (isSelected === true) { optionToAdd.attr("selected", "selected"); }
//	// Raise an event for beforeAddItem
//	control.trigger(beforeAddEvent, eventData);
//	// If canceled return
//	if (beforeAddEvent.cancel || beforeAddEvent.isDefaultPrevented()) { return false; }
//	// Add the option
//	control.append(optionToAdd);

//	control.trigger(afterAddEvent, eventData);

//	return control.find('[value="' + value + '"]');
//}

//#endregion Select Code

function daysInMonth(iMonth, iYear) { return new Date(iYear, iMonth, 0).getDate(); }

function restrictInputToCurrency(control, noOfDecimals) {
	// If no of decimals is not specified then default to 4
	if (!noOfDecimals) { noOfDecimals = 2; }
	// Increase by 1 to get the correct result
	noOfDecimals = noOfDecimals + 1;

	$(control).keypress(function (e) {
		//Regex will check for 5 places to allow for max 4 decimal places
		//var regex = /^[0-9]*\.[0-9]{5}$/g;
		var regex = new RegExp("/^[0-9]*\\.[0-9]{" + noOfDecimals + "}$/g");

		var keyCode = e.which ? e.which : e.keyCode;
		// Is Control Read-Only
		var isReadonly = $(this).attr("readonly");
		// If read-only then return false
		if (isReadonly) { return false; }
		// Is Control Chars pressed
		var isControlKey = (controlKeys.join(",") + "46, 110, 190").match(new RegExp(keyCode));
		// Test the input
		var isValidKey = keyCode >= 48 && keyCode <= 57 || keyCode === 46 || keyCode === 45;
		// Key pressed is not valid
		if (!isValidKey && !isControlKey) { return false; }
		// Get the Selection Start And End
		var tempResult = getInputSelection(this);
		var selStart = tempResult.start;
		var selEnd = tempResult.end;
		// Get the final value after replacing the selected text
		var valueToCheck = this.value.substring(0, selStart) + String.fromCharCode(keyCode) + this.value.substring(selEnd, this.value.length);
		// Validate the input
		if (regex.test(valueToCheck) && !isControlKey) { return false; }
		else { return true; }
	});
}

function restrictInputToLetters(control) {
	$(control).keypress(function (e) {
		var keyCode = e.which ? e.which : e.keyCode;
		// Is Control Read-Only
		var isReadonly = $(this).attr("readonly");
		// If read-only then return false
		if (isReadonly) { return false; }
		// Is Control Chars pressed
		var isControlKey = controlKeys.join(",").match(new RegExp(keyCode));
		// Test the input
		var result = keyCode >= 65 && keyCode <= 90 || keyCode >= 97 && keyCode <= 122;
		if (!result && !isControlKey) { DigitalPrizm.showMessage("Invalid Key", "Only alphabets (a-z,A-Z) are allowed."); return false; }
		else { return true; }
	});
}

function getQueryStringValue(key) {
	return decodeURIComponent(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + encodeURIComponent(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
}

function getVerticalScrollBarWidth() {
	var inner = document.createElement('p');
	inner.style.width = "100%";
	inner.style.height = "200px";

	var outer = document.createElement('div');
	outer.style.position = "absolute";
	outer.style.top = "0px";
	outer.style.left = "0px";
	outer.style.visibility = "hidden";
	outer.style.width = "200px";
	outer.style.height = "150px";
	outer.style.overflow = "hidden";
	outer.appendChild(inner);

	document.body.appendChild(outer);
	var w1 = inner.offsetWidth;
	outer.style.overflow = 'scroll';
	var w2 = inner.offsetWidth;
	if (w1 === w2) w2 = outer.clientWidth;

	document.body.removeChild(outer);

	return w1 - w2;
}

// Actual width of an element even if it's hidden
$.fn.actualWidth = function () {
	var $clone = this.clone().css({ visibility: "hidden", display: "block", position: "absolute" }).appendTo($('body'));
	var $width = $clone.outerWidth();
	$clone.remove();
	return $width;
};

// Actual height of an element even if it's hidden
$.fn.actualHeight = function () {
	var $clone = this.clone().css({ visibility: "hidden", display: "block", position: "absolute" }).appendTo($('body'));
	var $height = $clone.outerHeight();
	$clone.remove();
	return $height;
};

Date.prototype.getWeek = function () {
	var onejan = new Date(this.getFullYear(), 0, 1);
	var today = new Date(this.getFullYear(), this.getMonth(), this.getDate());
	var dayOfYear = (today - onejan + 86400000) / 86400000;
	return Math.ceil(dayOfYear / 7);
};

Date.prototype.getShortMonthName = function (monthNumber) {
	if (!monthNumber) {
		monthNumber = new Date(this).getMonth();
	}
	var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
	return months[monthNumber];
};

Date.prototype.getFullMonthName = function (monthNumber) {
	if (!monthNumber) { monthNumber = new Date(this).getMonth(); }
	var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
	return months[monthNumber];
};

Date.prototype.add = function (size, value) {
	value = parseInt(value);
	var incr;
	switch (size) {
		case 'day':
			incr = value * 24;
			this.add('hour', incr);
			break;
		case 'hour':
			incr = value * 60;
			this.add('minute', incr);
			break;
		case 'week':
			incr = value * 7;
			this.add('day', incr);
			break;
		case 'minute':
			incr = value * 60;
			this.add('second', incr);
			break;
		case 'second':
			incr = value * 1000;
			this.add('millisecond', incr);
			break;
		case 'month':
			this.setMonth(this.getMonth() + value);
			break;
		case 'millisecond':
			this.setTime(this.getTime() + value);
			break;
		case 'year':
			this.setFullYear(this.getUTCFullYear() + value);
			break;
		default:
			throw new Error('Invalid increment passed');
	}
};

dateTimeReviver = function (key, value) {
	var a;
	if (typeof value === 'string') {
		a = /\/Date\((-?\d*)\)\//.exec(value);
		if (a) { return new Date(+a[1]); }
	}
	return value;
};

//#region Fall-back scripts

// Date.now() function is not available in <IE9
Date.now = Date.now || function () { return +new Date; };

// Implement indexOf if not already
// Production steps of ECMA-262, Edition 5, 15.4.4.14
// Reference: http://es5.github.io/#x15.4.4.14
if (!Array.prototype.indexOf) {
	Array.prototype.indexOf = function (searchElement, fromIndex) {

		var k;

		// 1. Let O be the result of calling ToObject passing
		//    the this value as the argument.
		//if (this === null) { throw new TypeError('"this" is null or not defined'); }

		var obj = Object(this);

		// 2. Let lenValue be the result of calling the Get
		//    internal method of O with the argument "length".
		// 3. Let len be ToUint32(lenValue).
		var len = obj.length >>> 0;

		// 4. If len is 0, return -1.
		if (len === 0) { return -1; }

		// 5. If argument fromIndex was passed let n be
		//    ToInteger(fromIndex); else let n be 0.
		var n = +fromIndex || 0;

		if (Math.abs(n) === Infinity) { n = 0; }

		// 6. If n >= len, return -1.
		if (n >= len) { return -1; }

		// 7. If n >= 0, then Let k be n.
		// 8. Else, n<0, Let k be len - abs(n).
		//    If k is less than 0, then let k be 0.
		k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);

		// 9. Repeat, while k < len
		while (k < len) {
			// a. Let Pk be ToString(k).
			//   This is implicit for LHS operands of the in operator
			// b. Let kPresent be the result of calling the
			//    HasProperty internal method of O with argument Pk.
			//   This step can be combined with c
			// c. If kPresent is true, then
			//    i.  Let elementK be the result of calling the Get
			//        internal method of O with the argument ToString(k).
			//   ii.  Let same be the result of applying the
			//        Strict Equality Comparison Algorithm to
			//        searchElement and elementK.
			//  iii.  If same is true, return k.
			if (k in obj && obj[k] === searchElement) { return k; }
			k++;
		}
		return -1;
	};
}
if (!('lastIndexOf' in Array.prototype)) {
	Array.prototype.lastIndexOf = function (find, i /*opt*/) {
		if (i === undefined) i = this.length - 1;
		if (i < 0) i += this.length;
		if (i > this.length - 1) i = this.length - 1;
		for (i++; i-- > 0;) /* i++ because from-argument is sadly inclusive */
			if (i in this && this[i] === find)
				return i;
		return -1;
	};
}
if (!('forEach' in Array.prototype)) {
	Array.prototype.forEach = function (action, that /*opt*/) {
		for (var i = 0, n = this.length; i < n; i++)
			if (i in this)
				action.call(that, this[i], i, this);
	};
}
if (!('map' in Array.prototype)) {
	Array.prototype.map = function (mapper, that /*opt*/) {
		var other = new Array(this.length);
		for (var i = 0, n = this.length; i < n; i++)
			if (i in this)
				other[i] = mapper.call(that, this[i], i, this);
		return other;
	};
}
if (!('filter' in Array.prototype)) {
	Array.prototype.filter = function (filter, that /*opt*/) {
		var other = [], v;
		for (var i = 0, n = this.length; i < n; i++)
			if (i in this && filter.call(that, v = this[i], i, this))
				other.push(v);
		return other;
	};
}
if (!('every' in Array.prototype)) {
	Array.prototype.every = function (tester, that /*opt*/) {
		for (var i = 0, n = this.length; i < n; i++)
			if (i in this && !tester.call(that, this[i], i, this))
				return false;
		return true;
	};
}
if (!('some' in Array.prototype)) {
	Array.prototype.some = function (tester, that /*opt*/) {
		for (var i = 0, n = this.length; i < n; i++)
			if (i in this && tester.call(that, this[i], i, this))
				return true;
		return false;
	};
}
if (!('insert' in Array.prototype)) {
	Array.prototype.insert = function (index) {
		index = Math.min(index, this.length);
		arguments.length > 1
			&& this.splice.apply(this, [index, 0].concat([].pop.call(arguments)))
			&& this.insert.apply(this, arguments);
		return this;
	};
}
if (!('move' in Array.prototype)) {
	Array.prototype.move = function (oldIndex, newIndex) {
		while (oldIndex < 0) { oldIndex += this.length; }
		while (newIndex < 0) { newIndex += this.length; }
		if (newIndex >= this.length) {
			var k = newIndex - this.length;
			while (k-- + 1) { this.push(undefined); }
		}
		this.splice(newIndex, 0, this.splice(oldIndex, 1)[0]);
		//return this; // for testing purposes
	};
}
if (!('findBy' in Array.prototype)) {
	Array.prototype.findBy = function (property, valueToSearch) {
		if (!property || !valueToSearch) { return -1; }
		var index = -1;
		$.grep(this, function (item, idx) {
			if (item === undefined || item === null) { return true; }
			if (item[property] === valueToSearch) {
				index = idx;
				return false;
			}
			return true;
		});
		return index;
	};
}

function removeDuplicates(arr) {
	return [...new Set(arr)];
}

if (!('removeDuplicates' in Array.prototype)) {
	Array.prototype.removeDuplicates = function () {
		return removeDuplicates(this);
	};
}
//#region Array  custom scripts

/*
---
script: array-sortby.js
version: 1.2.2
description: Array.sortBy is a prototype function to sort arrays of objects by a given key.
license: MIT-style
source: http://github.com/eneko/Array.sortBy
authors:
- Eneko Alonso: (http://github.com/eneko)
- Fabio M. Costa: (http://github.com/fabiomcosta)
credits:
- Olmo Maldonado (key path as string idea)
provides:
- Array.sortBy

*/
(function () {

	var keyPaths = [];

	var saveKeyPath = function (path) {
		keyPaths.push({
			sign: path[0] === '+' || path[0] === '-' ? parseInt(path.shift() + 1) : 1,
			path: path
		});
	};

	var valueOf = function (object, path) {
		var ptr = object;
		try { for (var i = 0, l = path.length; i < l; i++) ptr = ptr[path[i]]; }
		catch (e) { return ptr; }
		return ptr;
	};

	var comparer = function (a, b) {
		for (var i = 0, l = keyPaths.length; i < l; i++) {
			var aVal = valueOf(a, keyPaths[i].path);
			var bVal = valueOf(b, keyPaths[i].path);
			if (typeof valueOf(a, keyPaths[i].path) === 'string' && typeof valueOf(b, keyPaths[i].path) === 'string') {
				aVal = aVal.toLowerCase();
				bVal = bVal.toLowerCase();
				return aVal.localeCompare(bVal, undefined, { numeric: true });
			}
			if (aVal > bVal) return keyPaths[i].sign;
			if (aVal < bVal) return -keyPaths[i].sign;
		}
		return 0;
	};

	Array.prototype.sortBy = function () {
		keyPaths = [];
		for (var i = 0, l = arguments.length; i < l; i++) {
			switch (typeof arguments[i]) {
				case "object": saveKeyPath(arguments[i]); break;
				case "string": saveKeyPath(arguments[i].match(/[+-]|[^.]+/g)); break;
			}
		}
		return this.sort(comparer);
	};
})();

/*
 * Group by single or multiple properties 
 * e.g. var result = groupBy(list, function(item) {
 *			return [item.lastname, item.age];
 *			});
 *  https://codereview.stackexchange.com/questions/37028/grouping-elements-in-array-by-multiple-properties
 * Function credit : https://codereview.stackexchange.com/a/37132/70412
 */
function groupBy(array, f) {
	var groups = {};
	array.forEach(function (o) {
		var group = JSON.stringify(f(o));
		groups[group] = groups[group] || [];
		groups[group].push(o);
	});
	return Object.keys(groups).map(function (group) { return groups[group]; });
}
function getMinMax(array, type) {
	var out = [];
	array.forEach(function (el) {
		return out.push.apply(out, [el[type]]);
	}, []);
	return { min: Math.min.apply(null, out), max: Math.max.apply(null, out) };
}

function scaleArray(arrayObject, dataMin, dataMax, rangeMin, rangeMax, propertyName) {
	// Scaling formula :  (scaleMax-scaleMin)/(dataMax-dataMin)(valueToScale-dataMax)+scaleMax 
	//				or    (scaleMax-scaleMin)/(dataMax-dataMin)(valueToScale-dataMin)+scaleMin.
	var scaleFactor = (rangeMax - rangeMin) / (dataMax - dataMin);
	for (var i = 0; i < arrayObject.length; i++) {
		if (propertyName) {
			arrayObject[i][propertyName] = scaleFactor * (arrayObject[i][propertyName] - dataMax) + rangeMax;
		}
		else {
			arrayObject[i] = scaleFactor * (arrayObject[i] - dataMax) + rangeMax;
		}
	}
	return arrayObject;
}
//#endregion Array 
//#endregion

//#region Selection Fallback and jQuery Extension scripts

jQuery.fn.extend({
	getCursorPosition: function () {
		var el = $(this).get(0);
		var pos = 0;
		if ('selectionStart' in el) { pos = el.selectionStart; }
		else if ('selection' in document) {
			el.focus();
			var sel = document.selection.createRange();
			var selLength = document.selection.createRange().text.length;
			sel.moveStart('character', -el.value.length);
			pos = sel.text.length - selLength;
		}
		return pos;
	},
	setCursorPosition: function (position) {
		if (this.length === 0) return this;
		return $(this).setSelection(position, position);
	},
	getSelection: function () {
		if (this.length === 0) return "";
		var s = $(this).getSelectionStart();
		var e = $(this).getSelectionEnd();
		return this[0].value.substring(s, e);
	},
	setSelection: function (selectionStart, selectionEnd) {
		if (this.length === 0) return this;
		var input = this[0];

		if (input.createTextRange) {
			var range = input.createTextRange();
			range.collapse(true);
			range.moveEnd('character', selectionEnd);
			range.moveStart('character', selectionStart);
			range.select();
		} else if (input.setSelectionRange) {
			input.focus();
			input.setSelectionRange(selectionStart, selectionEnd);
		}

		return this;
	},
	focusEnd: function () {
		this.setCursorPosition(this.val().length);
		return this;
	},
	insertAtCursor: function (myValue) {
		return this.each(function () {
			if (document.selection) {
				//For browsers like Internet Explorer
				this.focus();
				var sel = document.selection.createRange();
				sel.text = myValue;
				this.focus();
			}
			else if (this.selectionStart || parseInt(this.selectionStart) === 0) {
				//For browsers like Firefox and Webkit based
				var startPos = this.selectionStart;
				var endPos = this.selectionEnd;
				var scrollTop = this.scrollTop;
				this.value = this.value.substring(0, startPos) + myValue + this.value.substring(endPos, this.value.length);
				this.focus();
				this.selectionStart = startPos + myValue.length;
				this.selectionEnd = startPos + myValue.length;
				this.scrollTop = scrollTop;
			} else {
				this.value += myValue;
				this.focus();
			}
		});
	},
	getSelectionStart: function () {
		if (this.length === 0) return 0;
		var input = this[0];

		var pos = input.value.length;

		if (input.createTextRange) {
			var r = document.selection.createRange().duplicate();
			r.moveEnd('character', input.value.length);
			if (r.text === '') { pos = input.value.length; }
			else { pos = input.value.lastIndexOf(r.text); }
		}
		else if (typeof input.selectionStart !== "undefined") { pos = input.selectionStart; }

		return pos;
	},
	getSelectionEnd: function () {
		if (this.length === 0) return 0;
		var input = this[0];

		var pos = input.value.length;

		if (input.createTextRange) {
			var r = document.selection.createRange().duplicate();
			r.moveStart('character', -input.value.length);
			if (r.text === '') { pos = input.value.length; }
			else { pos = input.value.lastIndexOf(r.text); }
		}
		else if (typeof input.selectionEnd !== "undefined") { pos = input.selectionEnd; }

		return pos;
	}
});

function getInputSelection(el) {
	var start = 0, end = 0, normalizedValue, range, textInputRange, len, endRange;

	if (typeof el.selectionStart === "number" && typeof el.selectionEnd === "number") {
		start = el.selectionStart;
		end = el.selectionEnd;
	}
	else {
		range = document.selection.createRange();

		if (range && range.parentElement() === el) {
			len = el.value.length;
			normalizedValue = el.value.replace(/\r\n/g, "\n");

			// Create a working TextRange that lives only in the input
			textInputRange = el.createTextRange();
			textInputRange.moveToBookmark(range.getBookmark());

			// Check if the start and end of the selection are at the very end
			// of the input, since moveStart/moveEnd doesn't return what we want
			// in those cases
			endRange = el.createTextRange();
			endRange.collapse(false);

			if (textInputRange.compareEndPoints("StartToEnd", endRange) > -1) {
				start = end = len;
			} else {
				start = -textInputRange.moveStart("character", -len);
				start += normalizedValue.slice(0, start).split("\n").length - 1;

				if (textInputRange.compareEndPoints("EndToEnd", endRange) > -1) {
					end = len;
				} else {
					end = -textInputRange.moveEnd("character", -len);
					end += normalizedValue.slice(0, end).split("\n").length - 1;
				}
			}
		}
	}

	return { start: start, end: end };
}
//#endregion

//#region show/hide events for jQuery

/**
 * https://github.com/hypesystem/showandtell.js
 * jquery.hide-event.js
 * Currently supported hides: hide, fadeOut, slideUp, remove, toggle, fadeToggle, slideToggle,
 *     css (display), animate (height: hide, opacity: hide).
 * When a hide `h` is called, the event "hide" is triggered, with the additional parameter ["h"]. If it is
 * called as an action, the second parameter will be "action". If it is set as a CSS property it will be
 * "css".
 */
(function ($) {

	function applyIfExistsOrNull(fun, self, args) { return fun !== undefined && fun !== null ? fun.apply(self, args) : null; }

	function proxy$Functions(functionProxies) {
		$.each(functionProxies, function (oldFunctionName, proxySettings) {
			var oldFunction = $.fn[oldFunctionName];

			$.fn[oldFunctionName] = function () {
				var preResult = applyIfExistsOrNull(proxySettings.pre, this, arguments);
				var result = null;
				try {
					result = oldFunction.apply(this, arguments);
				}
				catch (e) {
					// Call Elmah Log
					Elmah.ErrorSignal.FromCurrentContext().Raise(ex);
				}

				var postArguments = [result, preResult, arguments];
				applyIfExistsOrNull(proxySettings.post, this, postArguments);

				return result;
			};
		});
	}

	function checkIfElementWasHidden() { return $(this).is(":hidden"); }

	//Only register if not already registered
	if (!$.showandtell) {

		//Indicate that showandtell has been registered.
		$.showandtell = true;

		proxy$Functions({
			hide: {
				pre: checkIfElementWasHidden,
				post: function (result, elementWasHidden) {
					if (!elementWasHidden) { this.triggerHandler("hide", { type: "action" }); }
				}
			},
			show: {
				pre: checkIfElementWasHidden,
				post: function (result, elementWasHidden) {
					if (elementWasHidden) { this.triggerHandler("show", { type: "action" }); }
				}
			},
			//remove: {
			//	//Remove has to trigger event before removing. After removal, there is no element to trigger the event on.
			//	pre: function () { this.triggerHandler("remove", { type: "action" }); }
			//},
			css: {
				pre: checkIfElementWasHidden,
				post: function (result, elementWasHidden, oldArgs) {
					if (!elementWasHidden && oldArgs[0] === "display" && oldArgs[1] === "none") { $(this).triggerHandler("hide", { type: "css" }); }

					if (elementWasHidden && oldArgs[0] === "display" && oldArgs[1] !== "none") { $(this).triggerHandler("show", { type: "css" }); }
				}
			}
		});
	}
})(jQuery);

//#endregion

function isExistsInDropDown(dropDownToSearch, valueToSearch) {
	var found;
	$(dropDownToSearch).find("option").each(function () { if (this.value === valueToSearch) { found = true; } });
	return found;
}

Storage.prototype.setObject = function (key, value) { this.setItem(key, JSON.stringify(value)); };

Storage.prototype.getObject = function (key) {
	var value = this.getItem(key);
	if (value === "undefined" || value === "null") { return null; }
	return value && JSON.parse(value);
};

function disableBackspace() {
	// Disable Backspace
	$(document).on("keydown", function (e) {
		if (e.which === 8 && !$(e.target).is("input:not([readonly]):not([type=radio]):not([type=checkbox]), textarea, [contentEditable], [contentEditable=true]")) {
			e.preventDefault();
			return false;
		}
		return true;
	});
}
function getDimensions(control) {
	var tempControl = getJQueryControl(control);

	var width = tempControl.width();
	if (!width && tempControl.parent() && tempControl.parent().length > 0) {
		tempControl = tempControl.parent();
		width = tempControl.width();
	}

	tempControl = getJQueryControl(control);
	var height = tempControl.height();
	if (!height && tempControl.parent() && tempControl.parent().length > 0) {
		tempControl = getJQueryControl(tempControl.parent()[0]);
		height = tempControl.height();
	}
	return { "width": width - 9, "height": height - 9 };
}
function validateEmail(email) {
	var re = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
	return re.test(email);
}
function validatePassword(password) {
	var reg = /^((?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$)/;
	/*
		(?=(.*[\d]){1,})				#   must contains one digit
		(?=(.*[a-z]){1,})				#   must contains one lowercase characters
		(?=.*?[A-Z])					#   must contains one uppercase characters
		(?=(.*[\W]){1,})(?!.*\s)		#   must contains one special symbols
		.								#   match anything with previous condition checking
		.{8,}$							#	length at least 8 characters
	*/
	return reg.test(password);
}
function getWidthOfText(txt, fontName, fontSize) {
	// Create a dummy canvas (render invisible with css)
	var c = document.createElement('canvas');
	// Get the context of the dummy canvas
	var ctx = c.getContext('2d');
	// Set the context.font to the font that you are using
	ctx.font = fontSize + 'px' + fontName;
	// Measure the string 
	// !!! <CRUCIAL>  !!!
	var length = ctx.measureText(txt).width;
	// !!! </CRUCIAL> !!!
	// Return width
	return length;
}
function validateFile(filename, validExtensions) {
	var ext = filename.split('.').pop();
	return validExtensions.indexOf(ext) >= 0;
}

function checkFeatures() {
	var browser = Browser;
	if (browser.ieVersion()) {

	}
	if (Browser.isCompatibilityModeOn()) {
		if (window.stop) { window.stop(); }

		document.getElementsByTagName('body')[0].innerHTML = '<div class="verticalMiddle"><div>' +
			'<div class="text-danger"> This browser is unsupported.</div><br/><br/>' +
			'<div>We recommend upgrading to the latest <a href="http://windows.microsoft.com/ie">Internet Explorer</a>, <a href="https://chrome.google.com">Google Chrome</a>, or <a href="https://mozilla.org/firefox/">Firefox</a>.</div>' +
			'<div>If you are using IE 11 or later, make sure you <A href="http://windows.microsoft.com/en-US/windows7/webpages-look-incorrect-in-Internet-Explorer">turn off "Compatibility View"</a>.</div>' +
			'</div></div>';
		return false;
	}
	return true;
}

var Browser = {
	Unknown: "Unknown",
	Edge: "Edge",
	Opera: "Opera",
	Chrome: "Chrome",
	Safari: "Safari",
	Firefox: "Firefox",
	Blink: "Blink Engine",
	InternetExplorer: "Internet Explorer",
	Information: function () {
		var info = { Name: Browser.Unknown, Version: "0.0" };
		//#region "Browser Name"

		// Opera 8.0+
		var isOpera = !!window.opr && !!opr.addons || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
		if (isOpera) { info.Name = Browser.Opera; }

		// Firefox 1.0+
		if (typeof InstallTrigger !== 'undefined') { info.Name = Browser.Firefox; }

		// Safari 3.0+ "[object HTMLElementConstructor]" 
		if (Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0 || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || safari.pushNotification)) { info.Name = Browser.Safari; }

		// Internet Explorer 6-11
		var isIe = /*@cc_on!@*/false || !!document.documentMode;
		if (isIe) { info.Name = Browser.InternetExplorer; }

		// Edge 20+
		if (!isIe && !!window.StyleMedia) { info.Name = Browser.Edge; }

		// Chrome 1+
		var isChrome = !!window.chrome && !!window.chrome.webstore;
		if (isChrome) { info.Name = Browser.Chrome; }

		// Blink engine detection
		if ((isChrome || isOpera) && !!window.CSS) { info.Name = Browser.Blink; }
		//#endregion "Browser Name"

		//#region "Browser Version"
		switch (info.Name) {
			case Browser.Opera:

			default:
		}

		//#endregion "Browser Version"

		return info;
	},
	version: function () {
		var nVer = navigator.appVersion;
		var nAgt = navigator.userAgent;
		var browserName = navigator.appName;
		var fullVersion = '' + parseFloat(navigator.appVersion);
		var majorVersion = parseInt(navigator.appVersion, 10);
		var nameOffset, verOffset, ix;

		// In Opera, the true version is after "Opera" or after "Version"
		if ((verOffset = nAgt.indexOf("Opera")) !== -1) {
			browserName = "Opera";
			fullVersion = nAgt.substring(verOffset + 6);
			if ((verOffset = nAgt.indexOf("Version")) !== -1)
				fullVersion = nAgt.substring(verOffset + 8);
		}
		// In MSIE, the true version is after "MSIE" in userAgent
		else if ((verOffset = nAgt.indexOf("MSIE")) !== -1) {
			browserName = "Microsoft Internet Explorer";
			fullVersion = nAgt.substring(verOffset + 5);
		}
		// In Chrome, the true version is after "Chrome" 
		else if ((verOffset = nAgt.indexOf("Chrome")) !== -1) {
			browserName = "Chrome";
			fullVersion = nAgt.substring(verOffset + 7);
		}
		// In Safari, the true version is after "Safari" or after "Version" 
		else if ((verOffset = nAgt.indexOf("Safari")) !== -1) {
			browserName = "Safari";
			fullVersion = nAgt.substring(verOffset + 7);
			if ((verOffset = nAgt.indexOf("Version")) !== -1)
				fullVersion = nAgt.substring(verOffset + 8);
		}
		// In Firefox, the true version is after "Firefox" 
		else if ((verOffset = nAgt.indexOf("Firefox")) !== -1) {
			browserName = "Firefox";
			fullVersion = nAgt.substring(verOffset + 8);
		}
		// In most other browsers, "name/version" is at the end of userAgent 
		else if ((nameOffset = nAgt.lastIndexOf(' ') + 1) <
			(verOffset = nAgt.lastIndexOf('/'))) {
			browserName = nAgt.substring(nameOffset, verOffset);
			fullVersion = nAgt.substring(verOffset + 1);
			if (browserName.toLowerCase() == browserName.toUpperCase()) {
				browserName = navigator.appName;
			}
		}
		// trim the fullVersion string at semicolon/space if present
		if ((ix = fullVersion.indexOf(";")) !== -1)
			fullVersion = fullVersion.substring(0, ix);
		if ((ix = fullVersion.indexOf(" ")) !== -1)
			fullVersion = fullVersion.substring(0, ix);

		majorVersion = parseInt('' + fullVersion, 10);
		if (isNaN(majorVersion)) {
			fullVersion = '' + parseFloat(navigator.appVersion);
			majorVersion = parseInt(navigator.appVersion, 10);
		}
	},
	ieVersion: function () {
		//Set defaults
		var value = { isIE: false, trueVersion: 0, actingVersion: 0, compatibilityMode: false };

		//Try to find the Trident version number
		var trident = navigator.userAgent.match(/Trident\/(\d+)/);
		if (trident) {
			value.isIE = true;
			//Convert from the Trident version number to the IE version number
			value.trueVersion = parseInt(trident[1], 10) + 4;
		}

		//Try to find the MSIE number
		var msie = navigator.userAgent.match(/MSIE (\d+)/);
		if (msie) {
			value.isIE = true;
			//Find the IE version number from the user agent string
			value.actingVersion = parseInt(msie[1]);
		} else {
			//Must be IE 11 in "edge" mode
			value.actingVersion = value.trueVersion;
		}

		//If we have both a Trident and MSIE version number, see if they're different
		if (value.isIE && value.trueVersion > 0 && value.actingVersion > 0) {
			//In compatibility mode if the trident number doesn't match up with the MSIE number
			value.compatibilityMode = value.trueVersion !== value.actingVersion;
		}
		return value;
	},
	otherBrowserVersion: function () {
		var userAgent = navigator.userAgent;
		var temp;
		var m = userAgent.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];

		if (m[1] === 'Chrome') {
			temp = userAgent.match(/\b(OPR|Edge)\/(\d+)/);
			if (temp != null) return { name: temp[1].replace('OPR', 'Opera'), version: temp[2] };
		}
		m = m[2] ? [m[1], m[2]] : [navigator.appName, navigator.appVersion, '-?'];
		temp = userAgent.match(/version\/(\d+)/i);
		if (temp != null) { m.splice(1, 1, temp[1]); }
		return m[1];
	},
	isCompatibilityModeOn: function () {
		return Browser.ieVersion().compatibilityMode === true;
	}
};

function ensureVisible(element, scrollableParent) {
	if (!element) { return true; }

	if (!scrollableParent) { scrollableParent = $(window); }
	scrollableParent = getJQueryControl(scrollableParent);
	element = getJQueryControl(element);

	if (scrollableParent.length === 0) { return true; }
	if (element.length === 0) { return true; }

	var offset = element.offset().top - scrollableParent.scrollTop();
	offset += 130;

	if (offset > scrollableParent.innerHeight()) {
		// Not in view
		//$('html,body').animate({ scrollTop: offset }, 1000);
		//$(scrollableParent).animate({ scrollTop: offset }, 1000);
		scrollableParent.scrollTop(offset);
		return false;
	}
	return true;
}

function getCurrentPageName() {
	var pageUrlParts = location.pathname.split("/");
	var fileName = pageUrlParts[pageUrlParts.length - 1].split(".");
	// If no file name is found then we are on home page
	if (!fileName[0]) { return "Default"; }
	return fileName[0];
}

function urlExists(testUrl) {
	var http = jQuery.ajax({ type: "HEAD", url: testUrl, async: false });
	return http.status;
	// this will return 200 on success, and 0 or negative value on error
}

function pad(inputString, lengthRequired, paddingCharacter, paddingDirection) {
	if (inputString.length > lengthRequired) { lengthRequired = inputString.length; }
	return inputString = (inputString || paddingCharacter || 0) + '',
		lengthRequired = new Array((++lengthRequired || 7) - inputString.length).join(paddingCharacter || 0),
		paddingDirection ? inputString + lengthRequired : lengthRequired + inputString;
}

// #region Animation

function flash(control, duration, times) {
	var controlToAnimate = getJQueryControl(control);
	if (isNaN(duration)) { throw "Duration must be numeric and greater than 0"; }
	if (parseInt(duration, 10) < 1) { throw "Duration must be numeric and greater than 0"; }

	if (isNaN(times)) { throw "No of times must be numeric and greater than 0"; }
	if (parseInt(times, 10) < 1) { throw "No of times must be numeric and greater than 0"; }

	controlToAnimate.addClass("blink");
	setTimeout(function () { controlToAnimate.removeClass("blink"); }, 3000);

	//for (var i = 0; i < times; i++) { controlToAnimate.fadeOut(duration).fadeIn(duration); }
}

// #endregion

//#region Image Methods
$.fn.naturalWidth = function () {
	var image = new Image();
	image.src = $(this).attr("src");
	return image.naturalWidth;
};

$.fn.naturalHeight = function () {
	var image = new Image();
	image.src = $(this).attr("src");
	return $(this).get(0).naturalHeight;
	//return image.naturalHeight;
};
//#endregion

function sleep(ms) {
	//return new Promise(function (resolve) { setTimeout(resolve, ms) });
	var date = Date.now();
	var curDate;
	do { curDate = Date.now(); } while (curDate - date < ms);
};

//#endregion

//#region Make any element draggable
// example : $("#someDlg").modal().makeDraggable({handle:".modal-header"});

(function ($) {
	$.fn.makeDraggable = function (opt) {
		opt = $.extend({ handle: "", cursor: "move" }, opt);

		var $element;
		if (opt.handle === "") { $element = this; } else { $element = this.find(opt.handle); }

		return $element.css('cursor', opt.cursor).on("mousedown", function (e) {
			var $drag;
			if (opt.handle === "") { $drag = $(this).addClass('draggable'); }
			else { $drag = $(this).addClass('active-handle').parent().addClass('draggable'); }

			var zIndex = $drag.css('z-index'),
				drgH = $drag.outerHeight(),
				drgW = $drag.outerWidth(),
				posY = $drag.offset().top + drgH - e.pageY,
				posX = $drag.offset().left + drgW - e.pageX;
			$drag.css('z-index', 1000).parents()
				.on("mousemove", function (e) {
					$('.draggable').offset({ top: e.pageY + posY - drgH, left: e.pageX + posX - drgW })
						.on("mouseup", function () { $(this).removeClass('draggable').css('z-index', zIndex); });
				});
			e.preventDefault(); // disable selection
		}).on("mouseup", function () {
			if (opt.handle === "") { $(this).removeClass('draggable'); }
			else { $(this).removeClass('active-handle').parent().removeClass('draggable'); }
		});
	};
})(jQuery);
//#endregion Make any element draggable

//#endregion