﻿// #region Information

/**
 * @author Bimal
 */

// #endregion Information

var app = angular.module("pluginApplication", ["DropDownSelect", "720kb.datepicker"]);

app.directive("dynamicfield", function () {
	return {
		restrict: "E",
		scope: {
			field: "=",
			form: "=",
			uiConfig: "=",
			formValues: "="
		},
		templateUrl: "./fieldHandler.html"
	};
});

// Create Application Controller
app.controller("pluginController", function ($scope, orderByFilter, $rootScope, $location) {

	// Set/Save the location
	$rootScope.location = $location;

	// #region Constants/Variables

	const originForPdfSelection = ["AUTO", "SELECTED"];
	const booleanValues = ["0", "1"];

	// Appian Events
	const onChange = "onChange";
	const onChangeLast = "onChangeLast";
	const onSearch = "onSearch";
	const onGridClick = "onGridClick";
	const onButtonClick = "onButtonClick";
	const onTabChange = "onTabChange";

	// View port Size
	var iframeHeight = "750px";
	var iframeWidth = "750px";

	var enableTestMode = typeof (Appian) === "undefined";
	// Appian document Id
	var currentDocumentUrl;

	// Get Luxon
	const luxonDateTime = luxon.DateTime;

	// #region Angular Variables

	// Collection object to keep the details of all the fields
	$scope.layoutDetails = {};
	// Collection object to keep the details of all the fields one step back
	$scope.oldLayoutDetails = {};
	// Supported Field Types
	$scope.supportedWebFields =
	{
		all: ["text", "number", "date", "select", "multiselect", "search", "grid", "button-group", "currency", "_", "paragraph", "searchableDropdown", "button", "label"],
		inputTypes: ["text", "number", "date", "currency", "paragraph"],
		arrayTypes: ["select", "multiselect"],
		search: ["search"],
		other: ["grid", "button-group", "button", "searchableDropdown", "label"]
	};

	$scope.globalConfig = {};
	$scope.selectedOptions = {};

	$scope.masterListElement = {};

	$scope.OptionLists = {};
	$scope.initialLoadCascadingDropdownValues = {};


	//// Properties to check while verifying if two field definitions are equal
	//$scope.fieldProperties = ["type", "label", "visible", "showLabel", "required", "disabled", "style", "icon", "placeholder", "masterListValue"];
	//$scope.changeValue = {};
	//$scope.focusedElement = null;
	//$scope.myFormHolder = {};
	//$scope.isValueChangedInLastFocusedElement = false;
	//$scope.formValidationErrors = {};
	//$scope.oldFormObjectData = {};
	//$scope.oldObjectValue = {};
	//$scope.formValues = {};
	//$scope.dropDownValues = {};
	//$scope.dropDownBooleanValues = {};
	//$scope.selectedVal = {};

	//$scope.isGridCellClicked = false;
	//$scope.formNewDetails = {};
	//$scope.globalMasterValues = {};
	//$scope.disableCtrl = {};
	//$scope.visibilityCtrl = {};
	//$scope.requiredCtrl = {};
	//$scope.styleCtrl = {};
	//$scope.retainVal = {};

	//$scope.globalCascadingMasterValues = {};


	//$scope.buttonClicked = false;

	// #endregion Angular Variables

	// #endregion Constants/Variables

	// #region Test Mode

	function enableTestModeConfig() {
		var temp = cleanupInput(window.TEST_VALUES);

		$scope.globalConfig = window.TEST_VALUES.config;

		$scope.globalMasterValues = window.TEST_VALUES.masterValues;
		$scope.globalCascadingMasterValues = window.TEST_VALUES.cascading;


		$scope.formData = temp.formDetails;

		$scope.globalMasterValues = temp.masterValues;
		$scope.globalCascadingMasterValues = temp.cascading;
		$scope.formValues = temp.formValues;

		$scope.originalFormValues = clone($scope.formValues);
		NEW_VALUES = temp;

		$scope.updateObjectValues = NEW_VALUES.updateObjectValues = window.TEST_VALUES.updateObjectValues;
		$scope.updateFromObject = NEW_VALUES.updateFormObject = window.TEST_VALUES.updateFormObject;

		setTimeout(function () {
			openPdf("MRC_SAMPLE.pdf");
		}, 10);
	}
	// #endregion Test Mode

	// #region Appian Methods

	function save(valueToSave, event) {
		if (enableTestMode) { return; }

		if (Appian == undefined || Appian == null) { return; }

		var eventToRaise = onChangeLast;
		if (event != undefined || event != null) { eventToRaise = event; }

		Appian.Component.saveValue(eventToRaise, valueToSave);
	}

	function initialize() {
		if (enableTestMode) {
			$scope.initializePlugin(window.TEST_VALUES);
		}
		else {
			Appian.Component.onNewValue(function (newValues) { $scope.initializePlugin(newValues); });
		}
	}

	function raiseAppianError(errorValue) {
		if (enableTestMode) { return; }

		if (Appian == undefined || Appian == null) { return; }

		Appian.Component.setValidations(errorValue);
	}

	function resetAppianErrors() {
		if (enableTestMode) { return; }

		if (Appian == undefined || Appian == null) { return; }

		Appian.Component.setValidations([]);
	}

	// #endregion Appian Methods

	// #region PDF Code

	// PDF.JS Global Variables, which are set here by JS utilities
	var PDFViewerApplication, clearOldRectangles, showRectangleByCoordinates, updatePdfConfiguration;

	// Setting up the above Global variables for PDF to initialize the application, they are called from viewer.html file
	window.setPDFViewerApplication = function (data, showHighlight, clearOldRectangle, pdfConfiguration) {
		PDFViewerApplication = data;
		showRectangleByCoordinates = showHighlight;
		clearOldRectangles = clearOldRectangle;
		updatePdfConfiguration = pdfConfiguration;

		// Initialize Plugin
		initialize();
	};

	window.getIframeSize = function () {
		adjustHeightOfIframe(iframeHeight, iframeWidth);
		return { iframeHeight: iframeHeight.split("px")[0], iframeWidth: iframeWidth };
	};

	window.getConfig = function () { return NEW_VALUES.config; };

	function getDocumentFromWeb(options) {
		function getBase64(blob) {
			var reader = new FileReader();
			reader.onload = function () {
				var base64data = reader.result;
				openBase64Pdf(base64data.split("data:application/pdf;base64,")[1]);
			};
			reader.readAsDataURL(blob);
		}

		const xhttp = new XMLHttpRequest();
		xhttp.onload = function () {
			getBase64(this.response);
		};
		xhttp.withCredentials = true;
		xhttp.open("GET", options, true);
		xhttp.responseType = "blob";
		xhttp.send();
	}

	function openBase64Pdf(file) {
		// Base64 String from response shortened
		var pdfData = base64ToUint8Array(file);
		openPdf(pdfData);

		function base64ToUint8Array(base64) {
			var raw = atob(base64);
			var uint8Array = new Uint8Array(raw.length);
			for (var i = 0; i < raw.length; i++) {
				uint8Array[i] = raw.charCodeAt(i);
			}
			return uint8Array;
		}
	}

	function openPdf(file) {
		PDFViewerApplication.open(file);
	}

	// This function is a parent function which invokes viewer.html's showRectangleByCoordinates (showHighlight) to highlight the text in the PDF.
	function highlightTextInPdf(searchObj, config) {
		if (searchObj.query == undefined || searchObj.query == null) {
			return;
		}

		var objectToSearch = clone(searchObj);

		objectToSearch.query = objectToSearch.query.toString();
		objectToSearch.coords = {
			"xMin": objectToSearch.xMin,
			"yMin": objectToSearch.yMin,
			"xMax": objectToSearch.xMax,
			"yMax": objectToSearch.yMax
		};

		if ($scope.globalConfig.clearCanvasBeforeHighlighting) {
			clearOldRectangles();
		}

		if (!config.phraseSearch) {
			// search specific coordinates
			var objToSearch = {
				pageNumber: objectToSearch.pageNumber,
				coords: objectToSearch.coords,
				query: objectToSearch.query,
				origin: objectToSearch.origin
			};

			//objToSearch
			showRectangleByCoordinates(objToSearch);
		}
		else {
			// general search without coordinates
			if (objectToSearch.query == undefined || objectToSearch.query == null) { return; }

			var findEvent = "find";

			if (config.highlightAll)
				findEvent = "findhighlightallchange";

			if (config.caseSensitive)
				findEvent = "findcasesensitivitychange";

			if (config.entireWord)
				findEvent = "findentirewordchange";

			PDFViewerApplication.findController.executeCommand(findEvent, {
				query: objectToSearch.query,
				phraseSearch: config.phraseSearch,
				caseSensitive: config.caseSensitive,
				entireWord: config.entireWord,
				highlightAll: config.highlightAll,
				findPrevious: config.findPrevious
			});
		}
	}

	// #endregion PDF Code

	// #region Initialize Plugin

	$scope.initializePlugin = function (inputs) {
		// Reset Appian Errors
		resetAppianErrors();

		try {
			$scope.globalConfig = inputs.config;

			var sanitizedValues = cleanupInput(inputs);

			/* Enable/Disable test mode from outside of Plugin */
			if (inputs.enableTestMode != null && inputs.enableTestMode === true) {
				enableTestMode = inputs.enableTestMode;
				enableTestModeConfig();
			}
			else {
				enableTestMode = false;
			}

			// Initialize Scope
			$scope.globalConfig = sanitizedValues.config;
			$scope.formData = sanitizedValues.formDetails;
			$scope.formValues = sanitizedValues.formValues;
			$scope.originalFormValues = clone($scope.formValues);

			$scope.globalMasterValues = sanitizedValues.masterValues;
			$scope.globalCascadingMasterValues = sanitizedValues.cascading;

			// Set Frame Height
			adjustHeightOfIframe(iframeHeight, iframeWidth);
			updatePdfConfiguration(inputs.config);

			if (!_.isEqual(currentDocumentUrl, inputs.documentDownloadURL)) {
				currentDocumentUrl = inputs.documentDownloadURL;
				getDocumentFromWeb(currentDocumentUrl);
			}
		}
		catch (e) {
			console.error(e);
		}

		//Add event handler to tabs for tab-change
		setTimeout(function () {
			$scope.$apply(function () {
				$('a[data-toggle="tab"]').on("shown.bs.tab", function (e) {
					e.preventDefault();
					var newTabName = $(e.target).attr("href").replace("#", "");
					var previousTabName = $(e.relatedTarget).attr("href").replace("#", "");

					/* Raise the Appian event */
					save({ previousTab: previousTabName, newTab: newTabName }, onTabChange);
				});
			});
		}, 1000);
	};

	function cleanupInput(inputs) {
		return sanitizeInput(validateAppianInput(convertInputArrayInRequiredFormat(inputs)));
	}

	// Adjust the plug-in in Appian window
	function adjustHeightOfIframe(height) {
		if (height === null || height === "auto") { height = "750px"; }

		$("pdfViewerParent").css("height", height);
		$("pdf-js-viewer").css("height", height);

		document.getElementById("pdfViewerParent").style.height = height;
		document.getElementById("pdf-js-viewer").setAttribute("height", height.split("px")[0]);

		document.getElementById("dynamic-form").style.height = height;

		/* Set the height of the tab-content page to height - height of tab area */
		var tabHeight = $("ul.nav-tabs").height();
		var tabPaneHeight = height.split("px")[0] - tabHeight;
		$("div.tab-content").height(tabPaneHeight).css("overflow-y", "auto");
	}

	function convertGridFieldsInRequiredFormat(gridFields) {
		gridFields.forEach(function (eachRow) {
			eachRow.data.forEach(function (eachCell) {
				if (eachCell.type === "date") {
					eachCell.query = formatDate(eachCell.query, $scope.globalConfig.dateFormat, $scope.globalConfig.outputDateFormat);
				}
			});
		});
	}

	function validateAppianInput(inputs) {
		var appianInputValidationResult = [];

		if (inputs.formDetails == undefined || inputs.formDetails == null) {
			appianInputValidationResult.push("Required fields are missing: formDetails");
		}
		if (inputs.formValues == undefined || inputs.formValues == null) {
			appianInputValidationResult.push("Required fields are missing: formValues");
		}
		if (inputs.config == undefined || inputs.config == null) {
			appianInputValidationResult.push("Required fields are missing: config");
		}

		if (enableTestMode !== true && (inputs.formValues == null || inputs.formValues == undefined || inputs.formValues.length === 0)) {
			raiseAppianError(appianInputValidationResult);
			return inputs;
		}

		//validating formDetails and values
		inputs.formDetails.milestones.forEach(function (milestone) {
			milestone.sections.forEach(function (section) {
				section.fields.forEach(function (field) {
					if (inputs.formValues[field.name] == null || inputs.formValues[field.name] == undefined || inputs.formValues[field.name].length === 0 || inputs.formValues[field.name].length == undefined) {
						return;
					}
					switch (field.type) {
						case "text": break;
						case "currency": break;
						case "paragraph": break;
						case "number":
							if (inputs.formValues[field.name].query != null && parseFloat(inputs.formValues[field.name].query) === "NaN")
								appianInputValidationResult.push("Invalid Value in " + field.name + ": should be a number, but " + inputs.formValues[field.name].query + " is given.");
							break;
						case "date": break;
						case "select":
							if (!Array.isArray(inputs.formValues[field.name].rows))
								appianInputValidationResult.push("Invalid Value: formValue Must be an array for " + field.name);
							break;
						case "multiselect":
							if (!Array.isArray(inputs.formValues[field.name].rows))
								appianInputValidationResult.push("Invalid Value: formValue Must be an array for " + field.name);
							break;
						case "grid": break;
						case "button-group":
							if (!Array.isArray(inputs.formValues[field.name].rows))
								appianInputValidationResult.push("Invalid Value: formValue Must be an array for " + field.name);
							break;
					}
				});
			});
		});
		// Set Error Message
		if (enableTestMode !== true && appianInputValidationResult.length > 0) {
			raiseAppianError(appianInputValidationResult);
		}
		return inputs;
	}

	// This is a wrapper function to extract the fields from milestones and nested sections.
	// handle the Appian input by mapping and segregating the data of each and every field in the required local variables.
	function sanitizeInput(inputs) {
		if (inputs.formDetails == null || inputs.formDetails == undefined) { inputs.formDetails = {}; }
		if (inputs.formValues == null || inputs.formValues == undefined) { inputs.formValues = {}; }
		if (inputs.annotationObject == null || inputs.annotationObject == undefined) { inputs.annotationObject = { clearOldRectangles: true }; }

		inputs.formDetails.milestones = orderByFilter(inputs.formDetails.milestones, "sortOrder");
		$scope.lastSelected = {};

		var rootLevelFields = inputs.formDetails.fields;
		var rootLevelMilestones = inputs.formDetails.milestones;

		// Handle Root Level Fields
		if (inputs.formDetails.hasOwnProperty("fields") && inputs.formDetails.fields.length) {
			rootLevelFields.forEach(function (field) {
				sanitizeField(field, inputs);
			});
		}

		rootLevelMilestones.forEach(function (milestone) {
			// handle fields inside milestone here
			if (milestone.hasOwnProperty("fields") && milestone.fields.length) {
				milestone.fields.forEach(function (field) {
					sanitizeField(field, inputs);
				});
			}
			milestone.sections.forEach(function (section) {
				section.fields.forEach(function (field) {
					sanitizeField(field, inputs);
				});
			});
		});
		return inputs;
	}

	/*
	 * function is called from sanitizeInput function,
	 * this function handles the Appian input by mapping and segregating the data of each and every field in the required local variables.
	 */
	function sanitizeField(field, inputs) {
		$scope.disableCtrl[field.name] = field.disabled;
		$scope.styleCtrl[field.name] = field.style.style;
		$scope.requiredCtrl[field.name] = field.required;
		$scope.visibilityCtrl[field.name] = field.visible;

		var previouslySelected = {};

		// create a watcher on each field separately, so that any change in the field will invoke the onChangeLast variable.
		$scope.$watch("formValues." + field["name"], function (newValue, oldValue) {
			if (_.isEqual(newValue, oldValue)) { return; }

			//console.log("$watch => formValues+" + field["name"] + "\nNew:", newValue, "\nOld:", oldValue);

			if ($scope.supportedWebFields.inputTypes.indexOf(field.type) > -1) {
				$scope.isValueChangedInLastFocusedElement = true;
				return;
			}

			if (field.type === "date") {
				newValue = formatDate(newValue, $scope.globalConfig.dateFormat, $scope.globalConfig.outputDateFormat);
			}

			// Update The Layout of the field
			$scope.updateLayout(field);
		}, true);

		previouslySelected[field.name] = [];

		if (inputs.formValues[field.name] == null || inputs.formValues[field.name] == undefined) { return; }

		if (Array.isArray(inputs.formValues[field.name]) && (inputs.formValues[field.name].length === 0 || inputs.formValues[field.name].length == undefined)) {
			return;
		}

		switch (field.type) {
			case "_": break;
			case "grid": break;
			case "label": break;
			case "button": break;
			case "text": break;
			case "paragraph": break;
			case "currency": break;
			case "number":
				var value = inputs.formValues[field.name].query;
				inputs.formValues[field.name].query = value.indexOf(".") > -1 ? parseFloat(value) : parseInt(value);
				break;
			case "date":
				try {
					inputs.formValues[field.name].query = formatDate(inputs.formValues[field.name].query, $scope.globalConfig.dateFormat, $scope.globalConfig.outputDateFormat);
				} catch (e) {
					console.log(e);
				}
				break;
			case "searchableDropdown":
				if ($scope.selectedOptions[field.name] == undefined || $scope.selectedOptions[field.name] == null) { $scope.selectedOptions[field.name] = {}; };
				updateSelectedOptionsArray(field, inputs.formValues[field.name].rows);
				break;
			case "select":
				if ($scope.selectedOptions[field.name] == undefined || $scope.selectedOptions[field.name] == null) { $scope.selectedOptions[field.name] = {}; };
				updateSelectedOptionsArray(field, inputs.formValues[field.name].rows);
				break;
			case "multiselect":
				if ($scope.selectedOptions[field.name] == undefined || $scope.selectedOptions[field.name] == null) { $scope.selectedOptions[field.name] = {}; };
				updateSelectedOptionsArray(field, inputs.formValues[field.name].rows);

				// setting 10 ms to time so multiselect can load properly
				setTimeout(function () {
					$("#" + field.name).change(function () {
						// Get newly selected elements
						var currentlySelected = $(this).val();
						var newSelections = currentlySelected.filter(function (element) {
							return previouslySelected[field.name].indexOf(element) < 0;
						});
						previouslySelected[field.name] = currentlySelected;
						if (newSelections.length) {
							// If there are multiple new selections, we'll take the last in the list
							$scope.lastSelected[field.name] = newSelections.reverse()[0];
						}
						clearOldRectangles();
						$scope.selectedOptions[field.name].forEach(function (selectedOption) {
							if ($scope.lastSelected[field.name] === selectedOption["$$hashKey"]) {
								setTimeout(function () {
									highlightTextInPdf(selectedOption, { clearCanvasBeforeHighlighting: false, phraseSearch: false });
								}, 10);
							}
						});
					});
				}, 10);
				break;
			default:
				break;
		}
	}

	$scope.updateLayout = function (field) {
		var fieldName = field["name"];

		/* if the old layout is available */
		if ($scope.layoutDetails[fieldName] != undefined && $scope.oldLayoutDetails[fieldName] != null) {
			/* Check if there is any change in the desired properties of the field
			 * If Yes then continue execution
			 * If No then return
			 */
			if ($scope.hasFieldChanged($scope.oldLayoutDetails[fieldName], $scope.layoutDetails[fieldName]) === false) {
				return true;
			}
		}

		// The field has changed, use the values from new layout details
		field = $scope.layoutDetails[fieldName];

		// create jQuery Object with field
		var fieldObject = $("#" + fieldName);

		if (fieldObject.length > 0) {
			fieldObject.attr("ng-disabled", field["disabled"]);
			fieldObject.attr("ng-required", field["required"]);
			fieldObject.attr("ng-style", field["style"]["fieldClass"]);
			fieldObject.attr("ng-class", field["style"]["style"]);
		}
		return true;
	};

	$scope.hasFieldChanged = function (oldValue, newValue) {
		//console.log("hasFieldChanged\nNew:", newValue, "\nOld:", oldValue);
		// If no values then return false
		if (oldValue == undefined || oldValue == null || newValue == undefined || newValue == null) { return false; }

		var result = _.chain(oldValue).keys().every(function (currentKey) {
			// if current key is one of the desired properties
			if ($scope.fieldProperties.indexOf(currentKey) > -1) {
				// Compare the values
				return _.has(newValue, currentKey) && _.isEqual(oldValue[currentKey], newValue[currentKey]);
			}
			else {
				return false;
			}
		}).value();
		// if equal then result will be true so return false and vice versa
		return !result;
	};

	function updateSelectedOptionsArray(field, values) {
		if (!Array.isArray(values)) {
			raiseAppianError("updateSelectedOptionsArray failed as 'values' in not an array");
		}
		else {
			values.forEach(function (eachValue) {
				if (eachValue.hasOwnProperty("isSelected") && eachValue.isSelected === true) {
					if (field.type === "multiselect") {
						$scope.selectedOptions[field.name].push(eachValue);
					}
					else {
						if (field.type === "select" || field.type === "searchableDropdown") {
							$scope.selectedOptions[field.name] = eachValue;
						}
					}
					if ($scope.dropDownValues.hasOwnProperty($scope.masterListElement[field.name]) !== true) {
						$scope.selectedVal[field.name] = eachValue;
					}
				}
				else {
					eachValue.isSelected = false;
				}
			});
		}
	}

	// #endregion Initialize Plugin

	// #region Controls Code

	$scope.saveInputTypeValue = function (field, value) {
		if (typeof field == "undefined" || field == null || typeof value == "undefined" || value == null) {
			return;
		}

		// Specific Code for Select/Multiselect 
		if (field.type === "select" || field.type === "multiselect") {
			if (field.hasOwnProperty("cascadingRule") && field.cascadingRule[0].controls.hasOwnProperty('resetControl')) {
				$scope.resetDropDownCtrl(field.cascadingRule[0], "R");
			}

			if (!field.hasOwnProperty("placeholder") || (field.hasOwnProperty("placeholder") && (field.placeholder == null || field.placeholder === ""))) {
				if (value.toString().toLowerCase().includes('select')) {
					$scope.resetDropDownCtrl(field.cascadingRule[0].controls.controlName, "P");
					$scope.formValues[field.name].rows[0].query = "";
				} else {
					$scope.formValues[field.name].rows[0].query = value;
				}

				value = $scope.formValues[field.name].rows[0];
				$scope.isValueChangedInLastFocusedElement = true;
			}
			else {
				$scope.formValues[field.name].rows[0].query = value;
				value = $scope.formValues[field.name].rows[0];
				$scope.isValueChangedInLastFocusedElement = true;
			}
		}

		// General Code continues
		if ($scope.isValueChangedInLastFocusedElement) {
			$scope.isValueChangedInLastFocusedElement = false;

			// Get the updated Value in correct format
			var fieldValue = getFieldValue(field, value);

			if (!enableTestMode) {
				if (field.type === "search") {
					save(fieldValue, onSearch);
				}
				else {
					/*console.log("saveInputTypeValue => onChangeLast \nfield", field, "\nvalue", value);*/
					// If field type is date then format the date
					if (field.type === "date") {
						// Format the date for Appian
						fieldValue.query = formatDate(fieldValue.query, $scope.globalConfig.dateFormat, $scope.globalConfig.outputDateFormat);
					}

					// Save the value
					save({
						name: field.name,
						fieldDetails: field,
						newValue: fieldValue
					}, onChangeLast);
				}
			}
		}
	};

	$scope.resetDropDownCtrl = function (fieldControl, flag) {
		if (flag !== "R" && flag !== "P") { return; }

		var elementId = "";
		var oldMasterData = "";
		var value = "--Select--";

		if (flag === "R") {
			$scope.selectedVal[fieldControl.controls.resetControl].query = value;
		}
		else if (flag === "P") {
			$scope.selectedVal[fieldControl].query = value;
		}

		if (flag === "R") {
			if (fieldControl.controls.hasOwnProperty('resetControl')) {
				oldMasterData = $scope.masterListElement[fieldControl.controls.resetControl];
			}
		}
		else if (flag === "P") {
			oldMasterData = $scope.masterListElement[fieldControl];
		}

		var tempList = oldMasterData.split("_");
		var fieldIndex = tempList[tempList.length - 1];

		if (flag === "R") {
			elementId = fieldControl.controls.resetControl + "_" + fieldIndex;
		}
		else if (flag === "P") {
			elementId = fieldControl + "_" + fieldIndex;
		}

		var resetDropdownVal = {};
		var query = "--Select--";
		var pageNumber = 0;
		var origin = 0;
		var xMin = 0;
		var xMax = 0;
		var yMin = 0;
		var yMax = 0;

		resetDropdownVal[0] = {
			query: query,
			value: value,
			pagenumber: pageNumber,
			origin: origin,
			xMin: xMin,
			xMax: xMax,
			yMin: yMin,
			yMax: yMax,
			isSelected: true
		};

		$scope.dropDownValues[elementId] = resetDropdownVal;
		if (flag === "R") {
			$scope.masterListElement[fieldControl.controls.resetControl] = elementId;
		}
		else if (flag === "P") {
			$scope.masterListElement[fieldControl] = elementId;
		}
	};

	function getFieldValue(field, value) {
		// Blank Place holder for value
		var fieldValue = {
			field: field.name,
			query: "",
			pageNumber: 0,
			origin: "AUTO",
			xMin: 0.00,
			xMax: 0.00,
			yMin: 0.00,
			yMax: 0.00
		};
		// Sanitize query
		if (typeof value.query == "undefined" || value.query == null) {
			value.query = "";
		}
		// Update the placeholder with values. Whatever is missing will have default values from placeholder
		fieldValue = Object.assign(fieldValue, value);
		return fieldValue;
	}

	$scope.dynamicDesignPropertiesControls = function (field, value, fieldCtrl, flagProperties) {
		var controlsToProcess = fieldCtrl.controls;
		let controlsCount = controlsToProcess.length;
		for (var p = 0; p < controlsCount; p++) {
			if (flagProperties === 'disabled') {
				$scope.disableCtrl[controlsToProcess[p]] = true;
			}
			if (flagProperties === 'required') {
				$scope.requiredCtrl[controlsToProcess[p]] = true;
			}

			if (flagProperties === 'visibility') {
				var flag = (fieldCtrl.name) ? false : true;
				$scope.visibilityCtrl[controlsToProcess[p]] = flag;
			}
			if (flagProperties === 'style') {
				var fieldObject = $("#" + controlsToProcess[p]);
				if (fieldObject.length > 0) {
					fieldObject.attr("style", fieldCtrl.styleProperties);
				}
				if (fieldCtrl.styleProperties.includes('display:none')) {
					$scope.visibilityCtrl[controlsToProcess[p]] = false;
				}
				if (fieldCtrl.styleProperties.includes('display:initial') || fieldCtrl.styleProperties.includes('display:block')) {
					$scope.visibilityCtrl[controlsToProcess[p]] = true;
				}
			}
		}
	};

	// #region Dropdown Initialization Code

	$scope.initializeSelect = function (field, fieldName, indexVal) {
		var placeholderText = "-- Select --";

		// Get the list of options
		var optionList = $scope.prepareOptionLists(field.masterListValue);

		// set displayText and values
		var displayTexts = optionList.texts;
		var displayValues = optionList.values;

		if (field.hasOwnProperty("placeholder") && field.placeholder != null) {
			placeholderText = field.placeholder;
		}

		displayTexts = [placeholderText].concat(displayTexts);
		displayValues = [""].concat(displayValues);

		if (field.type === "select") {
			$scope.bindSelect(displayTexts, displayValues, indexVal, field);
		}
		else if (field.type === "multiselect") {
			$scope.bindMultiselect(displayTexts, displayValues, indexVal, field);
		}

		return true;
	};

	$scope.prepareOptionLists = function (listName) {
		var displayTexts;
		var displayValues;

		var blankList = {
			texts: [],
			values: []
		};
		// No Master List Given */
		if (!listName) {
			if (!enableTestMode) { raiseAppianError("Master List is not available."); }
			return blankList;
		}
		// Check if the list is already prepared
		if ($scope.OptionLists[listName] && $scope.OptionLists[listName].texts.length > 0) {
			return $scope.OptionLists[listName];
		}

		// Check if Separate Text and Values are given
		// If text is present in the master list then use it
		displayTexts = $scope.globalMasterValues[listName].text;
		if (displayTexts === undefined || displayTexts === null) {
			displayTexts = $scope.globalMasterValues[listName];
			displayValues = $scope.globalMasterValues[listName];
		}
		else {
			displayTexts = $scope.globalMasterValues[listName].text;
			displayValues = $scope.globalMasterValues[listName].value;
			/* Check if text and values, both arrays have same length */
			if (displayTexts.length !== displayValues.length) {
				raiseAppianError("text & value length mismatch in given master list : " + listName);
				return blankList;
			}
		}

		$scope.OptionLists[listName] = {
			texts: displayTexts,
			values: displayValues
		};
		return $scope.OptionLists[listName];
	};

	$scope.bindSelect = function (displayTexts, displayValues, index, field) {
		var selectedValue = displayValues[0];
		var pageNumber = 0;
		var origin = 0;
		var xMin = 0;
		var xMax = 0;
		var yMin = 0;
		var yMax = 0;
		var fieldName = field.name;
		var elementId = fieldName + "_" + index;

		var dropDownVal = {};
		/* Get Parameters of selected value */
		if (field.hasOwnProperty('rows') && field.rows[0].hasOwnProperty('isSelected')) {
			var row = field.rows[0];

			if (displayValues.indexOf(row.query) > -1 && row.isSelected) {
				selectedValue = row.query;
				pageNumber = row.pageNumber;
				origin = row.origin;
				xMin = row.xMin;
				xMax = row.xMax;
				yMin = row.yMin;
				yMax = row.yMax;
			}
		}

		// Get the old selected value from the model container
		if (typeof $scope.selectedVal[fieldName] !== 'undefined' && $scope.selectedVal[fieldName] != null) {
			selectedValue = $scope.selectedVal[fieldName];
		}

		/* Backward Compatibility code. DO NOT CHANGE
		 * START
		 * */
		if (typeof selectedValue === 'undefined' || selectedValue == null) {
			selectedValue = $scope.selectedOptions[field.name];
		}
		/* Backward Compatibility code. DO NOT CHANGE
		 * END
		 * */

		var flagVal;
		if ($scope.isInArray(selectedValue.query, booleanValues)) { flagVal = true; }
		else { flagVal = $scope.isInArray(selectedValue.query, displayValues); }

		for (var i = 0; i < displayTexts.length; i++) {
			if (i === 0 && flagVal === false) {
				selectedValue = true;
				$scope.selectedVal[fieldName].query = displayValues[i];
			}
			else {
				selectedValue = false;
			}

			dropDownVal[i] = {
				query: displayTexts[i],
				value: displayValues[i],
				pagenumber: pageNumber,
				origin: origin,
				xMin: xMin,
				xMax: xMax,
				yMin: yMin,
				yMax: yMax,
				isSelected: selectedValue
				//isSelected: $scope.isValueSelected(selectedValue, displayValues[i])
			};
		}
		if ($scope.initialLoadCascadingDropdownValues[fieldName] === 'undefined' || $scope.initialLoadCascadingDropdownValues[fieldName] == null) {
			$scope.dropDownValues[elementId] = dropDownVal;
			$scope.masterListElement[fieldName] = elementId;
		}
		else {
			$scope.dropDownValues[elementId] = $scope.initialLoadCascadingDropdownValues[fieldName];
			$scope.masterListElement[fieldName] = elementId;
		}
	};

	$scope.bindMultiselect = function (displayTexts, displayValues, index, field) {
		var selectedValue = [];
		var query = [];
		var pageNumber = 0;
		var origin = 0;
		var xMin = 0;
		var xMax = 0;
		var yMin = 0;
		var yMax = 0;
		var fieldName = field.name;
		var elementId = fieldName + "_" + index;

		var dropDownVal = {};

		var counter;
		/* Get Parameters of selected value */
		if (field.hasOwnProperty("rows")) {
			for (counter = 0; counter < field.rows.length; counter++) {
				var row = field.rows[counter];

				if (displayValues.indexOf(row.query) > -1 && row.hasOwnProperty("isSelected") && row.isSelected) {
					query.push(
						{
							query: row.query,
							selectedValue: row.query,
							pageNumber: row.pageNumber,
							origin: row.origin,
							xMin: row.xMin,
							xMax: row.xMax,
							yMin: row.yMin,
							yMax: row.yMax
						}
					);
				}
			}
		}

		/* Backward Compatibility code. DO NOT CHANGE
		 * START
		 * */
		for (counter = 0; counter < query.length; counter++) {
			selectedValue.push(query[counter].query);
		}

		if (query.length == 0) {
			var values = $scope.uiConfig.selectedOptions[field.name];

			for (counter = 0; counter < values.length; counter++) {
				selectedValue.push(values[counter].query);
			}
		}

		/* Backward Compatibility code. DO NOT CHANGE
		 * END
		 * */
		$scope.selectedVal[fieldName] = selectedValue;

		for (var i = 0; i < displayTexts.length; i++) {
			dropDownVal[i] = {
				query: displayTexts[i],
				value: displayValues[i],
				pagenumber: pageNumber,
				origin: origin,
				xMin: xMin,
				xMax: xMax,
				yMin: yMin,
				yMax: yMax,
				isSelected: $scope.isValueSelected(selectedValue, displayValues[i])
			};
		}

		$scope.dropDownValues[elementId] = dropDownVal;
		$scope.masterListElement[fieldName] = elementId;
	};

	$scope.isValueSelected = function (value, valueToCheckAgainst) {
		if (typeof valueToCheckAgainst == "undefined" || valueToCheckAgainst == null) { return false; }
		if (typeof value == "undefined" || value == null) { return false; }
		if (typeof value == "object") { value = value.query; }
		if (typeof value == "undefined" || value == null) { return false; }

		return value.toString().toLowerCase() === valueToCheckAgainst.toString().toLowerCase();
	};

	// #endregion Dropdown Code

	// #endregion Controls Code

	// #region Helper Functions

	// This function will update the input as per version 1.0's structure
	// like converts array into Key:Objects structure, so the plugin can handle  
	function convertInputArrayInRequiredFormat(inputs) {
		var returnValue;
		var newFormValues = {};

		// Handle All the fields defined at root level
		var rootLevelFields = inputs.formDetails.fields;
		var rootLevelMilestones = inputs.formDetails.milestones;

		// Prepare Root Level Fields
		returnValue = convertArrayToDictionary(rootLevelFields, inputs.formValues, "root");

		if (!returnValue.container) { return inputs; }

		rootLevelMilestones = returnValue.container;
		newFormValues = Object.assign(newFormValues, returnValue.tempObject);

		// Prepare Milestones
		for (let mileCount = rootLevelMilestones.length - 1; mileCount >= 0; mileCount--) {
			returnValue = convertArrayToDictionary(rootLevelMilestones[mileCount], inputs.formValues, "milestone");
			rootLevelMilestones[mileCount] = returnValue.container;
			newFormValues = Object.assign(newFormValues, returnValue.tempObject);

			// for fields within sections
			const sections = rootLevelMilestones[mileCount].sections;
			for (let i = sections.length - 1; i >= 0; i--) {
				returnValue = convertArrayToDictionary(sections[i], inputs.formValues, "section");
				sections[i] = returnValue.container;
				newFormValues = Object.assign(newFormValues, returnValue.tempObject);
			}
		}
		inputs.formValues = newFormValues;
		return inputs;
	}

	function convertArrayToDictionary(container, values, typeOfContainer) {
		var tempObject = {};
		var fieldType;

		if (!container) {
			return {
				container: container,
				tempObject: tempObject
			};
		}

		const fields = container.fields;

		if (container.hasOwnProperty("fields") && fields.length) {
			for (let fieldIndex = 0; fieldIndex < fields.length; fieldIndex++) {
				const fieldName = fields[fieldIndex].name;
				fieldType = fields[fieldIndex].type;
				/*
				 * Create a backup of the control to be used later
				 */
				// Save the current layout to old layout container
				$scope.oldLayoutDetails[fieldName] = $scope.layoutDetails[fieldName];
				// Update the current layout with new value
				$scope.layoutDetails[fieldName] = fields[fieldIndex];

				for (let index = 0; index < values.length; index++) {
					const fieldValue = values[index];

					if (fieldValue.field !== fieldName) { continue; }

					if (isSupportedType(fieldType, "arrayTypes")) {
						if (!tempObject[fieldName]) {
							tempObject[fieldName] = fieldValue;
						}
					}
					else {
						tempObject[fieldName] = fieldValue;
					}

					if (typeOfContainer === "milestone" && fieldType === "grid") {
						convertGridFieldsInRequiredFormat(fieldValue.rows);
					}
				}
			}
		}

		return {
			container: container,
			tempObject: tempObject
		};
	}

	function isSupportedType(fieldType, typeToCheck) {
		return $scope.supportedWebFields[typeToCheck].indexOf(fieldType) > -1;
	}

	// #region Date Format Code

	/*
	 * Parses the given value on the formats and returns the date if success
	 * in case of failure, blank string is returned
	 */
	function formatDate(value, inputFormat, outputFormat) {
		// If no value then return blank string
		if (value == undefined || value == null) {
			return "";
		}

		// if no input format then default to format from global config
		if (inputFormat == undefined || inputFormat == null || inputFormat.trim() === "") {
			inputFormat = $scope.globalConfig.dateFormat;
		}

		// If the date format is still null then change it to ISO8601
		if (inputFormat == undefined || inputFormat == null || inputFormat.trim() === "") {
			inputFormat = "yyyy-MM-dd";
		}

		// if no output format then default to format from global config
		if (outputFormat == undefined || outputFormat == null || outputFormat.trim() === "") {
			outputFormat = $scope.globalConfig.outputDateFormat;
		}

		// If the date format is still null then change it to ISO8601
		if (outputFormat == undefined || outputFormat == null || outputFormat.trim() === "") {
			outputFormat = "yyyy-MM-dd";
		}

		var formattedDate;

		// Parse the date on given input format
		var parsedDate = luxonDateTime.fromFormat(value, inputFormat);

		// If Parse Failed,
		if (!parsedDate.isValid) {
			// Log the failure reason with value and format
			console.log(parsedDate.invalidReason, ":", value, inputFormat);
			// try output format
			parsedDate = luxonDateTime.fromFormat(value, outputFormat);
		}

		// Parse failed again, try parsing it with default JS Date object
		if (!parsedDate.isValid) {
			// Log the failure reason with value and format
			console.log(parsedDate.invalidReason, ":", value, outputFormat);
			parsedDate = Date.parse(value);

			// Check if the date is valid 
			if (!(parsedDate instanceof Date) || isNaN(parsedDate)) {
				// Parse Failed again, date seems to be invalid,
				// Log the value, object
				console.log(parsedDate, ":", value);
				//return blank value
				return "";
			}
			else {
				// Convert the date from JS date
				parsedDate = luxonDateTime.fromJSDate(parsedDate);
				// Format the date
				formattedDate = parsedDate.toFormat(outputFormat);
				// Return the formatted date
				return formattedDate;
			}
		}
		// If reached here then date is parsed via luxon and valid 
		// Convert the date in proper format if possible
		formattedDate = parsedDate.toFormat(outputFormat);
		// Return the formatted date
		return formattedDate;
	}

	// #endregion Date Format Code

	$scope.isInArray = function (value, array) {
		return array.indexOf(value) > -1;
	};

	// #endregion Helper Functions

	// #region Web Worker

	self.addEventListener('message',
		function (data) {
			sanitizeField(data.field, data.inputs);
		});

	// #endregion Web Worker
});