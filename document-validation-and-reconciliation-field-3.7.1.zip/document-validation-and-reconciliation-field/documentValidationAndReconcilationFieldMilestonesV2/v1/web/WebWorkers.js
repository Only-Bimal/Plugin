
var appianInputValidationResult = [];
onmessage = (e, scope) => {
	let inputs = e.data;
	validateAppianInput(inputs);
};

function validateAppianInput(inputs) {
	if (inputs.formDetails == undefined || inputs.formDetails == null) {
		appianInputValidationResult.push("Required fields are missing: formDetails");
	}

	if (inputs.formValues == undefined || inputs.formValues == null) {
		appianInputValidationResult.push("Required fields are missing: formValues");
	}
	if (inputs.config == undefined || inputs.config == null) {
		appianInputValidationResult.push("Required fields are missing: config");
	}

	//validating formDetails and values
	inputs.formDetails.milestones.forEach(function (milestone) {
		milestone.sections.forEach(function (section) {
			section.fields.forEach(function (field) {
				if (inputs.formValues[field.name] == null || inputs.formValues[field.name] == undefined || inputs.formValues[field.name].length == 0 || inputs.formValues[field.name].length == undefined) {
					return;
				}
				switch (field.type) {
					case "text": break;
					case "currency": break;
					case "paragraph": break;
					case "number":
						if (inputs.formValues[field.name].query != null && parseFloat(inputs.formValues[field.name].query) == "NaN")
							appianInputValidationResult.push("Invalid Value in " + field.name + ": should be a number, but " + inputs.formValues[field.name].query + " is given.");
						break;
					case "date": break;
					case "select":
						if (!Array.isArray(inputs.formValues[field.name].rows))
							appianInputValidationResult.push("Invalid Value: formValue Must be an array for " + field.name);
						break;
					case "multiselect":
						if (!Array.isArray(inputs.formValues[field.name].rows))
							appianInputValidationResult.push("Invalid Value: formValue Must be an array for " + field.name);
						break;
					case "grid": break;
					case "button-group":
						if (!Array.isArray(inputs.formValues[field.name].rows))
							appianInputValidationResult.push("Invalid Value: formValue Must be an array for " + field.name);
						break;
				}
			});
		});
	});
	setScopeValues(inputs);
}
function setScopeValues(inputs) {
	let scope = {
		disableCtrl: {},
		styleCtrl: {},
		requiredCtrl: {},
		visibilityCtrl: {}
	};

	inputs.formDetails.milestones.forEach(function (eachMilestone) {
		// handle fields inside milestone here
		if (eachMilestone.hasOwnProperty("fields") && eachMilestone.fields.length) {
			eachMilestone.fields.forEach(function (eachField) {
				scope.disableCtrl[eachField.name] = eachField.disabled;
				scope.styleCtrl[eachField.name] = eachField.style.style;
				scope.requiredCtrl[eachField.name] = eachField.required;
				scope.visibilityCtrl[eachField.name] = eachField.visible;
				// sanitizeField(eachField, previouslySelected, inputs);
			});
		}
		eachMilestone.sections.forEach(function (section) {
			section.fields.forEach(function (field) {
				scope.styleCtrl[field.name] = field.style.style;
				scope.disableCtrl[field.name] = field.disabled;
				scope.styleCtrl[field.name] = field.style.style;
				scope.requiredCtrl[field.name] = field.required;
				scope.visibilityCtrl[field.name] = field.visible;
				// sanitizeField(field, previouslySelected, inputs);
			});
		});
	});
	const response = {
		appianValidation: appianInputValidationResult,
		scopeValue: scope
	};
	postMessage(response);
}