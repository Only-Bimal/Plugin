﻿window.TEST_VALUES = {
	/* Enable Test Mode */
	enableTestMode: true,
	/* Configuration */
	config: {
		defaultRectanglePadding: 1,
		clearCanvasBeforeHighlighting: true,
		highlightTextOnElementFocus: true,
		highlightAll: true,
		pdfGlobalSearch: false,
		dateLocale: "Europe/London",
		dateFormat: "dd/MM/yyyy",
		/* Sum of pdfViewerBootstrapFrames & formPanelBootstrapFrames should always be 12 */
		pdfViewerBootstrapFrames: "5",
		formPanelBootstrapFrames: "7"
	},
	/* Annotations */
	annotationObject: {
		/* if true then ONLY query will be searched otherwise coordinates will be highlighted */
		phraseSearch: false,
		caseSensitive: false,
		entireWord: false,
		highlightAll: true,
		findPrevious: false
	},
	/* Master Data */
	masterValues: {
		DropdownInGrid: ["DIG1", "DIG2", "DIG3", "DIG4"],
		DropdownOutsideGrid: ["DOG1", "DOG2", "DOG3", "DOG4"],
		MultiInGrid: ["MIG1", "MIG2", "MIG3", "MIG4"],
		MultiOutsideGrid: ["MOG1", "MOG2", "MOG3", "MOG4"],
		SearchDDInGrid: ["SIG1", "SIG2", "SIG3", "SIG4"],
		SearchDDOutsideGrid: ["SOG1", "SOG2", "SOG3", "SOG4"],
		YesNoList: {
			text: ["Yes", "No"],
			value: [1, 0]
		}
	},
	/* Layout */
	formDetails: {
		/* Global Layout Settings */
		verticalMargin: "0px",
		vSpacingBetweenFields: "0px",
		verticalTabs: false,
		/* Form Style */
		style: {
			formClass: "",
			formStyle: "padding: 0",
			/* Is Tab Layout justified */
			justifiedTabs: false
		},
		/* Milestones (Tabs) Is Array of Objects */
		milestones: [
			/* First Tab */
			{
				/* Tab Name */
				name: "Tab_1",
				/* Tab Display Text (Label) */
				label: "Tab 1",
				/* Tab Position when rendered */
				sortOrder: 1,
				/* Tab Style */
				style: {
					/* Tab Header Style */
					tabStyle: "",
					/* Tab Page Style */
					contentStyle: "",
					/* Tab Page Class */
					contentClass: "",
					/*TODO: Implement Active/Inactive tab styling */
					active: {
						/* Active Tab Header Style */
						tabStyle: "color:red",
						/* Active Tab Page Style */
						contentStyle: "background-color: dimgrey;",
						/* Active Tab Page Class */
						contentClass: ""
					}
				},
				/* Fields/Controls in the tab page.
				 * Is an array of component definition
				 */
				fields: [
					/* Label */
					{
						/* Component Type */
						type: "label",
						/* Component Name */
						name: "labelOutsideGrid",
						/* Label to Show with the field */
						label: "Label Outside Grid",
						/* Visibility of the Field */
						visible: true,
						/* Label Visibility */
						showLabel: true,
						/* Label Field Styling */
						style: {
							/* Class for Field Div */
							divClass: "col-md-6",
							/* Style for Field Div */
							divStyle: "",
							/* Class for Field Label */
							labelClass: "",
							/* Style for Field Label */
							style: "",
							/* Class for the Field */
							fieldClass: ""
						},
						/* Icon Definition */
						icon: {
							/* Icon Visibility */
							visible: true,
							/* Icon to show, uses fontawesome 4.2 as "fa fa-<icon> */
							icon: "times",
							/* Style of Icon */
							style: "font-size:20px; color:lightblue"
						}
					},
					/* Text Box */
					{
						/* Component Type */
						type: "text",
						/* Component Name */
						name: "textboxOutsideGrid",
						/* Label to Show with the field */
						label: "Textbox Outside Grid",
						/* Visibility of the Field */
						visible: true,
						/* Is Field Required */
						required: true,
						/* Is Field Disabled */
						disabled: false,
						/* Label Visibility */
						showLabel: true,
						/* Placeholder */
						placeholder: "Textbox outside Grid",
						/* Textbox Field Styling */
						style: {
							/* Class for Field Div */
							divClass: "col-md-6",
							/* Style for Field Div */
							divStyle: "",
							/* Class for Field Label */
							labelClass: "",
							/* Style for Field  */
							style: "",
							/* Class for the Field */
							fieldClass: "form-control"
						},
						/* Icon Definition */
						icon: {
							/* Icon Visibility */
							visible: true,
							/* Icon to show, uses fontawesome 4.2 as "fa fa-<icon> */
							icon: "times",
							/* Style of Icon */
							style: "font-size:20px; color:lightblue"
						}
					},
					/* number Box */
					{
						/* Component Type */
						type: "number",
						/* Component Name */
						name: "numberOutsideGrid",
						/* Label to Show with the field */
						label: "Numeric box Outside Grid",
						/* Visibility of the Field */
						visible: true,
						/* Is Field Required */
						required: true,
						/* Is Field Disabled */
						disabled: false,
						/* Label Visibility */
						showLabel: true,
						/* Placeholder */
						placeholder: "###### Numbers only",
						/* Label Field Styling */
						style: {
							/* Class for Field Div */
							divClass: "col-md-6",
							/* Style for Field Div */
							divStyle: "",
							/* Class for Field Label */
							labelClass: "",
							/* Style for Field  */
							style: "",
							/* Class for the Field */
							fieldClass: "form-control"
						},
						/* Icon Definition */
						icon: {
							/* Icon Visibility */
							visible: true,
							/* Icon to show, uses fontawesome 4.2 as "fa fa-<icon> */
							icon: "times",
							/* Style of Icon */
							style: "font-size:20px; color:lightblue"
						}
					},
					/* Currency Box */
					{
						/* Component Type */
						type: "currency",
						/* Component Name */
						name: "currencyOutsideGrid",
						/* Label to Show with the field */
						label: "currency Outside Grid",
						/* Visibility of the Field */
						visible: true,
						/* Is Field Required */
						required: true,
						/* Is Field Disabled */
						disabled: false,
						/* Label Visibility */
						showLabel: true,
						/* Placeholder */
						placeholder: "currency outside grid",
						/* Label Field Styling */
						style: {
							/* Class for Field Div */
							divClass: "col-md-6",
							/* Style for Field Div */
							divStyle: "",
							/* Class for Field Label */
							labelClass: "",
							/* Style for Field  */
							style: "",
							/* Class for the Field */
							fieldClass: "form-control"
						},
						/* Icon Definition */
						icon: {
							/* Icon Visibility */
							visible: true,
							/* Icon to show, uses fontawesome 4.2 as "fa fa-<icon> */
							icon: "times",
							/* Style of Icon */
							style: "font-size:20px; color:lightblue"
						},
						/* Symbol before editor configuration */
						symbol: {
							/* Symbol/Text to show */
							symbol: "$",
							/* Symbol Style */
							style: "",
							/* Symbol Visible or not */
							visible: true
						}
					},
					/* Date */
					{
						/* Component Type */
						type: "date",
						/* Component Name */
						name: "dateOutsideGrid",
						/* Label to Show with the field */
						label: "Date Outside Grid",
						/* Visibility of the Field */
						visible: true,
						/* Is Field Required */
						required: true,
						/* Is Field Disabled */
						disabled: false,
						/* Label Visibility */
						showLabel: true,
						/* Placeholder */
						placeholder: "dd/MM/yyyy",
						/* Label Field Styling */
						style: {
							/* Class for Field Div */
							divClass: "col-md-6",
							/* Style for Field Div */
							divStyle: "",
							/* Class for Field Label */
							labelClass: "",
							/* Style for Field  */
							style: "",
							/* Class for the Field */
							fieldClass: "form-control"
						},
						/* Icon Definition */
						icon: {
							/* Icon Visibility */
							visible: true,
							/* Icon to show, uses fontawesome 4.2 as "fa fa-<icon> */
							icon: "times",
							/* Style of Icon */
							style: "font-size:20px; color:lightblue"
						}
					},
					/* Select */
					{
						/* Component Type */
						type: "select",
						/* Component Name */
						name: "dropdownOutsideGrid",
						/* Label to Show with the field */
						label: "Dropdown Outside Grid",
						/* Visibility of the Field */
						visible: true,
						/* Is Field Required */
						required: true,
						/* Is Field Disabled */
						disabled: false,
						/* Label Visibility */
						showLabel: true,
						/* Master List to pick options from */
						masterListValue: "DropdownOutsideGrid",
						/* Label Field Styling */
						style: {
							/* Class for Field Div */
							divClass: "col-md-6",
							/* Style for Field Div */
							divStyle: "",
							/* Class for Field Label */
							labelClass: "",
							/* Class for the Field */
							fieldClass: "form-control",
							/* Style for Field */
							style: ""
						},
						/* Icon Definition */
						icon: {
							/* Icon Visibility */
							visible: true,
							/* Icon to show, uses fontawesome 4.2 as "fa fa-<icon> */
							icon: "times",
							/* Style of Icon */
							style: "font-size:20px; color:lightblue"
						},
						//* Rows of value for select/dropdown */
						//rows: [
						//	{
						//		/* Value to show in the field */
						//		query: "DOG1",
						//		/* Numeric Id of the field */
						//		/*TODO: Check if it is of use */
						//		id: 1,
						//		/* Page number from PDF where it has been extracted */
						//		pageNumber: 4,
						//		/* Origin in the PDF */
						//		origin: "AUTO",
						//		/* Top Left and bottom right cordinates of the region
						//		 * From where the value has been extracted
						//		 * */
						//		xMin: 0.445,
						//		xMax: 0.551,
						//		yMin: 0.295,
						//		yMax: 0.204,
						//		/* isSelected needs to be specified for values selection to work */
						//		isSelected: true
						//	}
						//]
					},
					/* Searchable Dropdown */
					{
						/* Component Type */
						type: "searchableDropdown",
						/* Component Name */
						name: "searchDDOutsideGrid",
						/* Label to Show with the field */
						label: "Searchable Dropdown Outside Grid",
						/* Visibility of the Field */
						visible: true,
						/* Is Field Required */
						required: true,
						/* Is Field Disabled */
						disabled: false,
						/* Label Visibility */
						showLabel: true,
						/* Master List to pick options from */
						masterListValue: "SearchDDOutsideGrid",
						/* Label Field Styling */
						style: {
							/* Class for Field Div */
							divClass: "col-md-6",
							/* Style for Field Div */
							divStyle: "",
							/* Class for Field Label */
							labelClass: "",
							/* Class for the Field */
							fieldClass: "form-control"
						},
						/* Icon Definition */
						icon: {
							/* Icon Visibility */
							visible: true,
							/* Icon to show, uses fontawesome 4.2 as "fa fa-<icon> */
							icon: "times",
							/* Style of Icon */
							style: "font-size:20px; color:lightblue"
						}
					},
					/* button */
					{
						/* Component Type */
						type: "button",
						/* Component Name */
						name: "buttonOutsideGrid",
						/* Label to Show with the field */
						label: "Button Outside Grid",
						/* Visibility of the Field */
						visible: true,
						/* Is Field Disabled */
						disabled: false,
						/* Label Visibility */
						showLabel: true,
						/* Label Field Styling */
						style: {
							/* Class for Field Div */
							divClass: "col-md-6",
							/* Style for Field Div */
							divStyle: "",
							/* Class for Field Label */
							labelClass: "",
							/* Class for the Field */
							fieldClass: "btn-success"
						},
						/* Icon Definition */
						icon: {
							/* Icon Visibility */
							visible: true,
							/* Icon to show, uses fontawesome 4.2 as "fa fa-<icon> */
							icon: "times",
							/* Style of Icon */
							style: ""
						}
					},
					/* Paragraph Box */
					{
						/* Component Type */
						type: "paragraph",
						/* Component Name */
						name: "paragraphOutsideGrid",
						/* Label to Show with the field */
						label: "Paragraph Outside Grid",
						/* Visibility of the Field */
						visible: true,
						/* Is Field Required */
						required: true,
						/* Is Field Disabled */
						disabled: false,
						/* Label Visibility */
						showLabel: true,
						/* Placeholder */
						placeholder: "Paragraph outside Grid",
						/* Label Field Styling */
						style: {
							/* Class for Field Div */
							divClass: "col-md-6",
							/* Style for Field Div */
							divStyle: "",
							/* Class for Field Label */
							labelClass: "",
							/* Style for Field  */
							style: "",
							/* Class for the Field */
							fieldClass: "form-control"
						},
						/* Icon Definition */
						icon: {
							/* Icon Visibility */
							visible: true,
							/* Icon to show, uses fontawesome 4.2 as "fa fa-<icon> */
							icon: "times",
							/* Style of Icon */
							style: "font-size:20px; color:lightblue"
						}
					},
					/* Multiselect */
					{
						/* Component Type */
						type: "multiselect",
						/* Component Name */
						name: "multiselectOutsideGrid",
						/* Label to Show with the field */
						label: "Multiselect Outside Grid",
						/* Visibility of the Field */
						visible: true,
						/* Is Field Required */
						required: true,
						/* Is Field Disabled */
						disabled: false,
						/* Label Visibility */
						showLabel: true,
						/* Master List to pick options from */
						masterListValue: "MultiOutsideGrid",
						/* Label Field Styling */
						style: {
							/* Class for Field Div */
							divClass: "col-md-6",
							/* Style for Field Div */
							divStyle: "",
							/* Class for Field Label */
							labelClass: "",
							/* Class for the Field */
							fieldClass: "form-control"
						},
						/* Icon Definition */
						icon: {
							/* Icon Visibility */
							visible: true,
							/* Icon to show, uses fontawesome 4.2 as "fa fa-<icon> */
							icon: "times",
							/* Style of Icon */
							style: "font-size:20px; color:lightblue"
						}
					}
				],
				/* Sections is An Array of Objects
				 * It Creates a collapsible Panel with a header and a body
				 * The body can be hidden by clicking on the header
				 * */
				sections: [
					{
						/* Name of the Section */
						name: "Section1",
						/* Label to Show on the header */
						label: "Section 1",
						/* Visibility of the Section */
						visible: true,
						/* Is the section initially collapsed/hidden */
						collapsed: false,
						/* Styling of the Section */
						style: {
							/* Class for the section header */
							headerClass: "",
							/* Style for the section header */
							headerStyle: "",
							/* Class for section body */
							bodyClass: "",
							/* Style for section body */
							bodyStyle: ""
						},
						/* Fields in the Section */
						fields: [
							/* Grid/Table Field */
							{
								/* Componenet Type */
								type: "grid",
								/* Name of the Table/Grid */
								name: "Grid1",
								/* Label to Show with the field */
								label: "Grid 1",
								/* Label Visibility */
								showLabel: false,
								/* Grid Field Styling */
								style: {
									/* Class for Field Div */
									divClass: "col-md-12",
									/* Style for Field Div */
									divStyle: "padding: 2px;",
									/* Class for Field Label */
									labelClass: "",
									/* Class for the Table */
									fieldClass: "table table-bordered table-hover table-striped table-condensed",
									/* Style for the Table */
									style: ""
								},
								/* Columns to display inthe table
								 * Is An Array 
								 * */
								columns: [
									/* Definition of All the Columns */
									{
										/* Column Header */
										header: "Header 1",
										/* Class for the Header */
										headerClass: "",
										/* Style for the Header */
										headerStyle: ""
									},
									{
										/* Column Header */
										header: "Header 2",
										/* Class for the Header */
										headerClass: "",
										/* Style for the Header */
										headerStyle: ""
									},
									{
										/* Column Header */
										header: "Header 3",
										/* Class for the Header */
										headerClass: "",
										/* Style for the Header */
										headerStyle: ""
									},
									{
										/* Column Header */
										header: "Header 4",
										/* Class for the Header */
										headerClass: "",
										/* Style for the Header */
										headerStyle: ""
									}
								]
							}
						]
					}
				]
			}
		]
	},
	/* Values for Fields, is an Array of objects */
	formValues: [
		{
			/* Name of the field */
			field: "labelOutsideGrid",
			/* Value to show in the field */
			query: "Label Value",
			/* Numeric Id of the field */
			/*TODO: Check if it is of use */
			id: 1,
			/* Page number from PDF where it has been extracted */
			pageNumber: 20,
			/* Origin in the PDF */
			origin: "AUTO",
			/* Top Left and bottom right cordinates of the region
			 * From where the value has been extracted
			 * */
			xMin: 0.335,
			xMax: 0.441,
			yMin: 0.185,
			yMax: 0.194
		},
		{
			/* Name of the field */
			field: "textboxOutsideGrid",
			/* Value to show in the field */
			query: "Textbox Value",
			/* Numeric Id of the field */
			/*TODO: Check if it is of use */
			id: 1,
			/* Page number from PDF where it has been extracted */
			pageNumber: 20,
			/* Origin in the PDF */
			origin: "AUTO",
			/* Top Left and bottom right cordinates of the region
			 * From where the value has been extracted
			 * */
			xMin: 0.335,
			xMax: 0.441,
			yMin: 0.185,
			yMax: 0.194
		},
		{
			/* Name of the field */
			field: "numberOutsideGrid",
			/* Value to show in the field */
			query: "123456789.00",
			/* Numeric Id of the field */
			/*TODO: Check if it is of use */
			id: 1,
			/* Page number from PDF where it has been extracted */
			pageNumber: 2,
			/* Origin in the PDF */
			origin: "AUTO",
			/* Top Left and bottom right cordinates of the region
			 * From where the value has been extracted
			 * */
			xMin: 0.435,
			xMax: 0.541,
			yMin: 0.285,
			yMax: 0.294
		},
		{
			/* Name of the field */
			field: "currencyOutsideGrid",
			/* Value to show in the field */
			query: "987654321.00",
			/* Numeric Id of the field */
			/*TODO: Check if it is of use */
			id: 1,
			/* Page number from PDF where it has been extracted */
			pageNumber: 3,
			/* Origin in the PDF */
			origin: "AUTO",
			/* Top Left and bottom right cordinates of the region
			 * From where the value has been extracted
			 * */
			xMin: 0.435,
			xMax: 0.541,
			yMin: 0.285,
			yMax: 0.294
		},
		{
			/* Name of the field */
			field: "dateOutsideGrid",
			/* Value to show in the field */
			query: "13/09/2022",
			/* Numeric Id of the field */
			/*TODO: Check if it is of use */
			id: 1,
			/* Page number from PDF where it has been extracted */
			pageNumber: 4,
			/* Origin in the PDF */
			origin: "AUTO",
			/* Top Left and bottom right cordinates of the region
			 * From where the value has been extracted
			 * */
			xMin: 0.445,
			xMax: 0.551,
			yMin: 0.295,
			yMax: 0.204
		},
		{
			/* Name of the field */
			field: "buttonOutsideGrid",
			/* Value to show in the field */
			query: "Delete ",
			/* Numeric Id of the field */
			/*TODO: Check if it is of use */
			id: 1,
			/* Page number from PDF where it has been extracted */
			pageNumber: 4,
			/* Origin in the PDF */
			origin: "AUTO",
			/* Top Left and bottom right cordinates of the region
			 * From where the value has been extracted
			 * */
			xMin: 0.445,
			xMax: 0.551,
			yMin: 0.295,
			yMax: 0.204
		},
		{
			/* Name of the field */
			field: "dropdownOutsideGrid",
			/* Rows of value for select/dropdown */
			rows: [
				{
					/* Value to show in the field */
					query: "DOG4",
					/* Numeric Id of the field */
					/*TODO: Check if it is of use */
					id: 1,
					/* Page number from PDF where it has been extracted */
					pageNumber: 4,
					/* Origin in the PDF */
					origin: "AUTO",
					/* Top Left and bottom right cordinates of the region
					 * From where the value has been extracted
					 * */
					xMin: 0.445,
					xMax: 0.551,
					yMin: 0.295,
					yMax: 0.204,
					/* isSelected needs to be specified for values selection to work */
					isSelected: true
				}
			]
		},
		{
			/* Name of the field */
			field: "multiselectOutsideGrid",
			/* Rows of value for multiselect */
			rows: [
				{
					/* Value to show in the field */
					query: "MOG3",
					/* Numeric Id of the field */
					/*TODO: Check if it is of use */
					id: 1,
					/* Page number from PDF where it has been extracted */
					pageNumber: 4,
					/* Origin in the PDF */
					origin: "AUTO",
					/* Top Left and bottom right cordinates of the region
					 * From where the value has been extracted
					 * */
					xMin: 0.445,
					xMax: 0.551,
					yMin: 0.295,
					yMax: 0.204,
					/* isSelected needs to be specified for values selection to work */
					isSelected: true
				},
				{
					/* Value to show in the field */
					query: "MOG2",
					/* Numeric Id of the field */
					/*TODO: Check if it is of use */
					id: 1,
					/* Page number from PDF where it has been extracted */
					pageNumber: 2,
					/* Origin in the PDF */
					origin: "AUTO",
					/* Top Left and bottom right cordinates of the region
					 * From where the value has been extracted
					 * */
					xMin: 0.145,
					xMax: 0.251,
					yMin: 0.395,
					yMax: 0.404,
					/* isSelected needs to be specified for values selection to work */
					isSelected: true
				}
			]
		},
		{
			/* Name of the field */
			field: "searchDDOutsideGrid",
			/* Rows of value for multiselect */
			rows: [
				{
					/* Value to show in the field */
					query: "SOG1",
					/* Numeric Id of the field */
					/*TODO: Check if it is of use */
					id: 1,
					/* Page number from PDF where it has been extracted */
					pageNumber: 4,
					/* Origin in the PDF */
					origin: "AUTO",
					/* Top Left and bottom right cordinates of the region
					 * From where the value has been extracted
					 * */
					xMin: 0.445,
					xMax: 0.551,
					yMin: 0.295,
					yMax: 0.204,
					/* isSelected needs to be specified for values selection to work */
					isSelected: true
				},
				{
					/* Value to show in the field */
					query: "SOG2",
					/* Numeric Id of the field */
					/*TODO: Check if it is of use */
					id: 1,
					/* Page number from PDF where it has been extracted */
					pageNumber: 2,
					/* Origin in the PDF */
					origin: "AUTO",
					/* Top Left and bottom right cordinates of the region
					 * From where the value has been extracted
					 * */
					xMin: 0.145,
					xMax: 0.251,
					yMin: 0.395,
					yMax: 0.404,
					/* isSelected needs to be specified for values selection to work */
					isSelected: false
				},
				{
					/* Value to show in the field */
					query: "SOG3",
					/* Numeric Id of the field */
					/*TODO: Check if it is of use */
					id: 1,
					/* Page number from PDF where it has been extracted */
					pageNumber: 2,
					/* Origin in the PDF */
					origin: "AUTO",
					/* Top Left and bottom right cordinates of the region
					 * From where the value has been extracted
					 * */
					xMin: 0.135,
					xMax: 0.241,
					yMin: 0.385,
					yMax: 0.494,
					/* isSelected needs to be specified for values selection to work */
					isSelected: false
				},
				{
					/* Value to show in the field */
					query: "SOG4",
					/* Numeric Id of the field */
					/*TODO: Check if it is of use */
					id: 1,
					/* Page number from PDF where it has been extracted */
					pageNumber: 2,
					/* Origin in the PDF */
					origin: "AUTO",
					/* Top Left and bottom right cordinates of the region
					 * From where the value has been extracted
					 * */
					xMin: 0.155,
					xMax: 0.271,
					yMin: 0.305,
					yMax: 0.414,
					/* isSelected needs to be specified for values selection to work */
					isSelected: false
				}
			]
		},
		{
			/* Name of the field */
			field: "Grid1",
			rows: [
				{
					id: 1,
					data: [
						{
							/* Name of the field */
							field: "labelInsideGrid1",
							type: "label",
							showLabel: true,
							/* Value to show in the field */
							query: "Label 1",
							/* Page number from PDF where it has been extracted */
							pageNumber: 20,
							/* Origin in the PDF */
							origin: "AUTO",
							/* Top Left and bottom right cordinates of the region
							 * From where the value has been extracted
							 * */
							xMin: 0.335,
							xMax: 0.441,
							yMin: 0.185,
							yMax: 0.194
						},
						{
							/* Name of the field */
							field: "labelInsideGrid2",
							type: "label",
							/* Value to show in the field */
							query: "Label 2",
							/* Numeric Id of the field */
							/*TODO: Check if it is of use */
							id: 1,
							/* Page number from PDF where it has been extracted */
							pageNumber: 20,
							/* Origin in the PDF */
							origin: "AUTO",
							/* Top Left and bottom right cordinates of the region
							 * From where the value has been extracted
							 * */
							xMin: 0.335,
							xMax: 0.441,
							yMin: 0.185,
							yMax: 0.194
						},
						{
							/* Name of the field */
							field: "labelInsideGrid3",
							type: "label",
							/* Value to show in the field */
							query: "Label 3",
							/* Numeric Id of the field */
							/*TODO: Check if it is of use */
							id: 1,
							/* Page number from PDF where it has been extracted */
							pageNumber: 20,
							/* Origin in the PDF */
							origin: "AUTO",
							/* Top Left and bottom right cordinates of the region
							 * From where the value has been extracted
							 * */
							xMin: 0.335,
							xMax: 0.441,
							yMin: 0.185,
							yMax: 0.194
						},
						{
							/* Name of the field */
							field: "labelInsideGrid4",
							type: "label",
							/* Value to show in the field */
							query: "Label 4",
							/* Numeric Id of the field */
							/*TODO: Check if it is of use */
							id: 1,
							/* Page number from PDF where it has been extracted */
							pageNumber: 20,
							/* Origin in the PDF */
							origin: "AUTO",
							/* Top Left and bottom right cordinates of the region
							 * From where the value has been extracted
							 * */
							xMin: 0.335,
							xMax: 0.441,
							yMin: 0.185,
							yMax: 0.194
						}
					]
				}
			]
		}
	]
};