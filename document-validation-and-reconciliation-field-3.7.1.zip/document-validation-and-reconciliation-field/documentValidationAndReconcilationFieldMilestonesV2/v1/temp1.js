window.TEST_VALUES = {
	enableTestMode: true,
	annotationObject: {
		query: "string to search",
		pageNumber: 1,
		xMin: 20.45,
		xMax: 30.32,
		yMin: 18.8,
		yMax: 19.6,
		phraseSearch: false, // if true then ONLY query will be searched otherwise coordinates will be highlighted
		caseSensitive: false,
		entireWord: false,
		highlightAll: true,
		findPrevious: false
	},
	onChange: {},
	config: {
		// highlightAtPDFScale: 0.75,
		defaultRectanglePadding: 1,
		clearCanvasBeforeHighlighting: true,
		highlightTextOnElementFocus: true,
		highlightAll: true,
		pdfGlobalSearch: false,
		dateLocale: "Europe/London",
		dateFormat: "dd-MM-yyyy",
		outputDateFormat: "dd/MMM/yyyy",
		pdfViewerBootstrapFrames: "5", //sum of pdfViewerBootstrapFrames & formPanelBootstrapFrames should always be 12
		formPanelBootstrapFrames: "7"
	},
	updateFormObject: {
		type: "label",
		name: "UMR",
		label: "UMR Label",
		required: false,
		disabled: true,
		visible: true,
		style: {
			divClass: "col-sm-6",
			fieldClass: "form-control",
			labelClass: "text-primary",
			style: ""
		},
		icon: {
			visible: true,
			icon: "lightbulb-o",
			style: "color:red;font-size: 18px"
		}
	},
	masterValues: {
		Broker: ["Broker", "Broker1", "Broker2", "Broker3", "Broker4"],
		Country: ["India", "USA", "Italy", "China"],
		Product: ["Nokia", "Samsung", "Oppo", "Vivo"],
		booleanList: ["Yes", "No"],
		sampleList: {
			text: ["Sample1", "Sample 2"],
			value: [1, 0]
		}
	},
	updateObjectValues: {
		field: "Premium",
		id: 5,
		query: "Terrorism and/or Sabotage Reinsurance",
		pageNumber: 1,
		origin: "AUTO",
		xMin: 0.335,
		xMax: 0.631,
		yMin: 0.212,
		yMax: 0.224
	},
	formDetails: {
		verticalMargin: "0px",
		vSpacingBetweenFields: "0px",
		style: {
			formClass: "ABC",
			formStyle: "padding:0"
		},
		milestoneClass: "primary",
		verticalTabs: false,
		milestones: [
			{
				label: "Policy Details",
				name: "policyDetail",
				sortOrder: 1,
				style: {
					tabStyle: "color:red",
					contentStyle: "color: blue;",
					active: "background-color:red"
				},
				fields: [
					{
						type: "grid",
						name: "grid1",
						style: {
							divClass: "col-md-12",
							fieldClass: "table table-bordered table-hover table-striped",
							labelClass: "text-primary"
						},
						columns: [
							{
								header: "Product"
							},
							{
								header: "Country"
							},
							{
								header: "Broker",
								headerStyle: ""
							},
							{
								header: "Boolean",
								headerStyle: ""
							}
						]
					},
					{
						type: "label",
						name: "labelTest",
						label: "",
						class: "form-control",
						style: {
							divClass: "col-md-6",
							labelClass: "text-primary",
							style: "color: darkgrey"
						},
						icon: {
							visible: true,
							icon: "times",
							style: "font-size:20px; color:lightblue"
						}
					},
					{
						type: "paragraph",
						name: "UMR_Para",
						label: "Paragraph Field",
						required: true,
						disabled: false,
						visible: true,
						style: {
							divClass: "col-sm-6",
							fieldClass: "form-control",
							labelClass: "text-primary",
							style: ""
						},
						icon: {
							visible: true,
							icon: "lightbulb-o",
							style: "color:red;font-size: 18px"
						}
					},
					{
						type: "text",
						name: "Premium",
						label: "Premium",
						disabled: false,
						visible: true,
						required: true,
						style: {
							divClass: "col-sm-6 no-gutter-right",
							fieldClass: "form-control",
							labelClass: "text-primary",
							style: ""
						},
						validations: [
							{
								function: "alert(field.value);",
								message: "Alert Triggered"
							}
						]

					},
					{
						type: "date",
						name: "Settlement_Due_Date",
						label: "Settlement_Due_Date",
						required: true,
						style: {
							divClass: "col-sm-6 no-gutter-left",
							fieldClass: "form-control",
							labelClass: "text-primary",
							style: ""
						}
					},
					{
						type: "searchableDropdown",
						name: "SearchDD",
						label: "Test Dropdown",
						required: true,
						disabled: false,
						visible: true,
						style: {
							divClass: "col-sm-6",
							fieldClass: "form-control",
							labelClass: "text-primary",
							style: ""
						}
					}
				],
				sections: [
					{
						label: "Policy Details",
						name: "PolicyDetails",
						collapsed: false,
						style: {
							class: "panel panel-primary",
							style: "background-color: white; padding:0px; color: black",
							headerStyle: "color: red"
						},
						fields: [
							{
								type: "grid",
								name: "grid2",
								style: {
									divClass: "col-md-12",
									divStyle: "padding:2px; ",
									fieldClass: "table table-bordered table-hover table-striped",
									labelClass: "text-primary",
									style: ""
								},
								columns: [
									{
										header: "First Name"
									},
									{
										header: "Last Name"
									},
									{
										header: "Email"
									},
									{
										header: "DropDown"
									}
								]
							},
							{
								type: "currency",
								name: "Amount",
								label: "Amount",
								required: true,
								style: {
									divClass: "col-md-6",
									fieldClass: "form-control",
									labelClass: "text-primary",
									style: "color:red"
								},
								symbol: {
									symbol: "#",
									style: "color: orange",
									visible: true
								},
								icon: {
									visible: true,
									icon: "lightbulb-o",
									style: "color:red;font-size: 18px"
								}
							},
							{
								type: "button-group",
								name: "DupplicateCheck",
								required: true,
								label: "Duplicate Found ?",
								class: "form-control",
								disabled: false,
								visible: true,
								style: {
									divClass: "col-md-6",
									fieldClass: ["btn-primary btn-lg", "btn-danger btn-lg"],
									labelClass: "text-primary",
									style: ""
								},
								icon: {
									visible: true,
									icon: "lightbulb-o",
									style: "color:red;font-size: 18px"
								}
							},
							{
								type: "button",
								name: "TestButton",
								required: true,
								label: "Test Button",
								class: "form-control",
								style: {
									divClass: "col-md-6",
									divStyle: "padding: 4px",
									fieldClass: "btn-primary btn-md",
									labelClass: "text-primary",
									style: ""
								},
								icon: {
									visible: true,
									icon: "times",
									style: "color:red;font-size: 18px"
								}
							}
						]
					},
					{
						label: "Policy Details 2",
						name: "PolicyDetails2",
						collapsed: false,
						style: {
							class: "panel panel-primary"
						},
						fields: [
							{
								type: "text",
								name: "Situation",
								label: "Situation",
								required: true,
								style: {
									divClass: "col-md-6",
									fieldClass: "form-control",
									labelClass: "text-primary",
									style: ""
								},
								icon: {
									visible: true,
									icon: "lightbulb-o",
									style: "color:red;font-size: 18px"
								},
								value: {
									query: "ABC",
									pageNumber: 12,
									origin: "AUTO",
									label: "",
									id: 7,
									xMin: 0.436,
									xMax: 0.529,
									yMin: 0.537,
									yMax: 0.547
								}
							}
						]
					}
				]
			},
			{
				label: "Incident Details",
				name: "incidentDetail",
				sortOrder: 2,
				sections: [
					{
						label: "Insurance Details",
						name: "Policy_Details",
						collapsed: true,
						class: "panel panel-primary",
						fields: [
							{
								type: "text",
								name: "Address",
								label: "Address",
								class: "form-control",
								required: true,
								style: {
									divClass: "col-md-6",
									fieldClass: "form-control",
									labelClass: "text-primary",
									style: ""
								}
							}
						]
					}
				]
			}
		]
	},
	formValues: [
		{
			field: "grid1",
			rows: [
				{
					id: 1,
					data: [
						{
							type: "select",
							name: "ProductDD",
							masterListValue: "Product",
							rows: [
								{
									query: "Oppo",
									label: "",
									pageNumber: 1,
									origin: "AUTO",
									xMin: 0.335,
									xMax: 0.631,
									yMin: 0.212,
									yMax: 0.224,
									isSelected: true
								}
							],
							style: {
								cellStyle: "padding:0px",
								cellClass: "text-danger",
								fieldClass: "form-control"
							},
							icon: {
								visible: true,
								icon: "times",
								style: "color:red;font-size: 18px"
							}
						},
						{
							type: "select",
							name: "SampleDD",
							masterListValue: "sampleList",
							rows: [
								{
									query: 0,
									pageNumber: 1,
									origin: "AUTO",
									xMin: 0.335,
									xMax: 0.631,
									yMin: 0.212,
									yMax: 0.224,
									isSelected: true
								}
							],
							style: {
								cellStyle: "padding:0px",
								cellClass: "text-danger",
								fieldClass: "form-control"
							},
							icon: {
								visible: true,
								icon: "times",
								style: "color:red;font-size: 18px"
							}
						},
						{
							type: "select",
							name: "BrokerDD",
							masterListValue: "Broker",
							rows: [
								{
									query: "Broker13",
									pageNumber: 1,
									origin: "AUTO",
									xMin: 0.335,
									xMax: 0.631,
									yMin: 0.212,
									yMax: 0.224,
									isSelected: true
								}
							],
							style: {
								cellStyle: "padding:0px",
								cellClass: "text-danger",
								fieldClass: "form-control"
							},
							icon: {
								visible: true,
								icon: "times",
								style: "color:red;font-size: 18px"
							}
						},
						{
							type: "select",
							name: "BoolDD",  // name is mandatory for select, multiselect inside the gride and that should be unique always with all other fields in the form
							masterListValue: "booleanList",
							rows: [
								{
									query: "Yes",
									pageNumber: 1,
									origin: "AUTO",
									xMin: 0.335,
									xMax: 0.631,
									yMin: 0.212,
									yMax: 0.224,
									isSelected: true
								}
							],
							style: {
								cellStyle: "padding:0px",
								cellClass: "text-danger",
								fieldClass: "form-control"
							},
							icon: {
								visible: true,
								icon: "times",
								style: "color:red;font-size: 18px"
							}
						}
					]
				}
			]
		},
		{
			field: "grid2",
			rows: [
				{
					id: 1,
					data: [
						{
							query: "John",
							pageNumber: 12,
							origin: "AUTO",
							type: "paragraph",
							id: 7,
							xMin: 0.436,
							xMax: 0.529,
							yMin: 0.537,
							yMax: 0.547
						},
						{ query: "Doe", dataStyle: "", type: "text" },
						{ query: "John@test.com", type: "text" },
						{
							type: "select",
							name: "BoolDD2",
							masterListValue: "Product",
							rows: [
								{
									query: "No",
									pageNumber: 12,
									origin: "AUTO",
									label: "",
									id: 7,
									xMin: 0.436,
									xMax: 0.529,
									yMin: 0.537,
									yMax: 0.547,
									isSelected: true
								}
							],
							style: {
								cellStyle: "padding:0px",
								cellClass: "text-danger",
								fieldClass: "form-control"
							},
							icon: {
								visible: true,
								icon: "times",
								style: "color:red;font-size: 18px"
							}
						}
					]
				},
				{
					id: 2,
					data: [
						{
							query: "July",
							type: "text"
						},
						//{
						//	type: "select",
						//	name: "CountryDD",
						//	masterListValue: "Country",
						//	rows: [
						//		{
						//			query: "USA",
						//			pageNumber: 12,
						//			origin: "AUTO",
						//			label: "",
						//			id: 7,
						//			xMin: 0.436,
						//			xMax: 0.529,
						//			yMin: 0.537,
						//			yMax: 0.547,
						//			isSelected: true
						//		}
						//	],
						//	style: {
						//		cellStyle: "padding:0px",
						//		cellClass: "text-danger",
						//		fieldClass: "form-control"
						//	},
						//	icon: {
						//		visible: true,
						//		icon: "times",
						//		style: "color:red;font-size: 18px"
						//	}
						//},
						{
							query: "July@test.com",
							type: "text"
						}
					]
				}
			]
		},
		{
			field: "Settlement_Due_Date",
			query: "2022-01-11",
			id: 1,
			pageNumber: 20,
			origin: "AUTO",
			name: "Settlement_Due_Date",
			xMin: 0.335,
			xMax: 0.441,
			yMin: 0.185,
			yMax: 0.194,
			accuracy: 1
		},
		{
			field: "UMR",
			query: "B98345029321",
			id: 1,
			pageNumber: 1,
			origin: "AUTO",
			name: "qaz",
			xMin: 0.335,
			xMax: 0.441,
			yMin: 0.185,
			yMax: 0.194,
			accuracy: 1

		},
		{
			field: "labelTest",
			query: "B98345029321",
			id: 1,
			pageNumber: 1,
			origin: "AUTO",
			name: "qaz",
			xMin: 0.335,
			xMax: 0.441,
			yMin: 0.185,
			yMax: 0.194,
			accuracy: 1
		},
		{
			field: "SearchDD",
			rows: [
				{
					query: "Google",
					id: 1,
					pageNumber: 2,
					origin: "AUTO",
					name: "qaz",
					xMin: 0.335,
					xMax: 0.441,
					yMin: 0.185,
					yMax: 0.194,
					accuracy: 1,
					isSelected: true
				},
				{
					query: "Microsoft",
					id: 1,
					pageNumber: 3,
					origin: "AUTO",
					name: "qaz",
					xMin: 0.335,
					xMax: 0.441,
					yMin: 0.185,
					yMax: 0.194,
					accuracy: 1
				},
				{
					query: "Apple",
					id: 1,
					pageNumber: 10,
					origin: "AUTO",
					name: "qaz",
					xMin: 0.335,
					xMax: 0.441,
					yMin: 0.185,
					yMax: 0.194,
					accuracy: 1
				}
			]
		},
		{
			field: "DupplicateCheck",
			rows: [
				{
					query: "Yes",
					id: 1,
					pageNumber: 2,
					origin: "AUTO",
					name: "qaz",
					xMin: 0.335,
					xMax: 0.441,
					yMin: 0.185,
					yMax: 0.194,
					accuracy: 1
				},
				{
					query: "No",
					id: 1,
					pageNumber: 3,
					origin: "AUTO",
					name: "qaz",
					xMin: 0.335,
					xMax: 0.441,
					yMin: 0.185,
					yMax: 0.194,
					accuracy: 1
				}
			]
		},
		{
			field: "Address",
			query: "100 Paseo de Roxas , Legazpi Village, Makati, Metro Manila, Phillipines",
			pageNumber: 1,
			origin: "AUTO",
			xMin: 0.333,
			xMax: 0.499,
			yMin: 0.239,
			yMax: 0.332,
			tempKey: 1234,
			id: 2
		},
		{
			field: "Amount",
			id: 4,
			query: "1,20,000",
			pageNumber: 3,
			origin: "AUTO",
			xMin: 0.333,
			xMax: 0.499,
			yMin: 0.239,
			yMax: 0.332
		},
		{
			field: "TestButton",
			query: "Test Button"
		}
	]
};